<?php 



    echo $_SERVER['SCRIPT_NAME'];
    echo $HTTP_HOST;
    #echo '\nhello';
?>

 
