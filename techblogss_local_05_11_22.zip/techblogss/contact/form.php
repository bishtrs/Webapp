<?php
        $email='';$name;$comment;$captcha;
        if(isset($_POST['email'])){
          $email=$_POST['email'];
        }
        
        if(isset($_POST['name'])){
          $name=$_POST['name'];
        }
        
        if(isset($_POST['comment'])){
          $comment=$_POST['comment'];
        }
        /*
        if(!isset($_POST['email']) || !isset($_POST['name']) || !isset($_POST['comment'])) {
            echo '<h2>Error: All fields are required.</h2>';
            exit;
        }*/
        
        /*if (!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/i", $email)) {
            echo '<h2>Please check the email address.</h2>';
            exit;
        }*/
     
        if(isset($_POST['g-recaptcha-response'])){
          $captcha=$_POST['g-recaptcha-response'];
        }
        if(!$captcha){
          echo '<h2>Please check the the captcha form.</h2>';
          exit;
        }
        $secretKey = "6LfNMeUUAAAAANumM6TIy4eu1_cqYkl7n9zFHJD5";
        $ip = $_SERVER['REMOTE_ADDR'];
        // post request to server
        $url = 'https://www.google.com/recaptcha/api/siteverify?secret=' . urlencode($secretKey) .  '&response=' . urlencode($captcha);
        $response = file_get_contents($url);
        $responseKeys = json_decode($response,true);
        // should return JSON with success as true
        
        $headers = '';
        $headers .= 'From: '.$email."\r\n".
        $comment .= ' '.$name;

       
        if($responseKeys["success"]) {
                mail("techblogss@techblogss.com","My subject",$comment, $headers);
                echo '<h2>Thanks for posting comment</h2>';
                
        } else {
                echo '<h2>You are spammer !</h2>';
        }
?>