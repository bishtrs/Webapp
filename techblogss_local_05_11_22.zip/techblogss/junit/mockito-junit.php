<?php 
    include("../header.htm");
?>

<head>
    <title>Mockito JUnit Tutorial with various examples</title>
	<meta name="description" content="This tutorial explains how to integrate Mockito and JUnit using MockitoJUnitRunner." />
	<link rel="canonical" href="https://www.techblogss.com/junit/mockito-junit" />
</head>

<body>
	<?php 
		include("../navigation.htm");
	?>
   	
	<div id="content">
	
    <div id="blog" style="float:left;">
	
	<div id="problem">
		<h1>Mockito Junit Tutorial</h1>
	</div>
    
    <div id="solution">
        <p><code>Mockito</code> is an open source unit test framework in Java used for mocking. Using <code>Mockito</code> framework you can set the expection what an object will return, or what exception it throws or count how may times it was invoked.</p>
	</div>    
	
	<div id="solution">
        <h2>1. Integrate Mockito and JUnit using MockitoJUnitRunner.</h2>
	    <p>In this example, we will <b><i>mock</b></i> DAO interface that is used by Service class using <code>Mockito</code> framework.</p>
		<h4>Step 1) Add mockito-core dependency to maven file</h4>
		<h4>Maven details</h4>
    </div>
	
	<div id="code"> <pre class="prettyprint">
&lt;dependency&gt;
    &lt;groupId&gt;org.mockito&lt;/groupId&gt;
    &lt;artifactId&gt;mockito-core&lt;/artifactId&gt;
    &lt;version&gt;3.3.3&lt;/version&gt;
    &lt;scope&gt;test&lt;/scope&gt;
&lt;/dependency&gt;</pre>	</div>	
	
	 <h4>Gradle details</h4>

	<div id="code">	<pre class="prettyprint">dependencies { testCompile 'org.mockito:mockito-core:3.3.3' }   </pre>	</div>	

    <br>   
    <div id="solution">
        <h4>Step 2) Write a UserDAO interface, UserService class</h4>
        <p>Note that we will not implement UserDAO interface, rather will mock it (using Mockito @Mock ) when it is called in UserService class.</p>
	</div>
	
	<div id="code">	<pre class="prettyprint">
package dao;

public interface UserDAO {
	
    public String getUserName(String id);

}	</pre></div>	


<div id="code">	<pre class="prettyprint">
package service;

import dao.UserDAO;

public class UserService {
	
    private UserDAO userDAO;
	
    public void setUserDAO(UserDAO userDAO) {
        this.userDAO = userDAO;
    }

    public String getUserName(String id) {
        return userDAO.getUserName(id);
    }

}</pre></div>

	<br>
    <div id="solution">
        <h4>Step 3) Write JUnit UserServiceTest class which tests getUserName() method of UserService Class</h4>
        <p>To mock a class using <code>Mockito</code>, you can either use <code>Mockito mock()</code> method or use <code>@Mock</code> annotation.
        If you use <code>Mockito mock()</code> method, you have to set the mock reference in the class to be tested. But if you use <code>@Mock</code> annotation, then you can use <code>@InjectMocks</code> annotation to automatically set the mock object in test class and also you have to use <code>MockitoAnnotations.initMock(this)</code> or use <code>MockitoJUnitRunner</code>.</p>
        <p>Note that UserDAO implementation is not used, rather it is mocked when it is called in UserService class.</p>
	</div>
	
    <p>Mock using <code>Mockito mock()</code></p>
    
	<div id="code">	<pre class="prettyprint">
package service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

public class UserServiceTest {
	
    private UserService userService = new UserService();
     
    private UserDAO userDAO;
    
   @Before
    public void setUp() {
    	userDAO = Mockito.mock(UserDAO.class);
    	userService.setUserDAO(userDAO);
    }

    @Test
    public void testGetUserName() {
        when(userDAO.getUserName("u768034")).thenReturn("John Bocelli");
        String userName = userService.getUserName("u768034");
        assertNotNull(userName);
    }

}	</pre></div><br>

    <p>Mock using <code>@Mock</code> annotation</p>

	<div id="code">	<pre class="prettyprint">
package service;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import dao.UserDAO;

@RunWith(MockitoJUnitRunner.class)
public class UserServiceTest {
	
    @InjectMocks
    private UserService userService = new UserService();
     
    @Mock
    private UserDAO userDAO;

    @Test
    public void testGetUserName() {
        when(userDAO.getUserName("u768034")).thenReturn("John Bocelli");
        String userName = userService.getUserName("u768034");
        assertNotNull(userName);
    }

}	</pre></div><br>


	<div id="problem">
		<h2>2. Mock void method using Mockito doNothing()</h2>
	</div>
    
	<div id="solution">
	    <p>Sometimes we have to mock calls which have return type as void. These calls can be mocked using <code>Mockito doNothing()</code>. In this example, we will <b><i>mock</b></i> DAO interface method that does not return any value and is called by Service class using <code>Mockito doNothing()</code></p>

    <div id="solution">
        <h4>Step 1) Write a UserDAO interface, UserService class</h4>
        <p>Note that we will not implement UserDAO interface, rather will mock it (using Mockito @Mock ) when it is called in UserService class.</p>
	</div>
	
	<div id="code">	<pre class="prettyprint">
package dao;

public interface UserDAO {
	
    public void updateUserName(String id, String name);

}	</pre></div>	


<div id="code">	<pre class="prettyprint">
package service;

import dao.UserDAO;

public class UserService {
	
    private UserDAO userDAO;
	
    public void setUserDAO(UserDAO userDAO) {
        this.userDAO = userDAO;
    }
   
    public void updateUserName(String id, String name) {
        userDAO.updateUserName(id, name);
    }

}</pre></div>

	<br>
    <div id="solution">
        <h4>Step 2) Write JUnit UserServiceTest class which tests updateUserName() method of UserService Class</h4>
        <p>Note that since updateUserName() method return type is <code>void</code>, we need to use Mockito <code>doNothing()</code> to mock the void method.</p>
	</div>
	
	<div id="code">	<pre class="prettyprint">
package service;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.doNothing;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import dao.UserDAO;

@RunWith(MockitoJUnitRunner.class)
public class UserServiceTest {
	
    @InjectMocks
    private UserService userService = new UserService();
     
    @Mock
    private UserDAO userDAO;

    @Test
    public void testUpdateUserName() {
        doNothing().when(userDAO).updateUserName("u768034", "John");
        userService.updateUserName("u768034", "John");
    }

}	</pre></div><br>	

	<div id="problem">
		<h2>3. Verify method invocation on a mock object</h2>
	</div>
    
	<div id="solution">
	    <p>To verify if a method of mock object was invoked or how many times it was invoked, you can use <code>verify()</code>. Following method are used with <code>verify()</code> method to verify method calls:
        <ul>
            <li><code>times(int numberOfInvocations)</code> will verify if a method was invoked specific number of times.</li>
            <li><code>never()</code> will verify if method was never invoked.</li>
            <li><code>atLeastOnce() will verify if method was invoked at least once.</code></li>
            <li><code>atMost(int numberOfInvocations) will verify if method was not invoked more than specified times.</code></li>
            <li><code>only()</code>will verify if only this method was invoked.</li>
        </ul>
        </p>
    </div>
	
	<div id="code">	<pre class="prettyprint">
package service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.never;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import dao.UserDAO;

@RunWith(MockitoJUnitRunner.class)
public class UserServiceTest {
	
    @InjectMocks
    private UserService userService = new UserService();
     
    @Mock
    private UserDAO userDAO;

    @Test
    public void testGetUserName() {
        when(userDAO.getUserName("u768034")).thenReturn("John Bocelli");
        String userName = userService.getUserName("u768034");
        assertNotNull(userName);
        verify(userDAO, times(1)).getUserName("u768034");
        verify(userDAO, never()).updateUserName("u768034" , "John");
    }

}	</pre></div><br>	

	<div id="problem">
		<h2>4. Throwing exception using Mockito</h2>
	</div>
    
	<div id="solution">
	    <p>Sometimes you need to verify failure conditions also using JUnit. For example what if the method call throws exception and you want to verify that correct exception is thrown. In this case you can use Mockito's <code>doThrow()</code> and <code>thenThrow()</code> APIs. In case the mocked method has return type of void then you need to use <code>doThrow()</code> else you have to use <code>thenThrow()</code>.
        </p>
    </div>
	
	<div id="code">	<pre class="prettyprint">
package service;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import dao.UserDAO;

@RunWith(MockitoJUnitRunner.class)
public class UserServiceTestException {
	
    @InjectMocks
    private UserService userService = new UserService();
     
    @Mock
    private UserDAO userDAO;

    @Test(expected = IllegalArgumentException.class)
    public void testGetUserNameThrowsException() {
        when(userDAO.getUserName("")).thenThrow(new IllegalArgumentException("userid is empty"));
        userService.getUserName("");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testUpdateUserNameThrowsException() {
        doThrow(new IllegalArgumentException("username is empty")).when(userDAO).updateUserName("u768034", "");
        userService.updateUserName("u768034", "");
    }

}	</pre></div><br>	

    </div>

	
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?> 
    <br>
    
     References : <br><br>
    <a href="https://javadoc.io/doc/org.mockito/mockito-core/3.3.3/org/mockito/Mockito.html#doNothing--" target="_blank">Mockito doNothing()</a>	<br><br>
 
 	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
	
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>
</html>