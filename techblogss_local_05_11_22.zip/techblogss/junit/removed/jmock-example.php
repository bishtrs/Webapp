<?php 
    include("header.htm");
?>

<head>
    <title>JMock Example</title>
	<meta name="description" content="JMock Example" />
	<link rel="canonical" href="https://www.techblogss.com/junit/jmock-example" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
	
    <div id="blog" style="float:left;">
	
	<div id="problem">
		<h2>JMock Example</h2>
	</div>
	
	<div id="solution">
	    <p>This JMock Example shows how to write a JUnit test case using JMock  In this example, we will <b><i>mock</b></i> DAO interface
        that is used by Service class using <b><i>JMock </b></i> .</p>
		<h4>Step 1) Download required jars from below location</h4>
		<a href="https://jar-download.com/maven-repository-class-search.php?search_box=org.jmock.integration.junit4.JUnitRuleMockery">JMock Jars</a><br>
    </div>
	
    <div id="solution">
        <h4>Step 2) Write a UserDAO interface, UserService class</h4>
        <p>Note that we will not implement UserDAO interface, rather will mock it when it is called in UserService class.</p>
	</div>
	
	<div id="code">	<pre class="prettyprint">
package dao;

public interface UserDAO {
	
    public String getUserName(String id);

}	</pre></div>	


<div id="code">	<pre class="prettyprint">
package service;

import dao.UserDAO;

public class UserService {
	
    private UserDAO userDAO;
	
    public void setUserDAO(UserDAO userDAO) {
        this.userDAO = userDAO;
    }

    public String getUserName(String id) {
        return userDAO.getUserName(id);
    }

}</pre></div>

	<br>
    <div id="solution">
        <h4>Step 3) Write JUnit UserServiceTest class which tests getUserName() method of UserService Class.</h4>
	</div>
	
	<div id="code">	<pre class="prettyprint">
package service;

import static org.junit.Assert.assertNotNull;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JMock;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import dao.UserDAO;

@RunWith(JMock.class)
public class UserServiceTest {

    private Mockery context = new JUnit4Mockery();

    private UserDAO userDAO;

    @Before
    public void setUp() {
        userDAO = context.mock(UserDAO.class);
    }

    @Test
    public void testGetUserName() {
            
        context.checking(new Expectations() {{
            oneOf (userDAO).getUserName("u768034"); will(returnValue("John Bocelli"));
        }});
        UserService userService = new UserService();
        userService.setUserDAO(userDAO);
        String userName = userService.getUserName("u768034");
        assertNotNull(userName);
    }

}	</pre></div>	
	
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?> 
    <br>
 
 	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
	
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>
</html>