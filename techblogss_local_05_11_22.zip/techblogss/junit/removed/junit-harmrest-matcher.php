<?php 
    include("header.htm");
?>

<head>
    <title>JUnit Harmrest Matcher example</title>
	<meta name="description" content="JUnit Harmrest Matcher example" />
	<link rel="canonical" href="https://www.techblogss.com/junit/junit-harmrest-matcher" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
	
    <div id="blog" style="float:left;">
	
	<div id="problem">
		<h2>JUnit Harmrest Matcher example</h2>
	</div>
	
	<div id="solution">
	    <p>Harmcrest Matcher library makes it easy to perform assertion in JUnit tests. Below example shows how you can use Harmrest Matcher to 
        verify a List by size, items, etc after doing some processing.</p>
		<h4>Step 1) Download below harmcrest jars from the specified location</h4>
		<a href="https://mvnrepository.com/artifact/org.hamcrest/hamcrest-core/1.3" target="_blank">hamcrest-core-1.3.jar</a><br>
        
        <div id="code">	<pre class="prettyprint">
&lt;dependency>
    &lt;groupId>org.hamcrest&lt;/groupId>
    &lt;artifactId>hamcrest-core&lt;/artifactId>
    &lt;version>1.3&lt;/version>
    &lt;scope>test&lt;/scope>
&lt;/dependency>        </pre></div>

        <a href="https://mvnrepository.com/artifact/org.hamcrest/hamcrest-all/1.3" target="_blank">hamcrest-all-1.3.jar</a><br>
        
        <div id="code">	<pre class="prettyprint">
&lt;dependency>
    &lt;<groupId>org.hamcrest&lt;/groupId>
    &lt;artifactId>hamcrest-all&lt;/artifactId>
    &lt;version>1.3&lt;/version>
    &lt;scope>test&lt;/scope>
&lt;/dependency>        </pre></div>

    </div>
	
    <div id="solution">
        <h4>Step 2) Write Fruit class</h4>
	</div>
	
	

<div id="code">	<pre class="prettyprint">
import java.util.ArrayList;
import java.util.List;

public class Fruit {
	
    private String name;
    private List&lt;String&gt; fruits = new ArrayList^lt;>();
	
    public Fruit() {
    }
	
    public Fruit(String name) {
        this.name = name;
    }
	
    public void addFruit(String fruit) {
        fruits.add(fruit);
    }
	
    public List&lt;String> getFruits() {
        return fruits;
    }

}</pre></div>

	<br>
    <div id="solution">
        <h4>Step 3) Write JUnit FruitTest class which tests whether the List is empty, its size, has correct items using Hamcrest Matchers.</h4>
	</div>
	
	<div id="code">	<pre class="prettyprint">
import static org.hamcrest.CoreMatchers.anyOf;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.hasItems;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.not;

import java.util.List;

import org.hamcrest.collection.IsEmptyCollection;
import org.junit.Test;


public class FruitTest {
	
    @Test
    public void testGetFruits() {
        Fruit fruit = new Fruit();
        fruit.addFruit("Apple");
        fruit.addFruit("Banana");
        fruit.addFruit("Mango");
        List&lt;String> fruits = fruit.getFruits();
        
        assertThat(fruits, not(IsEmptyCollection.&lt;String>empty()));
        assertThat(fruits, hasSize(3));

        assertThat(fruits, hasItems("Apple", "Mango", "Banana")); // any order is fine
        assertThat(fruits, contains("Apple", "Banana", "Mango")); // strict order
        
        assertThat(fruits, not(hasItem("Pineapple")));
        
        assertThat(fruits, hasItems(anyOf(equalTo("Apple"), equalTo("two"), equalTo("three"))));
    }

}	</pre></div>	
	
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?> 
    <br>

References : <br><br>
<a href="http://hamcrest.org/JavaHamcrest/tutorial" target="_blank">Hamcrest tutorial</a>	<br><br>
    
 	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
	
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>
</html>