<?php
header_remove("X-Powered-By"); 
?>

<?php 
    include("../header.htm");
?>

<head>
    <title>Tech Blogss</title>
	<meta name="description" content="Solutions to problems in Java 8" />
    <link rel="canonical" href="https://www.techblogss.com/java8">
</head>

<body>
   	<?php 
		include("navigation.htm");
	?>
    
	<div id="title">
		<div id="topic" class="topic">
		
		<div style='background-color:#159414;color:white'><h3>Java 8</h3></div>
	    <ul id="problems">
            <li><a href="java/java_lambda" target="_blank">Lambda Expressions </a></li>
			<li><a href="java/java_cj_foreach_continue" target="_blank">Java 8 forEach continue</a></li>
            <li><a href="java/java8-predicate" target="_blank">Predicate example</a></li>
            <li><a href="java/java_j8_stringjoiner" target="_blank">Java 8 StringJoiner example</a></li>
   			<li><a href="java/java8-xmx-xms" target="_blank">Java Heap sizing</a></li>
            <li><a href="java/java8-garbage-collection-algorithms" target="_blank">Garbage Collection Algorithms</a></li>
            <li><a href="java/java8-completablefuture" target="_blank">CompletableFuture example</a></li>
            <li><a href="java/java8-spliterator" target="_blank">Spliterator example</a></li>
		</ul>
		
        <div style='background-color:#159414;color:white'><h3>Streams</h3></div>
		<ul id="problems">
            <li><a href="java/java8-stream-findanyfindfirst" target="_blank">Stream findAny(), findFirst()</a></li>
            <li><a href="java/java8-stream-allanynonematch" target="_blank">allMatch(), anyMatch(), noneMatch()</a></li>
            <li><a href="java/java_streamflatmap" target="_blank">Stream flatMap()</a></li>
            <li><a href="java/java8-stream-groupingby" target="_blank">Collectors groupingBy()</a></li>
            <li><a href="java/java8-collectors" target="_blank">Collectors example</a></li>
            <li><a href="java/java8-stream-reduce" target="_blank">Stream reduce()</a></li>
            <li><a href="java/java8-stream-sorted" target="_blank">Sort List using Stream sorted()</a></li>
        </ul>        
        </div>
        
		<div style='background-color:#159414;color:white'><h3>JUnit</h3></div>
		<ul id="problems">
            <li><a href="junit/junit4-tutorial" target="_blank">JUnit 4 Tutorial</a></li>
            <li><a href="junit/mockito-junit" target="_blank">Mockito JUnit Tutorial</a></li>
        </ul>        
        </div>
    </div>
		
	<div id="contentMain">
	
	
	<div id="wrap">
		<P>The code solutions have been tested with Java 1.8 version. You can download the jdk from this link</P>
        <a href="https://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html">Download JDK 8</a>
        <br><br><br><br><br><br><br><br><br><br><br><br>
         <!-- ADU1 -->
        <?php include("sidebar/ad.htm"); ?>

	</div>

	</div>
	</div>
    
    <?php include("sidebar/sidebarHomePage.htm"); ?>

</body>


<?php 
    include("footer.htm");
?>
	
</html>
