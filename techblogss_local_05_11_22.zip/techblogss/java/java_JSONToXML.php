<?php 
    include("../header.htm");
?>

<head>
    <title>Convert JSON to XML in Java</title>
	<meta name="description" content="Convert JSON to XML in Java, Convert XML to JSON in Java" />
	<link rel="canonical" href="https://www.techblogss.com/java/java_JSONToXML">
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
    <div id="content">
    <div id="blog">
	<div id="problem">
		<h2>How to convert JSON to XML in Java ?</h2>
	</div>

	<div id="solution">
		<h4>You can convert a JSON object to XML using JSON-Java library (json.jar), which you need to download from this link 
        <a href="https://repo1.maven.org/maven2/org/json/json/20190722/json-20190722.jar" target="_blank"> json-20190722 </a> 
        or using below maven dependency</h4>
    
    <div id="code">
	<pre class="prettyprint">
&lt;dependency>
    &lt;groupId>org.json&lt;/groupId>
    &lt;artifactId>json&lt;/artifactId>
    &lt;version>20190722&lt;/version>
&lt;/dependency>
</pre>
	</div>
    <br>
    <p>You can convert a JSON object to XML using json library as shown below</p>
	</div>
    
	<div id="solution">
		<h4>JSON content that you want to convert to XML</h4>
	</div>
	<div id="code">
	<pre class="prettyprint">
{
    "person" {
        "firstName": "Harry",
        "lastName": "Potter",
        "addresses": [
            { "city" : "London" },
            { "city" : "New York" }
        ]
    }
}
	</pre>
	</div>
	
	<div id="solution">
		<h4>Expected XML</h4>
	</div>
	
	<div id="code">
    <pre class="prettyprint">
&lt;person&gt;
    &lt;firstName&gt;Harry&lt;/firstName&gt;
    &lt;lastName&gt;Potter&lt;/lastName&gt;
    &lt;addresses&gt;
        &lt;address&gt;
            &lt;city&gt;London&lt;/city&gt;
        &lt;/address&gt;
        &lt;address&gt;
            &lt;city&gt;New York&lt;/city&gt;
        &lt;/address&gt;
    &lt;/addresses&gt;
&lt;/person&gt;</pre>
	</div>
	
	<br>
    
	<div id="code">	
    <pre class="prettyprint">
// Converts JSON to XML    
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;
	
public class JsonToXml {
    public static void main(String[] args) throws JSONException {
	String json = "{\"person\" :{\"firstName\": \"Harry\",\"lastName\": \"Potter\"," +
	    "\"addresses\": [{\"city\" : \"London\" },{ \"city\" : \"New York\"}]}}";
		
	JSONObject jsonObject = new JSONObject(json);
        String xml = XML.toString(jsonObject);
        
	System.out.println(xml);
    }
}	
    </pre>
	</div>

    <div id="solution">
		<h4>Console Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
&lt;?xml version="1.0" encoding="ISO-8859-15"?&gt;
&lt;person&gt;
    &lt;firstName&gt;Harry&lt;/firstName&gt;
    &lt;lastName&gt;Potter&lt;/lastName&gt;
    &lt;addresses&gt;&lt;city&gt;London&lt;/city&gt;&lt;/addresses&gt;
    &lt;addresses&gt;&lt;city&gt;New York&lt;/city&gt;&lt;/addresses&gt;
&lt;/person&gt;
</pre></div>
<br>

<div id="problem">
		<h2>Convert XML to JSON in Java</h2>
	</div>
    <div id="solution">
    <p>You can convert a XML to JSON using json library as shown below</p>
	</div>
    
	<div id="solution">
		<h4>XML content</h4>
	</div>
	<div id="code">
    <pre class="prettyprint">
&lt;person&gt;
    &lt;firstName&gt;Harry&lt;/firstName&gt;
    &lt;lastName&gt;Potter&lt;/lastName&gt;
    &lt;addresses&gt;
	&lt;address&gt;
	&lt;city&gt;London&lt;/city&gt;
	&lt;/address&gt;
	&lt;address&gt;
	&lt;city&gt;New York&lt;/city&gt;
	&lt;/address&gt;
    &lt;/addresses&gt;
&lt;/person&gt;
	</pre>
    </div>
    
	<div id="solution">
		<h4>Expected JSON</h4>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
{"person":
    {
        "firstName": "Harry",
        "lastName": "Potter",
        "addresses": 
            {"address":[
                { "city" : "London" },
                { "city" : "New York" }
            ]
        }
    }
}
    </pre>
	</div>
	
	<div id="solution">
		
	</div>
	
	<div id="code">	
    <pre class="prettyprint">
//Converts XML to JSON
import org.json.JSONException;
import org.json.XML;
	
public class XMLToJSON {
    public static void main(String[] args) throws JSONException {
        String xml = "&lt;person&gt;" +
        "&lt;firstName&gt;Harry&lt;/firstName&gt;" +
        "&lt;lastName&gt;Potter&lt;/lastName&gt;" +
        "&lt;addresses&gt;" +
        "&lt;address&gt;" +
        "&lt;city&gt;London&lt;/city&gt;" +
        "&lt;/address&gt;" +
        "&lt;address&gt;" +
        "&lt;city&gt;New York&lt;/city&gt;" +
        "&lt;/address&gt;" +
        "&lt;/addresses&gt;" +
        "&lt;/person&gt;";<br>
        System.out.println(XML.toJSONObject(xml).toString());<br>
    }
}
    </pre>	
	</div>
	
    <div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
    <pre class="prettyprint">
{"person":
{"firstName":"Harry",
"lastName":"Potter",
"addresses":
{"address":[{"city":"London"},
{"city":"New York"}]}}}


    </pre>
	</div>

    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
 
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->

         
</body>

<?php 
    include("footer.htm");
?>

</html>
