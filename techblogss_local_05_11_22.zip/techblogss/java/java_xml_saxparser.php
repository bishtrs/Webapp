<?php 
    include("../header.htm");
?>

<head>
    <title>Java SAX Parser example</title>
	<meta name="description" content="Java SAX Parser example, Read XML file in Java using SAX parser" />
	<link rel="canonical" href="https://www.techblogss.com/java/java_xml_saxparser">
</head>

<body>
	<?php 
		include("navigation.htm");
	?>

    <div id="content">
	<div id="blog">
    <div id="problem">
		<h1>Read XML file in Java using SAX parser</h1>
	
		<p><b><i>SAX</b></i> stands for Simple API for XML. It is an event based parsing and you need to create your own handler Class
        for handling the events (like StartDocument, EndDocument, StartElement, EndElement, etc) whenever <b><i>SAX</b></i> parser pareses 
        the xml document.</p>
    
        <h2>When to use SAX Parser ? </h2>
        <ul>
            <li>You should use SAX parser in case of shallow XML documents, documents that are not deeply nested.</li>
			<li>You want to process the XML document in a linear fashion.
         </ul>
         
           
        <p>Below example shows how to read a XML file in Java using SAX parser</p>
	</div>
	
	<div id="solution">
		XML file that you want to parse: <b>employees.xml</b>
	</div>
	
	
	<div id="code">
	
	<pre class="prettyprint">
&lt;?xml version = "1.0"?>    
&lt;employees>
	&lt;employee id="123">
	    &lt;firstname>Mohit&lt;/firstname>
	    &lt;lastname>Bisht&lt;/lastname>
	&lt;/employee>
	&lt;employee id="124">
	    &lt;firstname>Samit&lt;/firstname>
	    &lt;lastname>Ahlawat&lt;/lastname>
	&lt;/employee>
	&lt;employee id="125">
	    &lt;firstname>Vikram&lt;/firstname>
	    &lt;lastname>Raheja&lt;/lastname>
	&lt;/employee>
&lt;/employees>
	</pre>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// SAX Parser     
import java.io.File;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

// SAX event handler 
class EmployeeHandler extends DefaultHandler {
    boolean id = false;
    boolean firstname = false;
    boolean lastname = false;

    @Override
    public void startElement(String uri, String localName, String qName,
        Attributes attributes) throws SAXException {
	
        if (qName.equalsIgnoreCase("employee")) {
            String id = attributes.getValue("id");
            System.out.println("id  : " + id);
        } else if (qName.equalsIgnoreCase("firstname")) {
            firstname = true;
        } else if (qName.equalsIgnoreCase("lastname")) {
            lastname = true;
        }
    }
	
    @Override
    public void endElement(String uri, String localName, String qName)
        throws SAXException {
        if (qName.equalsIgnoreCase("student")) {
            System.out.println("End Element :" + qName);
        } 
    }
		
    @Override
    public void characters(char ch[], int start, int length) throws SAXException {
        if (firstname) {
            System.out.println("First Name : " + new String(ch, start, length));
            firstname = false;
        }
		
        if (lastname) {
            System.out.println("Last Name : " + new String(ch, start, length));
            lastname = false;
        }
    }
}
	

public class TestSAXParser {
    public static void main(String[] args) {
        try {
            File inputFile = new File("C://employees.xml");
            SAXParserFactory  saxParserFactory = SAXParserFactory .newInstance();
            SAXParser saxParser = saxParserFactory.newSAXParser();
            EmployeeHandler handler = new EmployeeHandler() ;
    	    saxParser.parse(inputFile, handler); 
        } catch (Exception  e) {
            e.printStackTrace();
        }  
    }
}
	</pre>
	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
    <pre class="prettyprint">
id  : 123
First Name : Mohit
Last Name : Bisht
id  : 124
First Name : Samit
Last Name : Ahlawat
id  : 125
First Name : Vikram
Last Name : Raheja
    </pre>
	</div>
	
	<div id="comments">
        <h4>Comments on above approach:</h4>
		<ul>
			<li>You should use SAX parser in case of shallow XML documents, documents that are not deeply nested.</li>
			<li>You should use SAX parser for large documents.</li>
            <li>SAX requires much less memory than DOM, because SAX does not construct an internal representation 
            (tree structure) of the XML data, as a DOM does.</li>
            <li>When you need to modify an XML structure - especially when you need to modify it interactively - 
            an in-memory structure makes more sense. DOM is one such model</li>
        </ul>
	</div>
	
   <!-- ADU1 -->
   <?php include("../sidebar/ad.htm"); ?>
   
References : <a href="https://docs.oracle.com/javase/tutorial/jaxp/sax/parsing.html">https://docs.oracle.com/javase/tutorial/jaxp/sax/parsing.html</a>
	<br>
      </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
	
	<div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    <?php include("share.htm"); ?>
    
</body>

<?php 
    include("footer.htm");
?>

</html>
