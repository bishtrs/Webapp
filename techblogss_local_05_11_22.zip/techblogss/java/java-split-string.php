<?php 
    include("../header.htm");
?>

<head>
    <title>Split String in Java</title>
	<meta name="description" content="split string in java, how to split string in java, how to split a string in java with delimiter, split string in java by dot, space, comma" />
	<link rel="canonical" href="https://www.techblogss.com/java/java-split-string" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>How to split a String in Java ?</h1>
        <p>You can split a <b><i>String</b></i>  in Java by a delimiter like dot, comma, space, etc by using <b><i>String split()</b></i> 
        and <b><i>StringTokenizer</b></i>  class.</p>
        <h3>String split() vs StringTokenizer</h3>
        <p>
        <ul>
            <li><b><i>StringTokenizer</b></i> is a legacy class which is retained for backward compatibility & its use is discouraged in new code. It is recommended to use the <b><i>String split()</b></i> method or the java.util.regex package instead.</li>
            <li><b><i>StringTokenizer</b></i> breaks a String into tokens and you need to iterate over the collection of tokens to get all the strings and doesn't use regular expressions, while <b><i>String split()</b></i> creates an array of String and uses regular expressions</li>
            <li><b><i>StringTokenizer</b></i> provides better performance when compared to <b><i>String split()</b></i>) as it must recompile the regular expression each time.</li>
        </ul>
        </p>
	</div>
	
	<div id="solution">
		<h4>1) Split a string using String split(String regex) by comma.</h4>
    </div>
	<div id="code">
    <pre class="prettyprint">
public class StringSplitTest {

    public static void main(String[] args) {
        String str = "mango,apple,banana,orange";
        String[] array = str.split(",");

        for (String a : array)
            System.out.println(a);
    }
}

    </pre>
	</div>

    <div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
mango
apple
banana
orange
		</pre>
	</div>
    
    <br>
    
    <div id="solution">
		<h4>2) Split a string using String split(String regex) by string pattern.</h4>
    </div>
	<div id="code">
    <pre class="prettyprint">
public class StringSplitTest {

    public static void main(String[] args) {
        String str = "heandhisfriendandhisbrothrrandhissister";
        String[] array = str.split("and");

        for (String a : array)
            System.out.println(a);
    }
}

    </pre>
	</div>

    <div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
he
hisfriend
hisbrothrr
hissister
		</pre>
	</div>
    
    <br>

    	<div id="solution">
		<h4>3) Split a string using String split(String regex) by dot.</h4>
        <p>Since dot is a <b><i>metacharacter</b></i> (others are <b><i>.$|()[{^?*+\\</b></i>), you need to escape it using two backslashes or you need to use [.]. Also in this case <b><i>String split()</b></i> will use <b><i>Pattern.compile(regex)</b></i> internally. </p>
    </div>
	<div id="code">
    <pre class="prettyprint">
public class StringSplitTest {

    public static void main(String[] args) {
        String str = "192.168.123.145";
        String[] array = str.split("\\.");

        for (String a : array)
            System.out.println(a);
		
        array = str.split("[.]");

        for (String a : array)
            System.out.println(a);
    }

}
    </pre>
	</div>

    <div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
192
168
123
145
192
168
123
145
		</pre>
	</div>
    <br>
    
	 <div id="solution">
		<h4>4) Split a string using String split(String regex, limit).</h4>
        <p>The limit parameter controls the number of times the pattern is applied and therefore affects the length of the resulting array.</p>
        <p>The string "hello:and:foo", for example, yields following results with these parameters:<br><br>
<b>Regex&nbsp;	    Limit&nbsp;		Result</b> <br>
 &nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	2&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	"hello", "and:foo" <br>
 &nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	5&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;  "hello", "and", "foo"  <br>
 &nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  -2&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  "hello", "and", "foo" </p>
    </div>
	<div id="code">
    <pre class="prettyprint">
public class StringSplitTest {

    public static void main(String[] args) {
        String str = "192.168.123.145";
        String[] array = str.split("\\.", 2);

        for (String a : array)
            System.out.println(a);
		
        array = str.split("[.]", 3);

        for (String a : array)
            System.out.println(a);
    }

}
    </pre>
	</div>

    <div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
192
168.123.145
192
168
123.145
		</pre>
	</div>
    <br>    
    
    <div id="solution">
		<h4>5) Split a string using StringTokenizer.</h4>
        <p>The <b><i>StringTokenizer</b></i> class allows an application to break a string into tokens. If you don't specify any
        delimiter, space will be used as delimiter by default</p>
    </div>
	<div id="code">
    <pre class="prettyprint">
import java.util.StringTokenizer;

public class StringSplitTest {

    public static void main(String[] args) {
        String str = "Hello world this is a tutorial";
        
        // space will be used as delimiter by default
        StringTokenizer st = new StringTokenizer(str);
        while (st.hasMoreElements()) {
            System.out.println(st.nextElement());
        }
        
        str = "192.168.123.145";

        st = new StringTokenizer(str, ".");
        while (st.hasMoreElements()) {
            System.out.println(st.nextElement());
        }

    }
}
    </pre>
	</div>

    <div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Hello
world
this
is
a
tutorial
192
168
123
145

		</pre>
	</div>
    <br>
    
    <br>
    
     <!-- ADU1 -->

    <?php include("../sidebar/ad.htm"); ?>
    
<div id="refrences">
   References: 

<ul>
    <li><a href="https://docs.oracle.com/javase/8/docs/api/java/util/StringTokenizer.html" target="_blank">Java 8 Docs StringTokenizer</a></li><br>
    <li><a href="https://docs.oracle.com/javase/8/docs/api/java/lang/String.html#split-java.lang.String-" target="_blank">Java 8 Docs String split()</a></li>
</ul>
</div>

	 </div> <!-- blog div-->

    <?php include("../sidebar/sidebar.htm"); ?>

    </div> <!-- content div -->

    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>

</html>