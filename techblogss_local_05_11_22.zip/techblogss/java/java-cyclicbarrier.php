<?php 
    include("../header.htm");
?>

<head>
    <title>CyclicBarrier in Java</title>
    <meta name="description" content="CyclicBarrier in Java" />
    <link rel="canonical" href="https://www.techblogss.com/java/java-cyclicBarrier">
</head>

<body>
    <?php 
        include("../navigation.htm");
    ?>
       
    <div id="content">
    <div id="blog">
    <div id="problem">
        <h1>CyclicBarrier in Java</h1>
    </div>
    <div id="solution">
        <p>A <code>CyclicBarrier</code> allows one or more <code>threads</code> to wait so that they can reach a common point or barrier after which further processing can be done. For example suppose you divide the tasks and multiple <code>threads</code> execute them and then they wait for final processing, you can make <code>threads</code> wait at a common point by invoking <code>await()</code> on <code>CyclicBarrier</code> object.
        </p> 
        <p>
        Below example shows <code>CyclicBarrier</code> example with 2 worker threads t1 & t2 which take list of names and convert them to lowercase. <code>CyclicBarrier runnable thread</code> waits for final processing (which combines list of all names) which can be done by any one of the threads t1 or t2. 
        </p>
    </div>    

    <h4>1) CountDownLatch example with two threads/events </h4>        
    <div id="code">
    <pre class="prettyprint">
package threads;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.stream.Collectors;

public class CyclicBarrierExample {

    private CyclicBarrier cyclicBarrier;
    private Set&lt;String> finalNames = new HashSet<>();
    private Set&lt;String> names1 = new HashSet<>();
    private Set&lt;String> names2 = new HashSet<>();

    public CyclicBarrierExample() {
        cyclicBarrier = new CyclicBarrier(2, () -> {
            finalNames.addAll(names1);
            finalNames.addAll(names2);
            System.out.println(Thread.currentThread().getName() + " done");
            System.out.println(finalNames);
        });
        names1.add("John");
        Thread t1 = new Thread(new NameProcessor(names1));
        names2.add("Mark");
        Thread t2 = new Thread(new NameProcessor(names2));
        t1.start();
        t2.start();
        System.out.println(Thread.currentThread().getName() + " done");
    }

    public static void main(String[] args) {
        new CyclicBarrierExample();
    }

    class NameProcessor implements Runnable {
        private Set&lt;String> names;

        NameProcessor(Set&lt;String> names) {
            this.names = names;
        }

        @Override
        public void run() {
            System.out.println(Thread.currentThread().getName() + " running");
            names = names.stream().map(name -> name.toUpperCase()).collect(Collectors.toSet());
            System.out.println(Thread.currentThread().getName() + " calling await on CB");
            try {
                cyclicBarrier.await();
            } catch (InterruptedException | BrokenBarrierException e) {
                e.printStackTrace();
            }
        }

    }

}    </pre></div>

    <div id="solution">
        <h4>Output : </h4>
    </div>
    
    <div id="code">
        <pre class="prettyprint">
main done
Thread-0 running
Thread-1 running
Thread-1 calling await on CB
Thread-0 calling await on CB
Thread-0 done
[John, Mark]</pre></div><br>
    
 <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
    
References : <br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/CyclicBarrier.html">Oracle Docs CyclicBarrier</a>    <br><br>

        </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
    
     <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>    

</html>
