<?php 
    include("../header.htm");
?>

<head>
    <title>Java HashMap remove entry</title>
<meta name="description" content="Java HashMap remove entry using Collection removeIf(), Map remove, Iterator remvoe, Map clear." />
<link rel="canonical" href="https://www.techblogss.com/java/java_removeitemmap">
</head>

<body>
<?php 
include("../navigation.htm");
?>

   <div id="content" >
<div id="problem">
<h1>Java HashMap remove entry examples</h1>
         <p>
        There are various ways of removing an item from a <code>Map</code> type in Java. We will use <code>HashMap</code> to show various ways of removing an item from a <code>Map</code> and same can be used for other <code>Map</code> implementations.
        </p>
</div>
<div id="solution">
<h4>1) Remove an entry from HashMap by using Collection removeIf() method</h4>
        <p>
        You can remove an entry from <code>HashMap</code> by using <code>Collection removeIf()</code> method which was added in Java 8. It has following signature <code>default boolean removeIf(Predicate filter)</code> and removes all entries from the <code>Collection</code> which match the predicate. <code>removeIf()</code> method will be called on <code>Map.Entry Set</code>. It uses <code>Iterator remove()</code> internally and hence doesn't throw <code>ConcurrentModificationException</code>.
        </p>
        <p>
        In the example below we first pass a predicte (<code>e -> e.getKey().equals("Mark")</code>) that checks for the matching key and another predicate (<code>e -> e.getValue().equals(6)</code>) that checks for the matching value for entry that we want to remove from the <code>HashMap</code>.
        </p>
</div>

<div id="code">
<pre class="prettyprint">
package java8;

import java.util.HashMap;
import java.util.Map;

public class RemoveHashMapEntry {

    public static void main(String[] args) {
        Map&lt;String, Integer> map = new HashMap&lt;>();
        map.put("John", 2);
        map.put("Mark", 1);
        map.put("Thomas", 4);
        map.put("James", 3);
        map.put("Edwin", 5);
        map.put("Vinod", 6);
        System.out.println(map);
        map.entrySet().removeIf(e -> e.getKey().equals("Mark"));
        map.entrySet().removeIf(e -> e.getValue().equals(6));
        System.out.println(map);
    }

}</pre></div>

<div id="solution">
<h4>Output : </h4>
</div>

<div id="code">
<pre class="prettyprint">
{Thomas=4, James=3, Edwin=5, John=2, Mark=1, Vinod=6}
{Thomas=4, James=3, Edwin=5, John=2}</pre></div><br>

    <div id="solution">
    <h4>2) Remove an entry from HashMap by using HashMap remove() method</h4>
        <p>
        You can remove an entry from HashMap by using <code>HashMap remove()</code> method. It has following signature <code>public remove(Object key)</code> and removes the entry from HashMap for the key specified if the key is present. It returns the previous value associated with key passed.
        </p>
</div>

<div id="code">
<pre class="prettyprint">
import java.util.HashMap;
import java.util.Map;

// Removes entry from HashMap
public class MyClass {
    public static void main(String[] args) {
        Map&lt;String, String&gt; map = new HashMap&lt;String, String&gt;();
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        map.remove("key2"); // Remove entry from HashMap

        System.out.println("map " + map);
    }
}</pre></div>

<div id="solution">
<h4>Output : </h4>
</div>

<div id="code">
<pre class="prettyprint">
map {key1=value1, key3=value3}</pre></div><br>


<div id="solution">
        <h4>3) Remove an entry from HashMap by using Iterator remove() method</h4>
<p>
        You can remove an entry from <code>HashMap</code> by using <code>Iterator remove()</code> method. It has following signature <code>default void remove()</code>. It removes the last element returned by the iterator from the specified collection and can be used only once for one <code>Iterator.next()</code> call.
        </p>
        <p>
        You can get <code>Map.Entry Iterator</code> by calling <code>iterator()</code> method on <code>Map entrySet()</code> method. Also this is a preferred approach to remove entry from <code>HashMap</code> as with this approach you will not get <code>ConcurrentModificationException</code>.
        </p>
</div>
    
    <div id="code">
<pre class="prettyprint">
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

// Removes entry from HashMap
public class MyClass {
    public static void main(String[] args) {
        Map&lt;String, String&gt; map = new HashMap&lt;String, String&gt;();
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        Iterator&lt;Map.Entry&lt;String, String&gt;&gt; iterator = map.entrySet().iterator();

        while (iterator.hasNext()){
            Map.Entry&lt;String, String&gt; entry = iterator.next();
            if (entry.getKey().equalsIgnoreCase("key2")) {
                iterator.remove(); // Remove entry from HashMap
            }
        }
        System.out.println("map " + map);
    } 
}</pre></div>

<div id="solution">
<h4>Output : </h4>
</div>

<div id="code"><pre class="prettyprint">map {key1=value1, key3=value3}</pre></div><br>

<div id="solution">
<p>
        If you remove an entry from <code>HashMap</code> while iterating using <code>HashMap remove()</code> method, you will get <code>ConcurrentModfiicationException</code>.
        </p>
</div>
    
    <div id="code">
<pre class="prettyprint">
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

// Removes entry from HashMap
public class MyClass {
    public static void main(String[] args) {
        Map&lt;String, String&gt; map = new HashMap&lt;String, String&gt;();
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        Iterator&lt;Map.Entry&lt;String, String&gt;&gt; iterator = map.entrySet().iterator();

        while(iterator.hasNext()){
            Map.Entry&lt;String, String&gt; entry = iterator.next();
            if ("key2".equals(entry.getKey())) {            
                map.remove("key2"); // Remove entry from HashMap
            }
        }
        System.out.println("map " + map);
    } 
}</pre></div>

<div id="solution">
<h4>Output : </h4>
</div>

<div id="code">
<pre class="prettyprint">
Exception in thread "main" java.util.ConcurrentModificationException
at java.util.HashMap$HashIterator.nextNode(Unknown Source)
at java.util.HashMap$EntryIterator.next(Unknown Source)
at java.util.HashMap$EntryIterator.next(Unknown Source)
at MyClass.main(MyClass.java:16)</pre></div><br>

    <div id="solution">
        <h4>4) Remove all the entries from HashMap by using HashMap clear()</h4>
        <p>
        You can remove all the entries from HashMap by using <code>HashMap clear()</code> method. It has following signature <code>public void clear()</code>. It removes all of the entries from the map.
        </p>
    </div>

<div id="code">
<pre class="prettyprint">
import java.util.HashMap;
import java.util.Map;

// Removes all the entries from HashMap
public class MyClass {
    public static void main(String[] args) {
        Map&lt;String, String&gt; map = new HashMap&lt;String, String&gt;();
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        map.clear();

        System.out.println("map " + map);
    }
}
</pre>
</div>

<div id="solution">
<h4>Output : </h4>
</div>

<div id="code">
<pre class="prettyprint">
map {}</pre></div>

 <br>   
References : <br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/HashMap.html#remove-java.lang.Object-">Oracle Docs HashMap remove()</a><br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/Iterator.html#remove--">Oracle Docs Iterator remove()</a><br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/HashMap.html#clear--">Oracle Docs HashMap clear() </a> <br><br>

</div>
<?php include("share.htm"); ?>
</body>
</html>
