<?php 
    include("../header.htm");
?>

<head>
    <title>Gson JsonReader and JsonWriter example</title>
	<meta name="description" content="Gson JsonReader and JsonWriter example" />
	<link rel="canonical" href="https://www.techblogss.com/java/java_json_gsonreadwrite">
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
    <div id="content">
	<div id="blog" style="float:left;">
	<div id="problem">
		<h2>Gson JsonReader and JsonWriter example</h2>
		<p>Gson provides APIs to read and write JSON as an object model or stream. The GSON JsonReader & JsonWriter use streaming model to process JSON.</p>
	</div>
	
	<div id="solution">
		<h4> To use Gson JsonReader & JsonWriter, you need to download gson-2.8.5.jar from  <a href="http://central.maven.org/maven2/com/google/code/gson/gson/2.8.5/gson-2.8.5.jar"> gson-2.8.5.jar</a></h4>
	</div>
    
    <div id="solution">
		<h4>1) JsonReader example</h4>
	</div> 
    
    <div id="code">
	<pre class="prettyprint">
import java.io.IOException;
import java.io.StringReader;

import com.google.gson.stream.JsonReader;
	
public class TestGsonJsonReader {
    public static void main(String[] args) {
        String jsonString = "{\"id\":12345, \"name\":\"Jason Bourne\", \"age\":35, "
             + "\"roles\":[\"Actor\",\"Father\"]}";
        JsonReader jsonReader = new JsonReader(new StringReader(jsonString));

        try {
            jsonReader.beginObject();
            
            while(jsonReader.hasNext()){
                String key = jsonReader.nextName(); 
                if ("id".equals(key)){
                 System.out.println(jsonReader.nextInt());
                } else if("name".equals(key)){
                    System.out.println(jsonReader.nextString());
                } else if("age".equals(key)){
                    System.out.println(jsonReader.nextInt());
                } else if("roles".equals(key)){
                    jsonReader.beginArray();
                    
                    while (jsonReader.hasNext()) {
                        System.out.println(jsonReader.nextString());
                    }
                    
                    jsonReader.endArray();
                } else {
                    jsonReader.skipValue(); 
                }
            }
            
            jsonReader.endObject();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
	</pre>
	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
    <pre class="prettyprint">
12345
Jason Bourne
35
Actor
Father
    </pre>
	</div>
	<br>
    <div id="solution">
		<h4>2) JsonWriter example</h4>
	</div> 
  
    <div id="code">
	<pre class="prettyprint">
import java.io.FileWriter;
import java.io.IOException;

import com.google.gson.stream.JsonWriter;
	
public class TestGsonJsonWriter {
    public static void main(String[] args) {
                
        try (JsonWriter writer = new JsonWriter(new FileWriter("C:\\actor.json"))) {

            writer.beginObject();                   
            writer.name("id").value(12345);    
            writer.name("name").value("Jason Bourne");         
            writer.name("age").value(35);    

            writer.name("roles");
            writer.beginArray(); 
            writer.value("Actor");                  
            writer.value("Father");                  
            writer.endArray();                      

            writer.endObject();                     

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
	</pre>
	</div>
	
	<div id="solution">
		<h4>Output actor.json: </h4>
	</div>
	
	<div id="code">
    <pre class="prettyprint">
{"id":12345,"name":"Jason Bourne","age":35,"roles":["Actor","Father"]}
    </pre>
	</div>	
	
	<!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>

    References : <br><br>
	<a href="https://sites.google.com/site/gson/streaming">Gson streaming</a><br><br>
	<a href="https://static.javadoc.io/com.google.code.gson/gson/2.8.5/com/google/gson/stream/JsonReader.html">JsonReader</a><br><br>
	<a href="https://static.javadoc.io/com.google.code.gson/gson/2.8.5/com/google/gson/stream/JsonWriter.html">JsonWriter</a>
	
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
    <?php include("share.htm"); ?>		
</body>

<?php 
    include("footer.htm");
?>

</html>
