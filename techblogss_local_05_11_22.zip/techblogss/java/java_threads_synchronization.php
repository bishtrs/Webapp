<?php 
    include("../header.htm");
?>
<!-- static Synchronization in Java -->
<head>
    <title>Thread Synchronization in Java simple example</title>
	<meta name="description" content="Thread synchronization in java simple example" />
	<link rel="canonical" href="https://www.techblogss.com/java/java_threads_synchronization">
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
	<div id="problem">
		<h1>Thread Synchronization</h1>
		<p>You can achieve thread synchronization in Java using <code>synchronized</code> keyword. You can use it in two forms: <code>synchronized</code>	blocks and <code>synchronized</code> methods.</p>
	</div>
    
    <div id="solution">
        <h4>Race Conditions</h4>
           <p>Threads share memory, and they can concurrently modify data which can lead to data corruption.
            When two or more threads are trying to access a variable and one of them wants to modify it, you get a
            problem known as a race condition.</p>
		<h4>Race Condtion example</h4>
        <p>In below example multiple threads are trying to increase the value counter variable. You may expect the counter to increase always by a value of
        one and print like 1 2 3 4..., but it may not be always possible as multiple threads can access the counter variable at the same time and increase its value.
        If you are not able to reproduce try increasing sleep time interval to 1 sec.
        </p> 
	</div>

<h4>1) Java example without using thread synchronization</h4>
	<div id="code">
	<pre class="prettyprint">
class Counter {

    private int counter;
    
    public void increaseCounter() {
        try {
            Thread.sleep(300); // Added sleep to mimic time consuming operation
        } catch (InterruptedException e) {
            e.printStackTrace();
        }    
    
        this.counter++;
        System.out.println("Counter value is " + this.counter);
    }

}    

public class CounterThread implements Runnable {
    private Counter counter;
    
    public CounterThread(Counter counter) {
        this.counter = counter;
    }

    public void run() { 
    	for (int i=0; i&lt; 5; i++) {
            counter.increaseCounter();
    	}

    }
    
    public static void main(String[] args) {
        Counter counter = new Counter();
        CounterThread counterThread = new CounterThread(counter);
        Thread thread1 = new Thread(counterThread); 
        Thread thread2 = new Thread(counterThread); 
        Thread thread3 = new Thread(counterThread); 
        thread1.start();
        thread2.start();
        thread3.start();
    }

}
	</pre>
	</div>

	<div id="solution">
		<h4>Output : </h4>
	</div>
	<div id="code">
		<pre class="prettyprint">
Counter value is 1
Counter value is 3
Counter value is 3
Counter value is 4
Counter value is 6
Counter value is 6
Counter value is 7
Counter value is 8
Counter value is 9
Counter value is 10
Counter value is 11
Counter value is 12
Counter value is 13
Counter value is 15
Counter value is 15		</pre></div><br>	

<h4>2) Example of thread synchronization in java</h4>
<p>You can easily fix above race condition problem by using <code>synchronized</code> keyword.</p>
	<div id="code">
	<pre class="prettyprint">
class Counter {

    private int counter;
    
    public synchronized void increaseCounter() {
        try {
            Thread.sleep(300); // Added sleep to mimic time consuming operation
        } catch (InterruptedException e) {
            e.printStackTrace();
        }    
    
        this.counter++;
        System.out.println("Counter value is " + this.counter);
    }

}    

public class CounterThread implements Runnable {
    private Counter counter;
    
    public CounterThread(Counter counter) {
        this.counter = counter;
    }

    public void run() { 
    	for (int i=0; i&lt; 5; i++) {
            counter.increaseCounter();
    	}

    }
    
    public static void main(String[] args) {
        Counter counter = new Counter();
        CounterThread counterThread = new CounterThread(counter);
        Thread thread1 = new Thread(counterThread); 
        Thread thread2 = new Thread(counterThread); 
        Thread thread3 = new Thread(counterThread); 
        thread1.start();
        thread2.start();
        thread3.start();
    }

}
	</pre>
	</div>

	<div id="solution">
		<h4>Output : </h4>
	</div>
	<div id="code">
		<pre class="prettyprint">
Counter value is 1
Counter value is 2
Counter value is 3
Counter value is 4
Counter value is 5
Counter value is 6
Counter value is 7
Counter value is 8
Counter value is 9
Counter value is 10
Counter value is 11
Counter value is 12
Counter value is 13
Counter value is 14
Counter value is 15	</pre></div><br>	

    <p>You can also fix above race condition problem by using <code>synchronized</code> keyword at block level.</p>
	<div id="code">
	<pre class="prettyprint">
class Counter {

    private int counter;
    
    public void increaseCounter() {
        try {
            Thread.sleep(300); // Added sleep to mimic time consuming operation
        } catch (InterruptedException e) {
            e.printStackTrace();
        }    
        
        synchronized(this) {
            this.counter++;
            System.out.println("Counter value is " + this.counter);
        }
        
    }

}       </pre></div><br>
    
    <div id="problem">
		<h1>AtomicInteger in Java</h1>
        <p>Note that marking increaseCounter() method as <code>synchronized</code> will cause performance issues as getting and releasing a 
		lock may be more time consuming than the actual work. Instead we can use <code>AtomicInteger</code> to solve the race condition.
        </p>
		
        <p>
		<code>AtomicInteger</code> is typically used in <b><i>multithreading</b></i> to achieve synchronization using <b><i>compare-and-swap (CAS)</b></i>mechanism. Atomic variables are finer-grained and lighter weight than locks and ideal to use as counters, sequence generator etc. <code>AtomicInteger</code> provides far better performance than using explicit locks where you need to update single variable of type <b><i>int</b></i> in a multithreading environment.
        </p>
      
	</div>    
    
    <h4>Below is a thread-safe replacement for the Counter class shown in the previous example:</h4>
	<div id="code">
	<pre class="prettyprint">
import java.util.concurrent.atomic.AtomicInteger;
	
class Counter {

    private AtomicInteger count = new AtomicInteger();
    
    public void increaseCounter() {
        count.getAndIncrement(); // atomic operation    
        System.out.println("count value is " + this.count);
    }

}    

public class CounterThread implements Runnable {
    private Counter counter;
    
    public CounterThread(Counter counter) {
        this.counter = counter;
    }

    public void run() { 
    	for (int i=0; i&lt; 5; i++) {
            counter.increaseCounter();
    	}
    }
    
    public static void main(String[] args) {
        Counter counter = new Counter();
        CounterThread counterThread = new CounterThread(counter);
        Thread thread1 = new Thread(counterThread); 
        Thread thread2 = new Thread(counterThread); 
        Thread thread3 = new Thread(counterThread); 
        thread1.start();
        thread2.start();
        thread3.start();
    }

}	</pre></div>

	<div id="solution">
		<h4>Output : </h4>
	</div>
	<div id="code">
		<pre class="prettyprint">
count value is 1
count value is 2
count value is 3
count value is 4
count value is 5
count value is 6
count value is 7
count value is 8
count value is 9
count value is 10
count value is 11
count value is 12
count value is 13
count value is 14
count value is 15		</pre></div><br>

     Reference: <a href="https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/atomic/AtomicInteger.html" target="_blank">Java 8 Docs AtomicInteger</a>  

    </div>
	
	 <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>	

</html>
