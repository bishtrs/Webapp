<?php 
    include("../header.htm");
?>

<head>
    <title>How to create immutable class in Java</title>
	<meta name="description" content="How to create immutable class in Java" />
	<link rel="canonical" href="https://www.techblogss.com/java/java-immutable-class">
</head>

<body>
	<?php 
		include("../navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>How to create immutable class in Java ?</h1>
        <p>An immmutable class is a class whose state can not be changed once its instance has been created. There are many immmutable classes in Java for e.g. <code>String</code> class, <code>Integer</code> class.</p>
        
        <h3>Benefits of using immmutable class:</h3>
        <p>
		<ul>
			<li>An <b><i>immutable</b></i> class is useful when you want to use object for caching purpose for e.g. in <code>HashSet</code> or key in a <code>HashMap</code> because you don’t need to worry about the value changes.</li>
			<li>An <b><i>immutable</b></i> class is inherently thread-safe.</li>
            <li><b><i>Immutable</b></i> objects are very useful in concurrent applications as their state cannot be changed state, so they cannot
            be corrupted or in consistent state if changed by multiple threads.</li>
        </ul>
        </p>
        
        <h3>To create immutable class in Java, follow these rules:</h3>
        <p>
		<ul>
		    <li><code>Class</code> should be declared as <code>final</code>, so it can't be extended.</li>
		    <li><code>Class</code> attributes should be declared as <code>final</code>.</li>
		    <li><code>Class</code> should not have any setter methods.</li>
            <li>Make all <code>class</code> attributes private.</li>
            <li>Make defensive copies of fields that are mutable and return those.</li>
		</ul>
        </p>
             
	    
	
    </div>    

    <div id="solution">
        <h4>1) Example below shows a mutable class</h4>
    </div>
    
    <p>
    In this example we are using setter method for setting the day attribute, but we should not provide settter method for day attribute as we are not supposed to change the day state.
    </p>
	
	<div id="code">
        <pre class="prettyprint">
// mutable class	
public final class MutableDay { 
    private String day;
      
    public MutableDay(String day) {
        this.day = day; 
    }
            
    public String getDay() {
        return this.day; 
    }
                    
    public void setDay(String day) {
        this.day = day;
    }
    
    public static void main(String[] args) {
        MutableDay day = new MutableDay("Monday");
        System.out.println(day.getDay());
        day.setDay("Tuesday");
        System.out.println(day.getDay());
    }
}
        </pre>
	</div>
 <div id="solution">
		<h4>Output : </h4>
	</div>   
  <div id="code">
	
	<pre class="prettyprint">
Monday
Tuesday	</pre></div><br>

    <div id="solution">
        <h4>2) Example below shows how can we make above class immutable by removing setter method for day attribute</h4>
    </div>
    
	<div id="code">
        <pre class="prettyprint">
// immutable class	
public final class ImmutableDay { 
    private final String day;
      
    public ImmutableDay(String day) {
        this.day = day; 
    }
            
    public String getDay() {
        return this.day; 
    }
                    
    public static void main(String[] args) {
        ImmutableDay day = new ImmutableDay("Monday");
        System.out.println(day.getDay());
    }
}
        </pre>
	</div>
 <div id="solution">
		<h4>Output : </h4>
	</div>   
  <div id="code">
	
	<pre class="prettyprint">
Monday
	</pre>	</div>  <br>
    
     <div id="solution">
        <h4>3) Example below shows a mutable class with List type attribute</h4>
    </div>
	<p>In this example in <b><i>getDays()</b></i> we should not return original copy of days <code>List</code>, as it can be modifled by someone. Also you should not provide setter method for days <code>List</code> as someone can modify the days <code>List</code>.
    </p>
	
    <div id="code">
        <pre class="prettyprint">
import java.util.List;
import java.util.ArrayList;
        
// mutable class	
public final class MutableDay { 
    private List&lt;String&gt; days; 
      
    public MutableDay(List&lt;String&gt; days) {
        this.days = days;
    }
            
    public List&lt;String&gt; getDays() {
        return this.days; 
    }
                    
    public void setDays(List&lt;String&gt; days) {
        this.days = days;
    }
    
    public static void main(String[] args) {
        List&lt;String&gt; days = new ArrayList&lt;String&gt();
        days.add("Monday");
        days.add("Tuesday");
        days.add("Wednesday");
        MutableDay day = new MutableDay(days);
        days = day.getDays();
        System.out.println(days);
        days.remove("Wednesday");
        System.out.println(day.getDays());
    }
}
        </pre>
	</div>
    
 <div id="solution">
		<h4>Output : </h4>
	</div>   
  <div id="code">
	
	<pre class="prettyprint">
[Monday, Tuesday, Wednesday]
[Monday, Tuesday]	</pre></div><br>

	<div id="solution">
        <h4>4) Example below shows how to make above class immutable by creating a copy of days <code>List</code> when returning it and removing the setter method for days <code>List</code></h4>
    </div>
	
	<div id="code">
        <pre class="prettyprint">
// immutable class	
import java.util.List;
import java.util.ArrayList;
	
public final class ImmutableDay { // immutable class should be final 
    private final List&lt;String&gt; days;  // immutable class attributes should be final
      
    public ImmutableDay(List&lt;String&gt; days) {
        this.days = days;
    }
            
    // return copy of days instead of actual data
    public List&lt;String&gt; getDays() {
         return new ArrayList&lt;String&gt;(this.days); 
    }
            
    public static void main(String[] args) {
        List&lt;String&gt; days = new ArrayList&lt;String&gt;();
        days.add("Monday");
        days.add("Tuesday");
        days.add("Wednesday");
        ImmutableDay day = new ImmutableDay(days);
        days = day.getDays();
        System.out.println(days);
        days.remove("Wednesday");
        System.out.println(day.getDays());
    }
}        </pre>	</div>

 <div id="solution">
		<h4>Output : </h4>
	</div>   
  <div id="code">
	
	<pre class="prettyprint">
[Monday, Tuesday, Wednesday]
[Monday, Tuesday, Wednesday]	</pre>	</div>   <br>
    
    <div id="solution">
        <h4>5) Example below shows a mutable class with Date type attribute.</h4>
    </div>
	<p>
    In this example in <b><i>getPublishedDate()</b></i> method we should not return exact copy of publishedDate, as it can be modifled by someone. 
    </p>
	
    <div id="code">
        <pre class="prettyprint">
import java.util.Date;
        
// mutable class	
public final class MutableBook { 
    private String bookName;
    private Date publishedDate;
      
    public MutableBook(String bookName, Date publishedDate) {
        this.bookName = bookName;
        this.publishedDate = publishedDate;
    }
            
    public String getBookName() {
        return this.bookName; 
    }
                    
    public Date getPublishedDate() {
        return this.publishedDate; 
    }
    
    public static void main(String[] args) {
        MutableBook book = new MutableBook("Lord of the Rings" , new Date(1997, 10, 01));
        System.out.println(book.getBookName());
        Date publishedDate = book.getPublishedDate();
        System.out.println("Actual published date " + publishedDate);
        publishedDate.setYear(2018);
        System.out.println("Modified published date " + book.getPublishedDate());
    }
}
        </pre>
	</div>
 <div id="solution">
		<h4>Output : </h4>
	</div>   

  <div id="code">
	
	<pre class="prettyprint">
Lord of the Rings
Actual published date Mon Nov 01 00:00:00 IST 3897
Modified published date Fri Nov 01 00:00:00 IST 3918	</pre></div><br>
	
    <div id="solution">
        <h4>6) Example below shows how to create immutable class in Java with <code>Date</code> type attribute.</h4>
        <p>In this example we return a copy of publishedDate instead of returning the actual publishedDate instance. The caller of this method can't modify the original <code>Date</code> object.</p>
    </div>
	
	<div id="code">
        <pre class="prettyprint">
import java.util.Date;
        
// immutable class	
public final class ImmutableBook { 
    private String bookName;
    private Date publishedDate;
      
    public ImmutableBook(String bookName, Date publishedDate) {
        this.bookName = bookName;
        this.publishedDate = publishedDate;
    }
            
    public String getBookName() {
        return this.bookName; 
    }
                    
    public Date getPublishedDate() {
        return new Date(publishedDate.getTime());
    }
    
    public static void main(String[] args) {
        ImmutableBook book = new ImmutableBook("Lord of the Rings" , new Date(1997, 10, 01));
        System.out.println(book.getBookName());
        Date publishedDate = book.getPublishedDate();
        System.out.println("Actual published date " + publishedDate);
        publishedDate.setYear(2018);
        System.out.println("Modified published date " + book.getPublishedDate());
    }
}        </pre>	</div>

    <div id="solution">
		<h4>Output : </h4>
	</div>   
    
    <div id="code">
	
	<pre class="prettyprint">
Lord of the Rings
Actual published date Mon Nov 01 00:00:00 IST 3897
Modified published date Mon Nov 01 00:00:00 IST 3897	</pre></div><br>
	
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
    
	References : <br><br>
    <a href="https://docs.oracle.com/javase/tutorial/essential/concurrency/immutable.html">Oracle Docs Immutable objects</a>	<br><br>
    <a href="https://docs.oracle.com/javase/8/docs/api/java/lang/String.html">Oracle Docs String class </a> <br><br>		

	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->

    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>

    <?php include("share.htm"); ?>		
</body>

<?php 
    include("footer.htm");
?>

</html>
