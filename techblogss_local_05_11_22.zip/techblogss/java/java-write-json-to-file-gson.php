<?php include("../header.htm");?>

<head>
    <title>Write JSON to file Java Gson</title>
	<meta name="description" content="Write JSON to file Java Gson" />
	<link rel="canonical" href="https://www.techblogss.com/java/java-write-json-to-file-gson">
</head>

<body>
	<?php include("../navigation.htm");	?>
   	
    <div id="content">
    <div id="blog">
	<div id="problem">
		<h2>Write JSON to file in Java using Gson</h2>
	</div>
    
    <p>In this example we will create a Java object and then write it to a file in <code>JSON</code> format using <code>Gson</code> library.</p>
	
	<div id="solution">
        <h4>To parse JSON using Gson library, you need to use gson-2.9.0 jar</h4>
    </div>

<div id="code"><pre class="prettyprint">
&lt;dependency>
    &lt;groupId>com.google.code.gson&lt;/groupId>
    &lt;artifactId>gson&lt;/artifactId>
    &lt;version>2.9.0&lt;/version>
&lt;/dependency></pre></div><br>    
       
    <div id="solution">
		<h4>Java class used to represent the JSON</h4>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
import java.util.List;
    
public class Student {
    
    private int id;
    private String name;
    private int age;
    private List&lt;String&gt; emailaddress;
        
    // removed getter and setter      
    
    @Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ","
            +" age=" + age + ", emailaddress=" + emailaddress + "]";
	}    
    
}    </pre></div><br>
 
	
    <div id="solution">
		<h4>Create Java object and write it to file in JSON format.</h4>
	</div>
  
    <div id="code">
	<pre class="prettyprint">
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
	
public class TestGsonFileWriter {
    public static void main(String[] args) {
                
        Student student = new Student();
        student.setId(123);
        student.setName("George Bush");
        student.setAge(40);
        
        List&lt;String&gt; emailaddress = new ArrayList&lt;&gt;();
        emailaddress.add("jbush@yahoo.com");
        emailaddress.add("jbush@gmail.com");
        student.setEmailaddress(emailaddress);
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        
        try (FileWriter writer = new FileWriter("E:\\student.json")) {
            gson.toJson(student, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}	</pre></div><br>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
    <p>If you see under E: or whatever directory you use to write JSON file, you will see below JSON file is generated</p>
	
	<div id="code">
    <pre class="prettyprint">
{
  "id": 123,
  "name": "George Bush",
  "age": 40,
  "emailaddress": [
    "jbush@yahoo.com",
    "jbush@gmail.com"
  ]
}    </pre></div>	

	
	
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    
    <br>    
        
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->    
</body>

<?php 
    include("footer.htm");
?>

</html>
