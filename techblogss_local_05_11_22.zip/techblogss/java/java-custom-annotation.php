<?php include("../header.htm");?>
<head>
    <title></title>
	<meta name="description" content="Java custom annotation example" />
    <link rel="canonical" href="https://www.techblogss.com/java/java-custom-annotation" />
</head>

<body>
	<?php include("../navigation.htm");?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>Java custom annotation example</h1>
        
	</div>
	<div id="solution">
		<p>
        <code>Annotations</code> were introduced in Java 1.5 version. They are used to provide metadata for a field, method or Class.
        They are defined as interface and converted to implementation classes by JVM nehind the scene.
        </p>        
        <p>
        <code>Annotations</code> eliminate the need to use XML for providing metadata about the classes. Also using <code>Annotation</code>
        you can avoid creating large number of classes. For example suppose we have a Person class, and we want to describe what kind of
        profession he is in, you don't need to create seperate class for each Profession like Doctor, Engineer or Player.
        We can create a custom <code>Annotation</code> @Profession to describe his profession and provide the type of profession.
        The example below describes how to create a custom <code>Annotation</code>.
        </p>
	</div>
    
    <h4>1) Class level Custom Annotation</h4>
    <p>This example shows how to create a custom annotation at class level and then how to use its value.</p>

	<div id="code">
	<pre class="prettyprint">
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface IsSerializable {
    public String type() default "";
}	</pre></div>

<div id="code">
	<pre class="prettyprint">
import java.lang.annotation.Annotation;

@IsSerializable(type="no")
public class TestClassLevelAnnotation {

	public static void main(String[] args) {
        Class&lt;TestClassLevelAnnotation> obj = TestClassLevelAnnotation.class;
        if (obj.isAnnotationPresent(IsSerializable.class)) {

            Annotation annotation = obj.getAnnotation(IsSerializable.class);
            IsSerializable isSerializable = (IsSerializable) annotation;

            System.out.println("IsSerializable type : " +  isSerializable.type());
        }
    }
}	</pre></div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code"><pre class="prettyprint">IsSerializable type : no</pre></div><br>
    
    <h4>2) Field level Custom Annotation</h4>
    <p>
    This example shows how to create a custom annotation at field level. Note that if you don't mention default for the method
    in the annotation interface, then that annotation attribute becomes mandatory. In this example "fit" is mandatory attribute.
    </p>

	<div id="code">
	<pre class="prettyprint">
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface Player {
    public String value() default "";
    public boolean fit();
}</pre></div>

<div id="code">
	<pre class="prettyprint">
import java.lang.reflect.Field;

public class TestFieldLevelAnnotation {

    @Player(value="footballer", fit=true)
    private Person person1;

    @Player(value="cricketer", fit=false)
    private Person person2;
	
    @Player(fit=false)
    private Person person3;

    public static void main(String[] args) {
        TestFieldLevelAnnotation test = new TestFieldLevelAnnotation();
        for (Field field : test.getClass().getDeclaredFields()) {
            Player player = field.getAnnotation(Player.class);
            System.out.println("player :" + player.value());
            System.out.println("fit: " + player.fit());
        }
    }
}	</pre></div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code"><pre class="prettyprint">
player :footballer
fit: true
player :cricketer
fit: false
player :
fit: false</pre></div><br>

    <h4>3) Method level Custom Annotation</h4>
    <p>
    This example shows how to create a custom annotation at method level. We will create @LogCurrentTime annotation which accepts boolean type
    attribute logTime. If a method is annotated with logTime=true, then the method will print current time.
    </p>

	<div id="code">
	<pre class="prettyprint">
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface LogCurrentTime {
    public boolean logTime() default false;
}</pre></div>

<div id="code">
	<pre class="prettyprint">
import java.lang.reflect.Method;

public class TestMethodLevelAnnotation {

    public static void main(String[] args) {
        TestMethodLevelAnnotation test = new TestMethodLevelAnnotation();
        Method method = null;
        try {
            method = test.getClass().getMethod("print");
        } catch (NoSuchMethodException  | SecurityException e) {
            e.printStackTrace();
        }

        LogCurrentTime ml = method.getAnnotation(LogCurrentTime.class);
        System.out.println("value is: " + ml.logTime());
        if (ml.logTime()) {
            System.out.println(System.currentTimeMillis());
        }
		
        try {
            method = test.getClass().getMethod("print2");
        } catch (NoSuchMethodException  | SecurityException e) {
            e.printStackTrace();
        }

        ml = method.getAnnotation(LogCurrentTime.class);
        System.out.println("value is: " + ml.logTime());
        if (ml.logTime()) {
            System.out.println(System.currentTimeMillis());
        }
    }

    @LogCurrentTime(logTime=true)
    public void print() {
        System.out.println("hello");
    }
	
    @LogCurrentTime(logTime=false)
    public void print2() {
        System.out.println("hello");
    }

}	</pre></div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code"><pre class="prettyprint">
player :footballer
fit: true
player :cricketer
fit: false
player :
fit: falsevalue is: true
1646383432888
value is: false</pre></div><br>
    
            
     <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>

   
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
	
</body>

<?php 
    include("footer.htm");
?>

</html>
