<?php 
    include("../header.htm");
?>

<head>
    <title>Java forEach continue break</title>
	<meta name="description" content="this tutorial explains how to continue and break in Java forEach loop" />
    <link rel="canonical" href="https://www.techblogss.com/java/java_cj_foreach_continue" />
</head>


<body>
	<?php 
		include("navigation.htm");
	?>
   	<div id="content" >
    <div id="blog">
	<div id="problem">
		<h1>Java forEach continue</h1>
            <b><i>continue</b></i> inside loop is not supported by <b><i>forEach</b></i>. As a workaround you can return from the loop.
	</div>
	<div id="solution">
		<h2>1) Java 8 forEach continue</h2>
	</div>
	<div id="code">
	<pre class="prettyprint">
// shows how to continue in a forEach loop
import java.util.ArrayList;
import java.util.List;
	
public class TestClass { 
    public static void main(String[] args) {
        List&lt;String&gt; fruits = new ArrayList&lt;&gt;();
        fruits.add("mango");
        fruits.add("apple");
        fruits.add("pineapple");
        fruits.add("orange");
        
        fruits.stream().forEach(str -> {
            if (str.equals("pineapple")) {
                return;
            }
            System.out.println(str);
        });
        
    }
}  
	</pre>
	</div>

<div id="solution">
		<b>Output : </b>
	</div>
	
	<div id="code">
    <pre class="prettyprint">
mango
apple
orange
    </pre>
	</div>	
	<div id="comments">
	</div>
	
	<div id="solution">
		<h2>2) Java 8 forEach break</h2>
	</div>
    <b><i>break</b></i> from loop is not supported by <b><i>forEach</b></i>. If you want to break out of forEach loop, you need to throw Exception.
	<div id="code">
	<pre class="prettyprint">
// shows how to break out of forEach loop
import java.util.ArrayList;
import java.util.List;
	
public class TestClass { 
    public static void main(String[] args) {
        try {
            List&lt;String&gt; fruits = new ArrayList&lt;&gt;();
            fruits.add("mango");
            fruits.add("apple");
            fruits.add("pineapple");
            fruits.add("orange");
            
            fruits.stream().forEach(fruit -> {
                if (fruit.equals("pineapple")) {
                    throw new RuntimeException();
                }
                System.out.println(fruit);
            });
        } catch (Exception e) {}
	
    }
}  
	</pre>
	</div>
<div id="solution">
		<b>Output : </b>
	</div>
	
	<div id="code">
    <pre class="prettyprint">
mango
apple
    </pre>
	</div>	
	<br>
   
   <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
<br>

     
References : <a href="https://docs.oracle.com/javase/8/docs/api/java/lang/Iterable.html#forEach-java.util.function.Consumer-" target="_blank">https://docs.oracle.com/javase/8/docs/api/java/lang/Iterable.html#forEach-java.util.function.Consumer-</a> 

    </div> <!-- blog div-->
	
	<!-- ADU1 -->
    <?php include("../sidebar/sidebar.htm"); ?>   <br><br>
	
	</div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
    <?php include("share.htm"); ?>

</body>

<?php 
    include("footer.htm");
?>
</html>
