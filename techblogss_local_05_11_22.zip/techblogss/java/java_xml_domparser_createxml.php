<?php 
    include("../header.htm");
?>

<head>
    <title>How to create XML file in Java using DOM parser</title>
	<meta name="description" content="How to create XML file in Java using DOM parser" />
	<link rel="canonical" href="https://www.techblogss.com/java/java_xml_domparser_createxml" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>

    <div id="content">
	<div id="blog" style="float:left;">
	<div id="problem">
		<h1>Create XML file in Java using DOM parser</h1>
        You can create or write a XML file using <b><i>DOM</b></i> Parser. First you will create a transformer object to wire a DOMSource to a StreamResult.
        You will then invoke the transformer's transform() method to write out the <b><i>DOM</b></i> as XML data.<br>
        <h2>1) Create XML file with nodes and text value:
	</div>
	
	<div id="solution">
		XML file that you want to create: <b>employees.xml</b>
	</div>
	<br>
	
	<div id="code">
	
	<pre class="prettyprint">
&lt;?xml version="1.0"?>    
&lt;employees>
    &lt;employee>
	&lt;firstname>Mohit&lt;/firstname>
	&lt;lastname>Bisht&lt;/lastname>
    &lt;/employee>
    &lt;employee>
        &lt;firstname>Samit&lt;/firstname>
        &lt;lastname>Ahlawat&lt;/lastname>
    &lt;/employee>
&lt;/employees>
	</pre>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// Creates XML file using Java DOM parser
import java.io.File;
 
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
 
import org.w3c.dom.Document;
import org.w3c.dom.Element;
				
public class WriteXMLDOMParser {
    public static void main(String[] args) {
        try {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.newDocument();
                
            Element rootElement = doc.createElementNS("", "employees");
            doc.appendChild(rootElement);
                
            rootElement.appendChild(createElement(doc, "Mohit", "Bisht"));
            rootElement.appendChild(createElement(doc, "Samit", "Ahlawat"));
                
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
                
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            DOMSource source = new DOMSource(doc);
                
            StreamResult console = new StreamResult(System.out);
            StreamResult file = new StreamResult(new File("E:\\employees.xml"));
                
            transformer.transform(source, console);
            transformer.transform(source, file);
                
        } catch (Exception e) {
            e.printStackTrace();
        } 

    }
        
    private static Element createElement(Document doc, String firstname, String lastname) {
        Element employee = doc.createElement("Employee");
               
        Element node1 = doc.createElement("firstname");
        node1.appendChild(doc.createTextNode(firstname));
                
        employee.appendChild(node1);
                
        Element node2 = doc.createElement("lastname");
        node2.appendChild(doc.createTextNode(lastname));
                
        employee.appendChild(node2);
            
        return employee;
    }
}
	</pre>
	</div>
   
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
    <pre class="prettyprint">
&lt;?xml version="1.0"?>    
&lt;employees>
    &lt;employee>
	&lt;firstname>Mohit&lt;/firstname>
	&lt;lastname>Bisht&lt;/lastname>
    &lt;/employee>
    &lt;employee>
        &lt;firstname>Samit&lt;/firstname>
        &lt;lastname>Ahlawat&lt;/lastname>
    &lt;/employee>
&lt;/employees>
    </pre>
	</div>
    
<br>

<div id="problem">
        <h2>2) Create elements with multiple attributes in XML file:
	</div>

	<div id="solution">
		XML file that you want to create: <b>employees.xml</b>
	</div>
	
	<div id="code">
	
	<pre class="prettyprint">
&lt;?xml version="1.0"?>    
&lt;employees>
    &lt;employee department="hr", id="123">
	&lt;firstname>Mohit&lt;/firstname>
	&lt;lastname>Bisht&lt;/lastname>
    &lt;/employee>
    &lt;employee department="finance" id="456">
        &lt;firstname>Samit&lt;/firstname>
        &lt;lastname>Ahlawat&lt;/lastname>
    &lt;/employee>
&lt;/employees>
	</pre>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
import java.io.File;
 
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
 
import org.w3c.dom.Document;
import org.w3c.dom.Element;
				
public class WriteXMLDOMParser {
    public static void main(String[] args) {
        try {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.newDocument();
                
            Element rootElement = doc.createElementNS("", "employees");
            doc.appendChild(rootElement);
                
            rootElement.appendChild(createElement(doc, "123", "hr", "Mohit", "Bisht"));
            rootElement.appendChild(createElement(doc, "456", "finance", "Samit", "Ahlawat"));
                
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
                
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            DOMSource source = new DOMSource(doc);
                
            StreamResult console = new StreamResult(System.out);
            StreamResult file = new StreamResult(new File("E:\\employees.xml"));
                
            transformer.transform(source, console);
            transformer.transform(source, file);
                
        } catch (Exception e) {
                e.printStackTrace();
        } 

    }
        
    private static Element createElement(Document doc, String id, String department,
            String firstname, String lastname) {
        
        Element employee = doc.createElement("employee");
        employee.setAttribute("id", id);
        employee.setAttribute("department", department);
                
        Element node1 = doc.createElement("firstname");
        node1.appendChild(doc.createTextNode(firstname));
                
        employee.appendChild(node1);
               
        Element node2 = doc.createElement("lastname");
        node2.appendChild(doc.createTextNode(lastname));
                
        employee.appendChild(node2);
            
        return employee;
    }
}
	</pre>
	</div>
   
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
    <pre class="prettyprint">
&lt;?xml version="1.0"?>    
&lt;employees>
    &lt;employee department="hr" id="123">
	&lt;firstname>Mohit&lt;/firstname>
	&lt;lastname>Bisht&lt;/lastname>
    &lt;/employee>
    &lt;employee department="finance" id="456">
        &lt;firstname>Samit&lt;/firstname>
        &lt;lastname>Ahlawat&lt;/lastname>
    &lt;/employee>
&lt;/employees>
    </pre>
	</div>
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    
 <br>
	References: <br>
    <a href="https://docs.oracle.com/javase/tutorial/jaxp/xslt/writingDom.html">https://docs.oracle.com/javase/tutorial/jaxp/xslt/writingDom.html</a>
    <br>	

    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
	
	<div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    <?php include("share.htm"); ?>
    
</body>

<?php 
    include("footer.htm");
?>
</html>
