<?php 
    include("../header.htm");
?>

<head>
    <title>Java array sort examples</title>
	<meta name="description" content="Java array sort examples using Arrays sort(), using Comparator, sort array in descending order in java ." />
	<link rel="canonical" href="https://www.techblogss.com/java/java_sortarray" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
	<div id="problem">
		<h1>Java array sort examples</h1>
	</div>
	<div id="solution">
		<h4>1) Sort array of int using Arrays sort() </h4>
        <p>You can sort array of int using <b><i>Arrays sort(int[])</b></i> method.
        It sorts the specified array into ascending numerical order & has time complexity of O(n log(n)).</p> 
	</div>
	<div id="code">
    <pre class="prettyprint">
import java.util.Arrays;

// Sorts an array of int   
public class MyClass {
    public static void main(String[] args) {
        int[] arr = {13, 8, 4, 6, 21, 102}; 
        Arrays.sort(arr); 
        
        System.out.printf("Sorted arr[] : %s", Arrays.toString(arr));
    }
}
    </pre>
	</div>

<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Sorted arr[] : [4, 6, 8, 13, 21, 102]
		</pre>
	</div>	
	
    <div id="solution">
		<h4>2) Sort sub array of int array using Arrays sort(int[] a, int fromIndex, int toIndex) </h4>
        <p>You can sort sub array of int using <b><i>Arrays sort()</b></i> method.
        It sorts the specified range of the array into ascending order. 
        The range to be sorted extends from the index fromIndex, inclusive, to the index toIndex, 
        exclusive & has time complexity of O(n log(n)). </p>
	</div>
	<div id="code">
    <pre class="prettyprint">
import java.util.Arrays;

// Sorts sub array of int array
public class MyClass {
    public static void main(String[] args) {
        int[] arr = {13, 8, 4, 6, 21, 102}; 
        Arrays.sort(arr, 1, 5); 
        
        System.out.printf("Sorted arr[] : %s", Arrays.toString(arr));
    }
}
    </pre>
	</div>

<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Sorted arr[] : [13, 4, 6, 8, 21, 102]
		</pre>
	</div>	

    <div id="solution">
		<h4>3) Sort array in descending order using Arrays sort(T[] a, Comparator&lt;&ques; super T&gt; c)</h4>
        <p>You can sort sub array of int using <b><i>Arrays sort(T[] a, Comparator&lt;&ques; super T&gt; c)</b></i> method. 
        It sorts the specified array of objects according to the order induced by the specified comparator.<br><br>
        Below example shows how to sort array in descending order</p>
	</div>
	<div id="code">
    <pre class="prettyprint">
import java.util.Arrays;
import java.util.Collections;

// Sorts array in descending order   
public class MyClass {
    public static void main(String[] args) {
        Integer[] arr = {13, 8, 4, 6, 21, 102}; 
        Arrays.sort(arr, Collections.reverseOrder()); // sorts Array by name
		
        System.out.printf("Sorted arr[] : %s", Arrays.toString(arr));
    }
}
    </pre>
	</div>

<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Sorted arr[] : [102, 21, 13, 8, 6, 4]
		</pre>
	</div>	

	<div id="solution">
		<h4>5) Sort array of String using Arrays sort() </h4>
        <p>You can sort array of String using <b><i>Arrays sort(Object[])</b></i> method.
        It sorts the specified array of objects into ascending order, according to the natural ordering of its elements.</p> 
	</div>
	<div id="code">
    <pre class="prettyprint">
import java.util.Arrays;

// Sorts an array of String   
public class MyClass {
    public static void main(String[] args) {
        String[] arr = {"John", "Chad", "Zach"}; 
        Arrays.sort(arr); 
        
        System.out.printf("Sorted arr[] : %s", Arrays.toString(arr));
    }
}
    </pre>
	</div>

<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Sorted arr[] : [Chad, John, Zach]
		</pre>
	</div>	
    
	<div id="solution">
		<h4>5) Sort an array of custom class objects using Collections sort(T[] a, Comparator&lt;&ques; super T&gt; c)</h4>
        <p>In this example, we write a Celebrity class whose objects can be sorted by various Class attributes using Comparator interface.
        In the sort implementation, you need to implement Comparator compareTo() method. It has following signature :   
        <b><i>int compare(T o1,T o2)</b></i>.<br><br>
        </p>
	</div>
	<div id="code">
    <pre class="prettyprint">
import java.util.Arrays;
import java.util.Comparator;

class Celebrity {
    private String name;
    private int rank;
    private int networth;
	
    Celebrity (String name, int rank, int networth) {
        this.name = name;
        this.rank = rank;
        this.networth = networth;
    }
	
    public String getName() {
        return name;
    }
	
    public int getRank() {
        return rank;
    }
	
    public int getNetworth() {
        return networth;
    }
	
    @Override
    public String toString() {
        return "Celebrity [name=" + name + ", rank=" + rank + ", networth="
            + networth + "]";
    }	
}

// Sorts Array of Celebrity objects using Comparator by networth of the celebritiy.			
class CelebrityComparator implements Comparator&lt;Celebrity&gt; {
		
    public int compare(Celebrity cel1, Celebrity cel2) {
        return (cel1.getNetworth() &lt; cel2.getNetworth()) ?
            -1 : ((cel1.getNetworth() == cel2.getNetworth()) ? 0 : 1);
    }
}
			
public class MyClass {
    public static void main(String[] args) {
        Celebrity[] celebrities = new Celebrity[3];
        celebrities[0] = new Celebrity("Charlie Sheen", 1, 100000);
        celebrities[1] = new Celebrity("Kate Backinsale", 3, 2000000);
        celebrities[2] = new Celebrity("Tom Cruise", 2, 50000);

        System.out.println("Before sorting");
        for (Celebrity celebritiy : celebrities)
            System.out.println(celebritiy);		

        Arrays.sort(celebrities, new CelebrityComparator()); // Sort Array by networth
		
        System.out.println("After sorting"); 	
        for (Celebrity celebritiy : celebrities)		
            System.out.println(celebritiy);		
    }
}
    </pre>
	</div>
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Before sorting
Celebrity [name=Charlie Sheen, rank=1, networth=100000]
Celebrity [name=Kate Backinsale, rank=3, networth=2000000]
Celebrity [name=Tom Cruise, rank=2, networth=50000]
After sorting
Celebrity [name=Tom Cruise, rank=2, networth=50000]
Celebrity [name=Charlie Sheen, rank=1, networth=100000]
Celebrity [name=Kate Backinsale, rank=3, networth=2000000]
		</pre>
	</div>
	
	<div id="comments">
		<h4>Comments on above approach:</h4>
		<ul>
            <li>You should use Comparator interface for sorting when you want to sort an array of Object by different attributes of a Class.</li>
			<li>The Class whose array needs to ne sorted is not tied to Comparator interface and you can change the Comparator implementation on the fly.</li>
			<li>You can use Comparator interface to sort array of Objects of a Class that can't be modified, e.g. third party library class.</li>
        </ul>
	</div>

References : <br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/Arrays.html#sort-int:A-">Oracle Docs Arrays sort(int[])</a>	<br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/Arrays.html#sort-int:A-int-int-">Oracle Docs Arrays sort(int[] a, int fromIndex, int toIndex) </a> <br><br>		
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/Arrays.html#sort-T:A-java.util.Comparator-">Oracle Docs Arrays sort(T[] a, Comparator&lt;&quest; super T> c)</a> <br><br>		
	</div>
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>	

</html>
