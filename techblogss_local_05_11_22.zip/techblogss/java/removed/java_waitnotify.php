<?php 
    include("../header.htm");
?>

<head>
    <title>wait and notify in Java</title>
	<meta name="description" content="wait and notify in Java, wait notify example." />
    <link rel="canonical" href="https://www.techblogss.com/java/java_waitnotify" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
	<div id="blog" style="float:left;">
	<div id="problem">
		<h1>Examples of wait and notify in Java</h4>
	</div>
	<div id="solution">
		<h4>1) Example of wait and notify using two threads</h4>
		In below example one thread (Thread2) does some calculation while other thread (Thread1) waits for Thread 2 to complete the calculation.
        Once calculation is over, waiting thread (Thread1) gets notification from Thread 2 using <b><i>notify()</b></i> method.
		</p>
	</div>
	<div id="code">
	<pre class="prettyprint">
public class Thread1 {
    public static void main(String[] args) {
        Thread2 thread2 = new Thread2();
        thread2.start();

        synchronized (thread2) {
            System.out.println("Waiting for  thread2 to complete..."); 
            try {
                thread2.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("Got notification, wait over");
    }
   
}

class Thread2 extends Thread {
    private int sum;

    public void run() {
        synchronized(this) {
            for (int i=0; i&lt;5; i++) {
               sum += i; 
            }  
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }   
            System.out.println("Notifying waiting threads...");            
            notify();
        }
    }
}
	</pre>	
	</div>

<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Waiting for  thread2 to complete...
Notifying waiting threads...
Got notification, wait over
		</pre>
	</div>
<br>
	
<div id="solution">
		<h4>2) Example of wait and notify as Producer Consumer problem</h4>
		<p>In below example one thread (Producer) produces data to be consumed by Consumer thread. The Consumer thread waits for Producer to produce the data by
		calling wait() method and the Producer thread calls notify() method to communicate to Consumer thread that data is ready to be consumed.
		</p>
</div>
		<div id="code">
	<pre class="prettyprint">
class Data {
    private int data;
    private volatile boolean consume = false;

    public synchronized void setData(int data) {
        if (!consume) {
            consume = false;
            this.data = data;
            this.notify();
        } else {
            try {
                this.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public synchronized int getData() {
        if (!consume) {
            try {
                this.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        } else {
            consume = true;
            this.notify();
        }
        return data;
    }
}

class Producer implements Runnable {
    private Data data;

    Producer(Data data) {
        this.data = data;
    }

    public void run() {
        int counter = 0;
        
        while(true) {
            System.out.println("Generating data, please wait...");
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
			System.out.println("Generated data " + (counter));
            data.setData(counter);
            counter++;
        }
    }
}

class Consumer implements Runnable {
    private Data data;

    Consumer(Data data) {
        this.data = data;
    }

    public void run() {
        while(true) {
            System.out.println("Got data..."  + data.getData());
        }
   }
}
	
public class WaitNotify {
    public static void main(String[] args) {
        Data data = new Data();
		
        Producer producer = new Producer(data);
        Thread producerThread = new Thread(producer);
        Consumer consumer = new Consumer(data);
        Thread consumerThread = new Thread(consumer);
		
        consumerThread.start();
        producerThread.start();
    }
}
	</pre>	
	</div>

<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Generating data, please wait...
Generated data 0
Generating data, please wait...
Got data...0
Generated data 1
Generating data, please wait...
Got data...1
Generated data 2
Generating data, please wait...
Got data...2
Generated data 3
Generating data, please wait...
Got data...3
Generated data 4
Generating data, please wait...
Got data...4
Generated data 5
Generating data, please wait...
Got data...5
Generated data 6
Got data...6
Generating data, please wait...
		</pre>
	</div>
	<br>
    
	<div id="solution">
		<h4>3) Example of wait() and notifyAll()</h4>
		In below example one thread (Calculator) does some calculation while other threads (of type Thread2) wait for Calculator thread to 
        complete the calculation, which then notifies all the waiting threads using <b><i>notifyAll()</b></i> method.
		</p>
	</div>
	<div id="code">
	<pre class="prettyprint">
public class Thread1 extends Thread {
    Calculator calculator;
	
    public Thread1(Calculator calculator) {
        this.calculator = calculator;
    }
	
    public void  run() {
        synchronized (calculator) {
            System.out.println("Waiting for calculator to complete..."); 
            try {
                calculator.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("Got notification, wait over");
    }
	
    public static void main(String[] args) {
        Calculator calculator = new Calculator();
        new Thread1(calculator).start();
        new Thread1(calculator).start();
        new Thread1(calculator).start();
        new Thread1(calculator).start();
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }   
        calculator.start();
    }
	   
}

class Calculator extends Thread {
    private int sum;

    public void run() {
        synchronized(this) {
            for (int i=0; i&lt;5; i++) {
               sum += i; 
            }  
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }   
            System.out.println("Notifying waiting threads...");            
            notifyAll();
        }
    }
}
	</pre>	
	</div>

<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Waiting for  calculator to complete...
Waiting for  calculator to complete...
Waiting for  calculator to complete...
Waiting for  calculator to complete...
Notifying waiting threads...
Got notification, wait over
Got notification, wait over
Got notification, wait over
Got notification, wait over
		</pre>
	</div>
<br>    
	
	 <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>

References : <br>
	<ul>
		<li><a href="https://docs.oracle.com/javase/8/docs/api/java/lang/Object.html#wait--" target="_blank">Oracle Docs wait()  </a>	</li><br>
		<li><a href="https://docs.oracle.com/javase/8/docs/api/java/lang/Object.html#notify--" target="_blank">Oracle Docs notify()  </a>	</li><br>
		<li><a href="https://docs.oracle.com/javase/8/docs/api/java/lang/Object.html#notifyAll--" target="_blank">Oracle Docs notifyAll()</a>	<br><br></li>	
	</ul>

	 </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
	
</body>

<?php 
    include("footer.htm");
?>
</html>
