<?php 
    include("../header.htm");
?>

<head>
    <title>Java 8 write to file</title>
	<meta name="description" content="Java 8 write to file, how to write to file in java, java write string to file." />
    <link rel="canonical" href="https://www.techblogss.com/java/java_j8_writefile" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	<div id="content" >
	<div id="problem">
		<h1>Java 8 write to file</h1>
	</div><br>
	
	<div id="solution">
		<h2>1) Write String to File using Files write(Path path) method.</h2>
	</div>

    <div id="code">
	<pre class="prettyprint">
// Writes String to file
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class TestWriteFile {

    public static void main(String args[]) {
        String content = "this blog is about java 8 write file";

        try {
            Files.write(Paths.get("C://Data.txt"), content.getBytes());
        } catch (IOException e1) {
            e1.printStackTrace();
        }

    }
}		</pre>
	</div>

    <div id="solution">
		<h3>Output : </h3>
     </div>
	
	<div id="code">
		<pre class="prettyprint">
1 this blog is about java 8 write file
2 this blog is about java 8 write file
3 this blog is about java 8 write file        </pre>
	</div>	<br>
    
	<div id="solution">
		<h4>2) Write String to file using Files newBufferedWriter(Path path) method.</h4>
	</div>

    
<div id="code">
		<pre class="prettyprint">
// Writes String to File
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class TestWriteFile {

    public static void main(String args[]) {
        String content = "this blog is about java 8 write file";
        
        try (BufferedWriter writer = Files.newBufferedWriter(Paths.get("C://Data.txt"))) {
            writer.write(content);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}	</pre>
	</div>

 <br>

References : <br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/nio/file/Files.html">Oracle Docs Files</a>	<br><br>
<a href ="https://docs.oracle.com/javase/8/docs/api/java/nio/file/Files.html#write-java.nio.file.Path-byte:A-java.nio.file.OpenOption...-">Oracle Docs Files write()</a>	<br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/nio/file/Files.html#newBufferedWriter-java.nio.file.Path-java.nio.file.OpenOption...-">Oracle Docs Files newBufferedWriter()</a> <br><br>
	</div>
	
<?php 
    include("footer.htm");
?>
	
</body>
</html>
