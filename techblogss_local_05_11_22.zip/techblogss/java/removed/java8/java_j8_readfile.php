<?php 
    include("../header.htm");
?>

<head>
    <title>Java 8 read file to String</title>
	<meta name="description" content="Java 8 read file to String, read file line by line." />
    <link rel="canonical" href="https://www.techblogss.com/java/java_j8_readfile" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	<div id="content" >
	<div id="problem">
		<h1>Java 8 read file</h1>
	</div><br>
	
	<div id="solution">
		<h3>1) Read file to String using Files lines(Path path) method.</h3>
	</div>

    <p>File to read <b>Data.txt</b></p>
<div id="code">
	<pre class="prettyprint">
1 this blog is about java 8 file reading
2 this blog is about java 8 file reading
3 this blog is about java 8 file reading	</pre>
   </div>
	
    <div id="code">
	<pre class="prettyprint">
// Reads file to String 
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class TestReadFile {

    public static void main(String args[]) {
        try (Stream&lt;String&gt; stream = Files.lines(Paths.get("C://Data.txt"))) {
            stream.forEach(System.out::println);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}	</pre>
	</div>

    <div id="solution">
		<h3>Output : </h3>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
1 this blog is about java 8 file reading
2 this blog is about java 8 file reading
3 this blog is about java 8 file reading        </pre>
	</div>	<br>
    
	<div id="solution">
		<h3>2) Read file to String using Files newBufferedReader(Path path) method.</h3>
       </div>

    <p>File to read <b>Data.txt</b></p>
<div id="code">
		<pre class="prettyprint">
// Reads file to String 
import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class TestReadFile {

    public static void main(String args[]) {
        try (BufferedReader br = Files.newBufferedReader(Paths.get("C://Data.txt"))) {
            Stream&lt;String&gt; lineStream = br.lines();
            lineStream.forEach(System.out::println);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}</pre>
	</div>


    <div id="solution">
		<h3>Output : </h3>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
1 this blog is about java 8 file reading
2 this blog is about java 8 file reading
3 this blog is about java 8 file reading   </pre>
	</div>	<br>
 
 	<div id="solution">
		<h3>3) Read file to String using Files readAllLines(Path path) method.</h3>
     </div>

    <p>File to read <b>Data.txt</b></p>
<div id="code">
		<pre class="prettyprint">
// Reads file to String 
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class TestReadFile {

    public static void main(String args[]) {
        try {
            List&lt;String&gt; lines =  Files.readAllLines(Paths.get("C://Data.txt"));
            lines.forEach(System.out::println);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}</pre>
	</div>


    <div id="solution">
		<h3>Output : </h3>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
1 this blog is about java 8 file reading
2 this blog is about java 8 file reading
3 this blog is about java 8 file reading       </pre>
	</div>	
 
 <br>

References : <br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/nio/file/Files.html">Oracle Docs Files</a>	<br><br>
<a href ="https://docs.oracle.com/javase/8/docs/api/java/nio/file/Files.html#lines-java.nio.file.Path-">Oracle Docs Files lines()</a>	<br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/nio/file/Files.html#newBufferedReader-java.nio.file.Path-">Oracle Docs Files newBufferedReader()</a> <br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/nio/file/Files.html#readAllLines-java.nio.file.Path-">Oracle Docs Files readAllLines()</a> <br><br>
	</div>
	
<?php 
    include("footer.htm");
?>
	
</body>
</html>
