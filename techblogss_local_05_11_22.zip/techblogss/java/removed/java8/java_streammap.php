<?php 
    include("../header.htm");
?>

<head>
    <title>Java 8 Stream map()</title>
    <meta name="description" content="Java 8 Stream map() examples like converting Strings to lowercase, convert numbers to their square,
    convert a collection to another collection type using java 8, convert list of objects to another list of objects java 8." />
    <link rel="canonical" href="https://www.techblogss.com/java/java_streammap" />
</head>

<body>
    <?php 
        include("navigation.htm");
    ?>
       <div id="content" >
    <div id="problem">
        <h1>Java 8 Stream map() examples</h1>
    </div>
    
    <div id="solution">
        <h4>1) Java 8 Stream map() example to convert List of Strings to lowercase</h4>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
// Converts List elements (of String type) to lowercase using Stream map
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
    
public class StreamMap { 

    public static void main(String[] args) {
        List&lt;String&gt; fruits = Arrays.asList("Mango", "apple", "Pineapple",
            "orange", "apple");
        List&lt;String&gt; stream = fruits.stream() // convert list to stream
            .map(String::toLowerCase) // map to lowercase
            .collect(Collectors.toList());         
         
         stream.forEach(System.out::println);    
    }
}        </pre>
    </div>

<div id="solution">
        <h4>Output : </h4>
        
    </div>
    
    <div id="code">
        <pre class="prettyprint">
mango
apple
pineapple
orange
apple    </pre>
    </div>    
 <br>
    <div id="solution">
        <h4>2) Java 8 Stream map() example to convert number to their square in a List</h4>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
// Converts List elements (of Integer type) to their square
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
    
public class StreamMap { 

    public static void main(String[] args) {
        List&lt;Integer&gt; numbers = Arrays.asList(1, 2, 3, 4, 5);
        List&lt;Integer&gt; stream = numbers.stream() // convert list to stream
            .map(n->n*n) // convert each number to its square
            .collect(Collectors.toList());         
         
         stream.forEach(System.out::println);    
    }
}        </pre>
    </div>

<div id="solution">
        <h4>Output : </h4>
        
    </div>
    
    <div id="code">
        <pre class="prettyprint">
1
4
9
16
25    </pre>
    </div>     
<br>
    <div id="solution">
        <h4>3) Java 8 Stream map() example to modify objects in a List</h4>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
import java.util.ArrayList;    
import java.util.List;
import java.util.stream.Collectors;
    
class Celebrity  {
    private String name;
    private int rank;
    
    Celebrity (String name, int rank) {
        this.name = name;
        this.rank = rank;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public int getRank() {
        return rank;
    }

    @Override
    public String toString() {
        return "Celebrity [name=" + name + ", rank=" + rank + "]";
    }    
}
 
// Modifies List of objects, changes name of Celebrity object
public class StreamMap { 

    public static void main(String[] args) {
        Celebrity celebrity1 = new Celebrity("AntMan", 1);
        Celebrity celebrity2 = new Celebrity("IronMan", 3);
        Celebrity celebrity3 = new Celebrity("Batman", 2);
            
        List&lt;Celebrity&gt; celebrities = new ArrayList&lt;&gt;();
        celebrities.add(celebrity1);
        celebrities.add(celebrity2);
        celebrities.add(celebrity3);

        List&lt;Celebrity&gt; stream = celebrities.stream() // convert list to stream
            .map(celebrity -> {
                if ("IronMan".equals(celebrity.getName())) {
                    celebrity.setName("Thor");
                }
                return celebrity;
            })
            .collect(Collectors.toList());         
         
         stream.forEach(System.out::println);    
    }
}    </pre>
    </div>

<div id="solution">
        <h4>Output : </h4>
        
    </div>
    
    <div id="code">
        <pre class="prettyprint">
Celebrity [name=AntMan, rank=1]
Celebrity [name=Thor, rank=3]
Celebrity [name=Batman, rank=2]    </pre>
    </div>    

<br>
    <div id="solution">
        <h4>4) Java 8 Stream map() example to convert a collection to another collection type</h4>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ListConverter {

    public static void main(String[] args) {
        List&lt;User> users = new ArrayList<>();
        users.add(new User("John", "Mathews", 39));
        users.add(new User("Boris", "Becker", 59));

        List&lt;Employee> employees = new ArrayList<>();
        
        employees = users.stream().map(user -> {
            Employee employee = new Employee(user.getFirstName().concat(" ")
                    .concat(user.getLastName()), user.getAge());
            return employee;
        }).collect(Collectors.toList());
        
        System.out.println(users);
        System.out.println(employees);
    }
}

class User {
    private String firstName;
    private String lastName;
    private int age;

    public User(String firstName, String lastName, int age) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public int getAge() {
        return age;
    }

    @Override
    public String toString() {
        return "User [firstName=" + firstName + ", lastName=" + lastName
                + ", age=" + age + "]";
    }
 
}

class Employee {
    private String fullName;
    private int age;
    
    public Employee(String fullName, int age) {
        this.fullName = fullName;
        this.age = age;
    }

    public String getFullName() {
        return fullName;
    }

    public int getAge() {
        return age;
    }

    @Override
    public String toString() {
        return "Employee [fullName=" + fullName + ", age=" + age + "]";
    }

}       </pre>
    </div>
    
<div id="solution">
        <h4>Output : </h4>
        
    </div>
    
    <div id="code">
        <pre class="prettyprint">
[User [firstName=John, lastName=Mathews, age=39], User [firstName=Boris, lastName=Becker, age=59]]
[Employee [fullName=John Mathews, age=39], Employee [fullName=Boris Becker, age=59]]    </pre>
    </div>   
    <br>    
    
References : <br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/stream/Stream.html#map-java.util.function.Function-">Oracle Docs Stream map</a>    <br><br>
<a href ="https://docs.oracle.com/javase/8/docs/api/java/util/function/Function.html">Oracle Docs Function</a>    
    </div>
    
<?php 
    include("footer.htm");
?>
    
</body>
</html>
