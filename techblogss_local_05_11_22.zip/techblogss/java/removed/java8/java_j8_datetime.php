<?php 
    include("../header.htm");
?>

<head>
    <title>Java 8 Date and Time API</title>
	<meta name="description" content="Java 8 Date and Time API examples of LocalDate, LocalTime, LocalDateTime, Instant, Period, Duration" />
    <link rel="canonical" href="https://www.techblogss.com/java/java_j8_datetime" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	<div id="content" >
	<div id="problem">
		<h1>Java 8 Date and Time API examples</h1>
	</div>
    <div style="text-align: justify;">
    <p>Prior to Java 8 there was inadequate support for the date and time use cases. For example developers faced following issues:<br><br>
    
    1) <b><i>Date</b></i> class provided by Java had poor API design and didn't do a good job of handling internationalization and localization situations.<br>
    2) <b><i>Date</b></i> and <b><i>SimpleDateFormatter</b></i> aren't thread-safe, and may lead to concurrency issues.<br>
    3) Years <b><i>Date</b/></i> start at 1900, months start at 1, and days start at 0 which is not very intuitive.<br>
    4) Above issues, and other issues have led to the popularity of third-party date and time libraries, such as Joda-Time.<br><br>
    
    Java 8 provides very good support for date and time related functionality in the <b><i>java.time</b></i> package. 
    Most of the classes in this package are immutable and thread-safe.
    </p
    </div>
	
    <div id="solution">
		<h4>1) LocalDate example</h4>
        <p><b><i>LocalDate</b></i> is an immutable date-time object that represents a date.</p>
	</div>

    <div id="code">
	<pre class="prettyprint">
// Java 8 Date and Time API LocalDate
import java.time.LocalDate;
import java.time.Month;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class TestLocalDate {

    public static void main(String args[]) {
        LocalDate today = LocalDate.now();
        System.out.println("Today's date is: " + today);
        
        LocalDate date = LocalDate.of(2012, Month.DECEMBER, 12);
        System.out.println(date);
        
        date = LocalDate.now(ZoneId.of("Asia/Kolkata"));
        System.out.println("Date in Asia/Kolkata zone " + date);
        
        date = LocalDate.now(ZoneId.of("America/Cuiaba"));
        System.out.println("Date in America/Cuiaba zone " + date);
        
        date = LocalDate.parse("2015-10-26");
        System.out.println("Parsed date " + date);
        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
       
        LocalDate localDate = LocalDate.parse("16-Jul-2019", formatter);
        System.out.println("localDate " +localDate);  
        System.out.println("formatted localDat e" +formatter.format(localDate));
        
        // Returns the LocalDate by adding the number of days to the epoch starting day (1970)
        date = LocalDate.ofEpochDay(150);  // middle of 1970
        System.out.println("Date from epoch day " + date);
        
        // obtains an instance of LocalDate from a year and day-of-year.
        date = LocalDate.ofYearDay(2016,100);
        System.out.println(date);
        
        // adds the specified amount to the days field 
        date = date.plusDays(100);
        System.out.println(date);
    }
}	</pre>
	</div>

    <div id="solution">
		<h4>Output : </h4>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Today's date is: 2019-11-12
2012-12-12
Date in Asia/Kolkata zone 2019-11-12
Date in America/Cuiaba zone 2019-11-12
Parsed date 2015-10-26
localDate 2019-07-16
formatted localDate 16-Jul-2019
Date from epoch day 1970-05-31
2016-04-09
2016-07-18
        </pre>
	</div>	
    
 <div id="solution">
		<h4>2) LocalTime example</h4>
        <p><b><i>LocalTime</b></i> is an immutable date-time object that represents a time, often viewed as hour-minute-second.</p>
	</div>

    <div id="code">
	<pre class="prettyprint">
// Java 8 Date and Time API LocalTime
import java.time.LocalTime;
import java.time.ZoneId;

public class TestLocalTime {

    public static void main(String args[]) {
        LocalTime time = LocalTime.now();
        System.out.println("Current time is: " + time);
        
        // add one hour , 20 min
        time = time.plusHours(1).plusMinutes(20);
        System.out.println("Current time is: " + time);
        
        time = LocalTime.of(10,23);
        System.out.println(time);
        
        time = LocalTime.now(ZoneId.of("Asia/Tokyo"));
        System.out.println("Time in Asia/Kolkata zone " + time);
        
        time = LocalTime.now(ZoneId.of("America/Cuiaba"));
        System.out.println("Time in Asia/Kolkata zone " + time);
        
        time = LocalTime.parse("14:20:05");
        System.out.println("Parsed time " + time);
        
        time = LocalTime.ofSecondOfDay(66620);
        System.out.println(time);
        
    }
}	</pre>
	</div>

    <div id="solution">
		<h4>Output : </h4>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Current time is: 10:20:57.270
Current time is: 11:40:57.270
10:23
Time in Asia/Kolkata zone 13:50:57.271
Time in Asia/Kolkata zone 00:50:57.274
Parsed time 14:20:05
18:30:20
        </pre>
	</div>		
 
 	 <div id="solution">
		<h4>3) LocalDateTime example</h4>
        <p><b><i>LocalDateTime</b></i> is an immutable date-time object that represents a date-time, 
        often viewed as year-month-day-hour-minute-second.</p>
	</div>

    <div id="code">
	<pre class="prettyprint">
// Java 8 Date and Time API LocalDateTime
import java.time.LocalDateTime;
import java.time.ZoneId;

public class TestLocalDateTime {

    public static void main(String args[]) {
        LocalDateTime time = LocalDateTime.now();
        System.out.println("Current time is: " + time);
        
        // add one hour , 20 min
        time = time.plusHours(1).plusMinutes(20);
        System.out.println("Current time is: " + time);
        
        time = LocalDateTime.now(ZoneId.of("Asia/Tokyo"));
        System.out.println("Time in Asia/Kolkata zone " + time);
        
        time = LocalDateTime.now(ZoneId.of("America/Cuiaba"));
        System.out.println("Time in Asia/Kolkata zone " + time);
        
        time = LocalDateTime.parse("2018-03-20T06:30:00");
        System.out.println("Parsed time " + time);
        
    }
}	</pre>
	</div>

    <div id="solution">
		<h4>Output : </h4>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Current time is: 2019-07-28T10:56:58.242
Current time is: 2019-07-28T12:16:58.242
Time in Asia/Kolkata zone 2019-07-28T14:26:58.244
Time in Asia/Kolkata zone 2019-07-28T01:26:58.246
Parsed time 2018-03-20T06:30
        </pre>
	</div>	

 <div id="solution">
		<h4>4) Instant example</h4>
        <p><b><i>Instant</b></i> represents an instantaneous point on the time-line  and cant be used to record event time-stamps in the application.</p>
	</div>

    <div id="code">
	<pre class="prettyprint">
// Java 8 Date and Time API Instant
import java.time.Instant;

public class TestDateTime {

    public static void main(String args[]) {
        Instant currTimeStamp = Instant.now();
        System.out.println("Instant timestamp is "+ currTimeStamp);
    }
}	</pre>
	</div>

    <div id="solution">
		<h4>Output : </h4>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Instant timestamp is 2019-07-28T05:36:11.870Z
        </pre>
	</div>		
 
<div id="solution">
		<h4>5) Period example</h4>
        <p><b><i>Period</b></i> class is used to measure an amount of time in terms of years, months, and days.</p>
	</div>

    <div id="code">
	<pre class="prettyprint">
// Java 8 Date and Time API Period
import java.time.LocalDate;
import java.time.Month;
import java.time.Period;

public class TestDateTime {
    public static void main(String args[]) 
        LocalDate initialDate = LocalDate.parse("2007-05-10");
        LocalDate finalDate = initialDate.plus(Period.ofDays(5));
        System.out.println("finalDate " + finalDate);
        
        LocalDate startDate = LocalDate.of(2016, Month.MAY, 1);
        LocalDate endDate = LocalDate.of(2018, Month.JULY, 18);
        Period timeElapsed = Period.between(startDate, endDate);
        System.out.printf("Time elapsed between end and start date is: %d years, %d months,"
            + " and %d days (%s)\n", timeElapsed.getYears(), timeElapsed.getMonths(),
            timeElapsed.getDays(), timeElapsed);

    }
}	</pre>
	</div>

    <div id="solution">
		<h4>Output : </h4>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Instant timestamp is 2019-07-28T05:36:11.870Z
        </pre>
	</div>		

<div id="solution">
		<h4>6) Duration example</h4>
        <p><b><i>Duration</b></i> is a distance on the timeline measured in terms of time, and it fulfills a similar purpose to Period,
        but with different precision.</p>
	</div>

    <div id="code">
	<pre class="prettyprint">
// Java 8 Date and Time API Duration
import java.time.Duration;
import java.time.LocalDateTime;

public class TestDateTime {
    public static void main(String args[]) {
        Duration duration = Duration.ofSeconds(6, 8);
        System.out.println("duration " + duration);
        
        Duration oneDay = Duration.between(LocalDateTime.now().plusDays(1), LocalDateTime.now().plusDays(1));
        System.out.println("oneDay " + oneDay);
        
    }
}	</pre>
	</div>

    <div id="solution">
		<h4>Output : </h4>
        
	</div>
	
	<div id="code">
		<pre class="prettyprint">
duration PT6.000000008S
oneDay PT0.001S
        </pre>
	</div>		    
 
 <br>

References : <br><br>
<a href="https://www.oracle.com/technetwork/articles/java/jf14-date-time-2125367.html">Oracle Docs Java SE 8 Date and Time</a>	<br><br>
<a href ="https://docs.oracle.com/javase/8/docs/api/java/time/LocalDate.html">Oracle Docs LocalDate</a>	<br><br>
<a href ="https://docs.oracle.com/javase/8/docs/api/java/time/LocalTime.html">Oracle Docs LocalTime</a>	<br><br>
<a href ="https://docs.oracle.com/javase/8/docs/api/java/time/LocalDateTime.html">Oracle Docs LocalDateTime</a>	<br><br>
<a href ="https://docs.oracle.com/javase/8/docs/api/java/time/Instant.html">Oracle Docs Instant</a>	<br><br>
<a href ="https://docs.oracle.com/javase/8/docs/api/java/time/Period.html">Oracle Docs Period</a>	<br><br>
<a href ="https://docs.oracle.com/javase/8/docs/api/java/time/Duration.html">Oracle Docs Duration</a>	<br><br>
	</div>
	
<?php 
    include("footer.htm");
?>
	
</body>
</html>
