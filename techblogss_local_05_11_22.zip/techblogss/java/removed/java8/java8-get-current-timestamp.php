<?php 
    include("../header.htm");
?>

<head>
    <title>How to get current timestamp in Java</title>
	<meta name="description" content="How to get current timestamp in Java." />
	<link rel="canonical" href="https://www.techblogss.com/java/java8-get-current-timestamp">
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	<div id="content" >
	<div id="problem">
		<h1>How to get current timestamp in Java ?</h1>
	</div>
	
	<div id="solution">
		<h4>You can get current timestamp using System.currentTimeMillis(), Instant, Date & Timestamp class.</h4>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
import java.sql.Timestamp;
import java.time.Instant;
import java.util.Date;

// get current timestamp
public class CurrentTimestamp {
		
    public static void main(String[] args) {
    	// number of milliseconds, between the current time and midnight, January 1, 1970 UTC.
        long currentTime = System.currentTimeMillis(); // gets current timestamp
        System.out.println("currentTime " + currentTime);
		
        Timestamp timestamp = new Timestamp(currentTime);
        System.out.println("timestamp " + timestamp); // gets current timestamp
		
        // uses UTC timezone
        Instant instant = Instant.now();
        System.out.println("instant " +instant);
		
        // convert Timestamp to Instance
        instant = timestamp.toInstant();
        System.out.println("instant from Timestamp " +instant); // gets current timestamp
		
        // convert Instance to Timestamp
        timestamp = Timestamp.from(instant);
        System.out.println("timestamp from instant " + timestamp.getTime()); // gets current timestamp
		
        // Prior to java 8, create Timestamp from Date
        Date date = new Date();
        timestamp = new Timestamp(date.getTime());
        System.out.println("timestamp from date " + timestamp.getTime()); // gets current timestamp
    }
}
	</pre>	
	</div>
	
	<div id="solution">
		<h4>Console Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
currentTime 1573489824900
timestamp 2019-11-11 22:00:24.9
instant 2019-11-11T16:30:24.916Z
instant from Timestamp 2019-11-11T16:30:24.900Z
timestamp from instant 1573489824900
</pre>
	</div>	
	<br>
    References
	<ul>
		<li><a href ="https://docs.oracle.com/javase/8/docs/api/java/lang/System.html#currentTimeMillis">Oracle Docs System currentTimeMillis</a></li><br>
		<li><a href ="https://docs.oracle.com/javase/8/docs/api/java/time/Instant.html">Oracle Docs Instant</a></li>
	</ul>
	
	
	</div>
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    <?php include("share.htm"); ?>	
</body>

<?php 
    include("footer.htm");
?>

</html>
