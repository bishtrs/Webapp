<?php 
    include("../header.htm");
?>

<head>
    <title>Java user defined exception</title>
	<meta name="description" content="Java user defined exception, Custom Exception or user-defined Exception, checked and unchecked Exception in Java."/>
	<link rel="canonical" href="https://www.techblogss.com/java/java_customexception">
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
   	<div id="content">
	<div id="blog">
	<div id="problem">
		<h1>How to write custom Exception or user-defined Exception in Java ?</h1>
	</div>

	<div style="text-align: justify;">There are many pre-defined checked and uncheked exceptions in Java. But in some scenario these exceptions may not suit your
        requirement and you may want to raise/throw a user-defined Exception.For e.g validating price of an commodity.
        In this case you can write custom Exception or user-defined Exception as follows:</div>
	<div id="solution">
		<h4>1) Writing custom checked Exception with String argument</h4>
        <p>You should use unchecked exceptions only for conditions from which the caller is not expected to recover or they are programming error.</p>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// custom or user-defined Exception	
public class InvalidPriceException extends Exception  {
    public InvalidPriceException(String s) {
        super(s); 
    }
}
	
public class TestClass {
    public void setPrice(int price) throws InvalidPriceException {
        if (price &lt; 0) { // throw custom or user-defined Exception
            throw new InvalidPriceException("invalid price");
        }
    }		
		
    public static void main(String[] args)  {
        TestClass testClass = new TestClass(); 
        try { 
            testClass.setPrice(-1); 
        } catch (InvalidPriceException e) { 
            e.printStackTrace();
        }
    }
}
	</pre>	
	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
InvalidPriceException: invalid price
	at TestClass.setPrice(TestClass.java:4)
	at TestClass.main(TestClass.java:12)
		</pre>
	</div>
	
	<br>
	<div id="solution">
		<h4>2) Writing custom checked Exception without String argument</h4>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// custom or user-defined Exception		
public class InvalidPriceException extends Exception  {
    public InvalidPriceException() {
    }
}
	
public class TestClass {
    public void setPrice(int price) throws InvalidPriceException {
        if (price &lt; 0) {
            // throw custom or user-defined Exception		
            throw new InvalidPriceException(""); 
        }
    }		
		
    public static void main(String[] args)  {
        TestClass testClass = new TestClass(); 
        try { 
            testClass.setPrice(-1); 
        } catch (InvalidPriceException e) { 
            e.printStackTrace();
        }
    }
}
	</pre>	
	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
InvalidPriceException
	at TestClass.setPrice(TestClass.java:9)
	at TestClass.main(TestClass.java:16)
		</pre>
	</div>
	
    <br>
	<div id="solution">
		<h4>3) Writing custom unchecked exception </h4>
        <p>You should use checked exceptions only for conditions from which the caller is expected to recover.</p>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// custom or user-defined Exception		
public class InvalidPriceException extends RuntimeException  {
    public InvalidPriceException(String s) {
        super(s); 
    }
}
		
public class TestClass {
    public void setPrice(int price) throws InvalidPriceException {
        if (price &lt; 0) { // throw custom or user-defined Exception
            throw new InvalidPriceException("invalid price"); 
        }
    }		
		
    public static void main(String[] args)  {
        TestClass testClass = new TestClass(); 
        try { 
            testClass.setPrice(-1); 
        } catch (InvalidPriceException e) { 
            e.printStackTrace();
        }
    }
}
	</pre>	
	</div>
	
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
InvalidPriceException: invalid price
	at TestClass.setPrice(TestClass.java:4)
	at TestClass.main(TestClass.java:12)
		</pre>
	</div>
    <br><br>
    References <a href="https://docs.oracle.com/javase/tutorial/essential/exceptions/index.html">Oracle Docs Exceptions </a>
	
	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
	</div> <!-- content div -->
    
   <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>

    <?php include("share.htm"); ?>
    
</body>



<?php 
    include("footer.htm");
?>

</html>
