<?php 
    include("../header.htm");
?>

<head>
    <title>Static variables and methods in Java</title>
	<meta name="description" content="static variables in Java, static methods in Java, static initialization block"/>
	<link rel="canonical" href="https://www.techblogss.com/java/java-static-variables-methods">
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
   	<div id="content">
	<div id="blog">
	<div id="problem">
		<h1>Static variables and methods in Java</h1>
	</div>

	<div id="solution">
        <p>
        The <b><i>static</b></i> modifier or keyword is used to create <b><i>static</b></i> variables and methods that exist independently of any instances of a class. All instances of a given class share the same value for any given <b><i>static</b></i> variable & there will be only one copy of a <b><i>static</b></i> member regardless of the number of instances of that class.
        </p>
        Follwing can be marked as <b><i>static</b></i> :
        <p>
        <ul>
        <li>Methods</li>
        <li>Variables</li>
        <li>Initialization blocks</li>
        <li>Nested class</li>
        </ul>
        </p>
        <p>
        Below example shows an example where you can use a <b><i>static</b></i> variable to count the number of times a class is instantiated.
        Note that counter variable is accessed in a <b><i>static</b></i> method.
        </p>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
public class Animal {
    
    private static int counter = 0;
    
    public Animal() {
        counter++;
    }
    
    public static void main(String[] args)  {
        new Animal();
        new Animal();
        new Animal();
        new Animal();
        System.out.println("Number of Animal instances " + counter);
    }
}
</pre>	
	</div>

    <div id="solution">
		<h4>Console Output : </h4>
	</div>    
    <div id="code">
		<pre class="prettyprint">
Number of Animal instances 4
		</pre>
	</div>
	
	<br>
	
	<div id="solution">
        <h4>Points to consider while accessing static variables:</h4>
        <p>
        <ul>
            <li><b><i>Static</b></i> variables can be accessed by both <b><i>static</b></i> & non-static (instance) methods.</li>
            <li>Non-static (instance) variables cannot be accessed directly by <b><i>static</b></i> methods.</li>
            <li>Non-static (instance) variables can be accessed by <b><i>static</b></i> method by using an instance.</li>
        </ul>
        </p>
    </div>
        <p>As shown below code will not compile as <b><i>static</b></i> method tries to access an instance variable.</p>
    <div id="code">
		<pre class="prettyprint">

public class Animal {
    
    private int counter = 0;
    
    public Animal() {
        counter++;
    }
    public static void main(String[] args)  {
        new Animal();
        new Animal();
        new Animal();
        new Animal();
        System.out.println("Number of Animal instances " + counter);
    }
}
</pre>
	</div>
    <br>
    
    <div id="solution">
        <h4>Using Initialization blocks to initialize static variables</h4>
    </div>
    <p>
     Initialization blocks run when the class is first loaded (a static initialization block) or when an instance is created (an instance initialization block). Look at the example below:
    </p>
    
    <div id="code">
    <pre class="prettyprint">
class TestStatic {
    static int x;
    int i;
    
    static { // static init block
        x = 7 ; 
    } 
    static { System.out.println("2nd static block"); }
    
    // instance init block
    {
        i = 2; 
        System.out.println("instance block");
    } 
    
    public static void main(String[] args)  {
        new TestStatic();
        new TestStatic();
    }
}
</pre>
	</div>
    
     <div id="solution">
		<h4>Console Output : </h4>
	</div>    
    <div id="code">
		<pre class="prettyprint">
2nd static block
instance block
instance block
		</pre>
	</div>
    
    <br>

    
    <p>Interfaces can also have <b><i>static</b></i> methods, view this page for more details <a href="https://www.techblogss.com/java/java8-default-methods" target="_blank">Static methods in interface</a></p>

    <br><br>
    
     <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
    	
	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
	</div> <!-- content div -->
    
   <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>

    <?php include("share.htm"); ?>
    
</body>



<?php 
    include("footer.htm");
?>

</html>
