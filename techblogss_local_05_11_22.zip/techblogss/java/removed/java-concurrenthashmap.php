<?php 
    include("../header.htm");
?>

<head>
    <title>ConcurrentHashMap in Java</title>
	<meta name="description" content="ConcurrentHashMap, ConcurrentHashMap Java, ConcurrentHashMap vs Hashtable, ConcurrentHashMap vs HashMap" />
    <link rel="canonical" href="https://www.techblogss.com/java/java-concurrenthashmap" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content" >
	<div id="problem">
		<h1>ConcurrentHashMap in Java</h1>
	
		<p><b><i>ConcurrentHashMap</b></i> is useful in multithreaded environment where multiple threads access the map concurrently and perform both read and write operations. Read operations do not block even when the <b><i>Map</b></i> is updated while write operations can often proceed without blocking, because a <b><i>ConcurrentHashMap</b></i> blocks only a segment of table and doesn't block the complete table.</p>
        <p>
         ConcurrentHashMap Iterator returns elements reflecting the state of the hash table at some point and they do not throw <b><i>java.util.ConcurrentModificationException</b></i>.
        </p>
        
        <h3>ConcurrentHashMap vs Hashtable</h3>
        <p>
        <ul>
        <li><b><i>ConcurrentHashMap</b></i> belongs to the Executor framework (java.util.concurrent package) while <b><i>Hashtable</b></i> belongs
		to the Collection framework (java.util package).</li>
        <li><b><i>ConcurrentHashMap</b></i> does not lock table for read operations while <b><i>Hashtable</b></i> locks the table 
		for read operations.</li>
        <li><b><i>ConcurrentHashMap</b></i> does not lock whole table but only one segment of table for write operations 
		while <b><i>Hashtable</b></i> locks the whole table for write operations.</li>
        <li><b><i>ConcurrentHashMap</b></i> doesn't throw <b><i>ConcurrentModificationException</b></i> if one thread tries to modify it 
		while another is iterating over it and while <b><i>Hashtable</b></i> iterator is fail-fast and it throws 
		<b><i>ConcurrentModificationException</b></i>.</li>
        </ul>
        </p>
	</div>
    
    
	<div id="solution">
		<h4>1) Iterate ConcurrentHashMap </h4>
        <p>You can iterate a <b><i>ConcurrentHashMap</b></i> as shown below.</p>
		<p>
		Also an Iterator for a <b><i>ConcurrentHashMap remove()</b></i> is weakly consistent. It can return elements from the point in time 
		the Iterator was created or later, which means that while you are looping through a <b><i>ConcurrentHashMap remove()</b></i>,
		you might observe elements that are being inserted by other threads.
		</p>
	</div>
	<div id="code">
	<pre class="prettyprint">
import java.util.Iterator;	
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;
	
public class ConcurrentHashMapExample {

    public static void main(String[] args) {
        Map&lt;String, String&gt; map = new ConcurrentHashMap&lt;String, String&gt;();
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
		
        // using java 8 forEach()
        map.forEach((k,v)->System.out.println("Index [" + k + "] Fruit  [" + v + "]"));

        // using java 8 stream()
        map.entrySet().stream().forEach(entry->
            System.out.println("Key : "+entry.getKey()+" Value : "+entry.getValue()));
		
        // using Iterator
        Iterator&lt;Map.Entry&lt;String, String&gt;&gt; iterator = map.entrySet().iterator();
        while(iterator.hasNext()){
            Map.Entry&lt;String, String&gt; entry = iterator.next();
            System.out.println("key=" + entry.getKey() + "::value=" + entry.getValue());
        }
		
   }
}
	</pre>
	</div>

	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Index [key1] Fruit  [value1]
Index [key2] Fruit  [value2]
Index [key3] Fruit  [value3]
Key : key1 Value : value1
Key : key2 Value : value2
Key : key3 Value : value3
key=key1::value=value1
key=key2::value=value2
key=key3::value=value3
		</pre>
	</div>
<br>	
	<div id="solution">
		<h4>2) Remove entry from ConcurrentHashMap</h4>
        <p>If you remove an entry while iterating using <b><i>ConcurrentHashMap remove()</b></i> method,
        unlike a HashMap, you will not get <b><i>ConcurrentModfiicationException</b></i>.</p>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
	
public class ConcurrentHashMapExample {
    public static void main(String[] args) {
        Map&lt;String, String&gt; map = new ConcurrentHashMap&lt;String, String&gt;();
        map.put("101.102.2.3", "www.abc.com");
        map.put("101.102.2.4", "www.def.com");
        map.put("101.102.2.5", "www.ghi.com");
        System.out.println("map " + map);
        Iterator&lt;Map.Entry&lt;String, String>> iterator = map.entrySet().iterator();

        while(iterator.hasNext()){
            Map.Entry&lt;String, String> entry = iterator.next();
            if ("101.102.2.4".equals(entry.getKey())) {            
                map.remove("101.102.2.4");
            }
        }
        System.out.println("map " + map);
    }
}
	</pre>
	</div>

<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
map {101.102.2.5=www.ghi.com, 101.102.2.3=www.abc.com, 101.102.2.4=www.def.com}
map {101.102.2.5=www.ghi.com, 101.102.2.3=www.abc.com}
		</pre>
	</div>
<br>
	<div id="solution">
		<h4>3) ConcurrentHashMap putIfAbsent()</h4>
        <p>A <b><i>ConcurrentMap</b></i> provides the atomic <b><i>putIfAbsent, remove, and replace</b></i> methods. If you want to put an entry while in the <b><i>ConcurrentHashMap</b></i> only if the key is not associated with a value, then you can use <b><i>ConcurrentModfiicationException putIfAbsent() method</b></i>. For example, the <b><i>putIfAbsent()</b></i> method is equivalent to performing the following code as an atomic operation:</p>
		
		<div id="code">
			<pre class="prettyprint">
if (!map.containsKey(key)) 
    return map.put(key, value); 
else
    return map.get(key);
		</pre>
		</div>
		
	</div><br>
	
	<div id="code">
	<pre class="prettyprint">
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
	
public class ConcurrentHashMapExample {
    public static void main(String[] args) {
        Map&lt;String, String&gt; fruitsMap = new ConcurrentHashMap&lt;String, String&gt;();
        fruitsMap.put("1", "apple");
        fruitsMap.put("2", "banana");
        fruitsMap.put("3", "orange");
        System.out.println("fruitsMap " + fruitsMap);
		
        // will not update map
        fruitsMap.putIfAbsent("2", "pineapple");
        System.out.println("fruitsMap " + fruitsMap);
        fruitsMap.putIfAbsent("4", "pineapple");
        System.out.println("fruitsMap " + fruitsMap);    
    }
}
	</pre>
	</div>

<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
fruitsMap {1=apple, 2=banana, 3=orange}
fruitsMap {1=apple, 2=banana, 3=orange}
fruitsMap {1=apple, 2=banana, 3=orange, 4=pineapple}
		</pre>
	</div>

<br>
	<div id="solution">
		<h4>4) ConcurrentHashMap computeIfPresent()</h4>
        <p>If you want to compute a new mapping given the key you can use <b><i>ConcurrentHashMap computeIfPresent()</b></i> method.</p>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
	
public class ConcurrentHashMapExample {
    public static void main(String[] args) {
        Map&lt;String, String&gt; fruitsMap = new ConcurrentHashMap&lt;String, String&gt;();
        fruitsMap.put("1", "apple");
        fruitsMap.put("2", "banana");
        fruitsMap.put("3", "orange");
        System.out.println("fruitsMap " + fruitsMap);
		
        // will convert the value to upperCase
        fruitsMap.computeIfPresent("2", (k, v) -> v.toUpperCase());

        System.out.println("fruitsMap " + fruitsMap);
    }
}
	</pre>
	</div>

<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
fruitsMap {1=apple, 2=banana, 3=orange}
fruitsMap {1=apple, 2=BANANA, 3=orange}
		</pre>
	</div>
	<br>

<div id="solution">
		<h4>5) ConcurrentHashMap computeIfAbsent()</h4>
        <p>If the specified key is not already associated with a value and you want to  compute its value using the given mapping function you can use <b><i>ConcurrentHashMap computeIfAbsent()</b></i> method. In below example map contains key as some text and value as its length.</p>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
	
public class ConcurrentHashMapExample {
    public static void main(String[] args) {
        Map<String, Integer> map = new ConcurrentHashMap<>();
        map.put("hello world", "hello world".length());
        map.put("this is a ConcurrentHashMap", "this is a ConcurrentHashMap".length());
        System.out.println("map " + map);
		
        map.computeIfAbsent("computeIfAbsent example", (k) -> k.length());

        System.out.println("updated map " + map);
    }
}
	</pre>
	</div>

<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
map {this is a ConcurrentHashMap=27, hello world=11}
updated map {computeIfAbsent example=23, this is a ConcurrentHashMap=27, hello world=11}
		</pre>
	</div>
	
<br>
References : <br><br>

<a href="https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/ConcurrentHashMap.html" target="_blank">Oracle Docs ConcurrentHashMap</a>	<br><br>
        
	</div>
<div id="entry">
    <?php include("share.htm"); ?>	
    </div>
</body>

<?php 
    include("footer.htm");
?>

</html>
