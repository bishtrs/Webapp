<?php 
    include("../header.htm");
?>

<head>
    <title>Find element in List Java</title>
	<meta name="description" content="Find element in List Java, using Collections binarysearch with comparator" />
	<link rel="canonical" href="https://www.techblogss.com/java/java_findelement">
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
	<div id="problem">
		<h1>Find element in List Java</h1>
	</div>
    <p>The Collections class provides methods that allow you to search for an element.</p>
	<div id="solution">
		<h4>1) Find an element in a List in Java using Collections binarySearch(List&lt;? extends Comparable&lt;? super T>> list, T key) </h4>
        <p>Below example shows how to find an element in an List.</p>
	</div>
	<div id="code">
	<pre class="prettyprint">
// find an element in an List	
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class TestSearchElement {
    public static void main(String[] args) {
        String[] sa = {"banana", "apple", "orange", "pineapple"};
        List&lt;String> sl = Arrays.asList(sa);
        
        Collections.sort(sl);
        
        for (String s : sa)     
            System.out.println("fruit " + s);
        System.out.println("index of orange in sorted array  " + Collections.binarySearch(sl, "orange"));
    }
}
	</pre>
	</div>

<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
fruit apple
fruit banana
fruit orange
fruit pineapple
index orange in sorted array  2
		</pre>
	</div>	
	

	<div id="solution">
		<h4>2) Find an element in a List in Java using Collections binarySearch(List&lt;? extends T> list, T key, Comparator&lt;? super T> c) with Comparator</h4>
	</div>
	<div id="code">
	<pre class="prettyprint">
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class Celebrity {
    private String name;
    private int networth;
	
    Celebrity (String name, int networth) {
        this.name = name;
        this.networth = networth;
    }
	
    public String getName() {
        return name;
    }
	
    public int getNetworth() {
        return networth;
    }
	
    @Override
    public String toString() {
        return "Celebrity [name=" + name + ", networth=" + networth + "]";
    }	
}

// Sorts using Comparator by networth of Celebrity		
class CelebrityNetWorthComparator implements Comparator&lt;Celebrity&gt;{

    public int compare(Celebrity cel1, Celebrity cel2) {
        return (cel1.getNetworth() &lt; cel2.getNetworth()) ?
            -1 : ((cel1.getNetworth() == cel2.getNetworth()) ? 0 : 1);
    }
}

public class TestSearchElement {
    public static void main(String[] args) {
        List&lt;Celebrity> celebrities = new ArrayList<>();
        celebrities.add(new Celebrity("Harry", 100000));
        celebrities.add(new Celebrity("IronMan", 2000000));
        celebrities.add(new Celebrity("Batman", 50000));
        
        System.out.println("Before sorting");
        for (Celebrity celebrity : celebrities)     
            System.out.println(celebrity);
        
        CelebrityNetWorthComparator comparator = new CelebrityNetWorthComparator();
        
        Collections.sort(celebrities, comparator);
        
        System.out.println("After sorting");
        for (Celebrity celebrity : celebrities)     
            System.out.println(celebrity);
        
        System.out.println("index of Harry celebrity in sorted array  " +
            Collections.binarySearch(celebrities, new Celebrity("Harry", 100000), comparator));
    }
}
	</pre>
	</div>

<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Before sorting
Celebrity [name=Harry, networth=100000]
Celebrity [name=IronMan, networth=2000000]
Celebrity [name=Batman, networth=50000]
After sorting
Celebrity [name=Batman, networth=50000]
Celebrity [name=Harry, networth=100000]
Celebrity [name=IronMan, networth=2000000]
index of Harry celebrity in sorted array  1
		</pre>
	</div>	
	

References : <br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/Collections.html">Oracle Docs Collections</a>	<br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/Collections.html#binarySearch-java.util.List-T-">Oracle Docs Collections binarySearch()</a> <br><br>		
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/Collections.html#binarySearch-java.util.List-T-java.util.Comparator-">Oracle Docs Collections binarySearch() using Comparator</a> <br><br>		
	</div>
    
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>	

</html>