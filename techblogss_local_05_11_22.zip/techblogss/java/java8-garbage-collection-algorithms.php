<?php include("../header.htm");?>

<head>
    <title>Garbage Collection Algorithms in Java</title>
	<meta name="description" content="Garbage Collection Algorithms in Java, Java Garbage Collection Algorithms" />
	<link rel="canonical" href="https://www.techblogss.com/java/java8-garbage-collection-algorithms" />
</head>

<body>
	<?php include("../navigation.htm");?>
   	
	<div id="content">
    <div id="blog">
   
	<div id="problem">
		<h1>Garbage Collection Algorithms in Java</h1>
	</div>
	<h3>What is Garbage Collection ?</h3>
	<div id="solution">
		<p>
        Java provides <b><i>Garbage Collection</b></i> feature to remove the objects from memory when the objects are no longer in use. 
        The JVM finds the objects that no longer have any references to them and removes them from heap memory. Java used special objects called <b><i>Garbage Collection Roots (GC roots)</b></i> which act as a root objects (local variables, active threads, static variables, & JNI references) using which objects are tracked for garbage collection.
		</p>
        <p>
        Below are few examples that shows how a Car or Engine class object becomes eligible for GC once its value is set to null.
        </p>
	</div>
    
    <div id="code">
    <pre class="prettyprint">
Car car = new Car();
car = null;      </pre></div><br>

<div id="code">
    <pre class="prettyprint">
Car car = new Car();
Engine engine = new Engine();
car.setEngine(engine);
engine.setCar(car)      
engine = null;
car = null;</pre></div><br>
	
	<h3>Minor GC (Garbage Collection)</h3>
	<div id="solution">
		<p><b><i>Heap</b></i> is divided into <b><i>old</b></i> and <b><i>young</b></i> generations. The <b><i>young generation</b></i> is 
        further divided into <b><i>eden and survivor</b></i> spaces. When the <b><i>young generation</b></i> fills up, 
        <b><i>garbage collector</b></i> will stop all the application threads and cleanup <b><i>young generation</b></i>. Objects that are no 
        longer in use are discarded. This operation is called <b><i>minor GC</b></i>.
		</p>
	</div>
	    
	<h3>Full GC (Garbage Collection)</h3>
	<div id="solution">
		<p>As objects are moved from <b><i>young</b></i> to <b><i>old/tenured generation</b></i>, it also gets filled up. Now JVM starts looking 
        for objects that are no longer in use. The <b><i>GC algorithms</b></i> like <b><i>serial</b></i> and <b><i>throughput garbage collector</b></i> stops
        all the application threads, find the unused objects, and free up memory. This process is called <b><i>full GC</b></i>.
		</p>
	</div>
    <div>
        <img src="../images/gc_2.jpg" alt="gc" style="width:500px;height:200px;">
        
        <br><br><br><br><br><br><br><br><br>
    </div>
    

	 <h2>GC (Garbage Collection) Algorithms</h2>
	<div id="solution">
		<p>The JVM provides four algorithms to perform GC.
		</p>
	</div>
    
  	<h3>1) Serial Garbage collector</h3>
	<div id="solution">
		<p><b><i>Serial Garbage collector</b></i> is the default garbage collector for the applications running on a client-class machine 
        (typically 32-bit JVM on windows or single-processor machines). <b><i>Serial Garbage collector</b></i> uses a single thread to process the heap. 
        It will stop all the application threads as the heap is processed for <b><i>minor/full GC</b></i>. <b><i>Serial Garbage collector</b></i> 
        can be enabled by using <b><i>-XX:+UseSerialGC</b></i> flag.
		</p>
	</div>
    
    <h3>2) Throughput Garbage collector</h3>
	<div id="solution">
		<p><b><i>Throughput Garbage collector</b></i> is the default garbage collector for the applications running on a server-class machine 
        (typically 64-bit JVM on windows or multi-CPU Unix machines). <b><i>Throughput Garbage collector</b></i> uses multiple threads to process the heap. It will stop all the application threads as the heap is processed for both <b><i>minor GC & full GC</b></i>. <b><i>Throughput Garbage collector</b></i> can be enabled by using <b><i>-XX:+UseParallelGC</b></i> flag.
		</p>
	</div>
    
    <h3>3) CMS Garbage collector</h3>
	<div id="solution">
		<p><b><i>CMS Garbage collector</b></i> uses multiple threads to process the heap, but it will stop all the application threads
        only during <b><i>minor GC</b></i> & not during <b><i>full GC</b></i>. <b><i>CMS Garbage collector</b></i> use separate threads to 
        periodically process old generation, thus avoids stopping application pause during a <b><i>full GC</b></i>. <b><i>CMS Garbage collector</b></i> 
        can be enabled by using <b><i>-XX:+UseConcMarkSweepGC</b></i> flag.
		</p>
	</div>

     <h3>4) G1 Garbage collector</h3>
	<div id="solution">
		<p><b><i>G1 Garbage collector</b></i> is designed to process large heaps (greater than 4 GB). <b><i>G1 Garbage collector</b></i> also uses 
        multiple threads to process the heap, and it will stop all the application threads only during <b><i>minor GC</b></i> & not during 
        <b><i>full GC</b></i>. <b><i>G1 Garbage collector</b></i> use separate threads to periodically process old generation, thus avoids
        stopping application pause during a <b><i>full GC</b></i>. <b><i>G1 Garbage collector</b></i> can be enabled by using
        <b><i>-XX:+UseG1GC</b></i> flag.
		</p>
	</div>
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
	
	<br>
References : <br><br>
<a href="https://www.oracle.com/webfolder/technetwork/tutorials/obe/java/gc01/index.html" target="_blank">Java Garbage Collection</a>	<br><br>
	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
	
	<div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>
</html>