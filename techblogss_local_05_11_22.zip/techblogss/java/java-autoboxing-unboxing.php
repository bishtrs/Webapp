<?php include("../header.htm");?>

<head>
    <title>Autoboxing and unboxing in Java example</title>
	<meta name="description" content="Autoboxing and unboxing in Java example" />
    <link rel="canonical" href="https://www.techblogss.com/java/java-autoboxing-unboxing"/ >
</head

<body>
	<?php include("../navigation.htm");?>
   	
	<div id="content">
	<div id="blog">
	
	<div id="problem">
		<h1>Autoboxing and unboxing in Java</h1>
	</div>
    
    <div id="solution">
    <p>
    Before Java 5, Wrapper classes like <code>Integer</code>, <code>Float</code>, <code>Boolean</code>, etc were used to put primitives into 
    collections and also to get it back from a collection. First you had to wrap a primitive before you could put it into a collection. 
    </p>
    <p>
    With Java 5, <code>Autoboxing</code> automatically converts primitive into Wrapper obejct and while <code>unboxing</code> converts
    back primitive from Wrapper object. When the primitive is automatically converted into a Wrapper, it is called 
    <code>Autoboxing</code> while when the value is converted automatically from wrapper to a primitive, it is called unboxing. 
    Below are the <code>Autoboxing</code> and <code>unboxing</code> examples.
    </p>
    </div>
    
	<h2>Autoboxing and unboxing Examples</h2>
    <h4>Example 1:</h4>
	<div id="code">
		<pre class="prettyprint">
import java.util.*;<br>
public class Test {
    public static void main(String[] args) {
        List&lt;Integer&gt; list = new ArrayList&lt;&gt;(); 
        list.add(new Integer(10)); // Pre Java 5
        
        // autoboxing, no need to wrap int value in Integer object
        list.add(10); // Post Java 5
    }
}		</pre></div><br>
    
	<h4>Example 2:</h4>
	<div id="code">
		<pre class="prettyprint">
public class Test {
    public static void main(String[] args) {
        Integer i = new Integer(100); 
        int j = i; // unboxing 
        System.out.println(j);  // prints 100 
    }
}		</pre></div><br>
	
	<h4>Example 3:</h4>
	<div id="code">
		<pre class="prettyprint">
public class Test {
    public static void main(String[] args) {
        Integer i = 100; // autoboxing
        i++; // unboxing  
        System.out.println(i);  // prints 101 
    }
}		</pre>
	</div><br>
	
	
	<h4>Example 4:</h4>
	<div id="code">
		<pre class="prettyprint">
public class Test {
    public static void main(String[] args) {
        Integer num = new Integer(5); 
        int i = num; // unboxing  
    }
}		</pre></div><br>

    <h4>Example 5:</h4>
    <p>When we use == operator to compare two wrapper objects, then the objects are first converted to their primitive value or unboxed first.</p>
	<div id="code">
		<pre class="prettyprint">
public class Test {
    public static void main(String[] args) {
        Integer num1 = 50;
        Integer num2 = 50;
        System.out.println(num1 == num2); // prints true , used unboxing
        System.out.println(num1 != num2); // prints false
        System.out.println(num1.equals(num2)); // prints true
    }
}		</pre></div><br>
	
	
	References : <a href="https://docs.oracle.com/javase/tutorial/java/data/autoboxing.html">
    https://docs.oracle.com/javase/tutorial/java/data/autoboxing.html</a>
	 <!-- ADU1 -->
	<?php include("../sidebar/ad.htm"); ?>
	
	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->

    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
    <?php include("share.htm"); ?>	
</body>

<?php 
    include("footer.htm");
?>

</html>
