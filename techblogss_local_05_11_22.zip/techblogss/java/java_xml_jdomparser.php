<?php 
    include("../header.htm");
?>

<head>
    <title>Java JDOM parser</title>
	<meta name="description" content="Java JDOM parser." />
	<link rel="canonical" href="https://www.techblogss.com/java/java_xml_jdomparser">
</head>

<body>
	<?php 
		include("navigation.htm");
	?>

    <div id="content">
    <div id="blog">
    <div id="problem">
		<h1>How to parse and create XML file using JDOM2 parser in Java ?</h1><br>
        
		<p><b><i>JDOM</b></i> parser uses similar approach as DOM parser but is easier to use. <b><i>JDOM</b></i> used proprietary Apache APIs, so it tie you 
        to a specific implementation that can evolve in time or lose backwards compatibility.</p><br>
  
  	
		<h2>Parse XML file using JDOM parser</h2>
	</div>
	
	<div id="solution">
        First you need to download jdom-2.0.6.jar from <a href="http://www.jdom.org/downloads/index.html"> JDOM 2.0.6 </a><br><br>
		XML file to parse: <b>employees.xml</b>
	</div>
	
	<div id="code">
	
	<pre class="prettyprint">
&lt;?xml version = "1.0"?>    
&lt;employees>
    &lt;employee id="123">
        &lt;firstname>John&lt;/firstname>
        &lt;lastname>Carter&lt;/lastname>
    &lt;/employee>
    &lt;employee id="124">
        &lt;firstname>Jay&lt;/firstname>
        &lt;lastname>Joseph&lt;/lastname>
    &lt;/employee>
    &lt;employee id="125">
        &lt;firstname>James&lt;/firstname>
        &lt;lastname>Hogg&lt;/lastname>
    &lt;/employee>
&lt;/employees>
	</pre>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
//JDOM2 parser
import java.io.File;
import java.io.IOException;
import java.util.List;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;

public class TestJDOM2 {
    public static void main(String[] args) {
       
        SAXBuilder builder = new SAXBuilder();
        File xmlFile = new File("c:\\employees.xml");  
        
        try {

            Document document = (Document) builder.build(xmlFile);
            Element rootNode = document.getRootElement();
            System.out.println("Root: " + rootNode.getName());
            
            List&lt;Element&gt; list = rootNode.getChildren("employee");
        
            for (int i = 0; i &lt; list.size(); i++) {
                Element node = (Element) list.get(i);
                System.out.println("id : " + node.getAttributeValue("id"));
                System.out.println("First Name : " + node.getChildText("firstname"));
                System.out.println("Last Name : " + node.getChildText("lastname"));
            }
            
        } catch (IOException  e) {
         e.printStackTrace();
        } catch (JDOMException  e) {
         e.printStackTrace();
        } 
    }
}
	</pre>
	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
	<pre class="prettyprint">
Root: employees
id : 123
First Name : John
Last Name : Carter
id : 124
First Name : Jay
Last Name : Joseph
id : 125
First Name : James
Last Name : Hogg
	</pre>
	</div><br><br>
    
    <div id="problem">
		<h2>Create XML using JDOM2</h2>
        
		<p><b><i>JDOM</b></i> parser uses similar approach as DOM parser but is easier to use. <b><i>JDOM</b></i> used proprietary Apache APIs, so it tie you 
        to a specific implementation that can evolve in time or lose backwards compatibility.</p>
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
	
	
		<h4>You can create XML file using JDOM parser as following:</h4>
	</div>
		
	<br>
    <div id="solution">
		XML file to create: <b>employees.xml</b>
	</div>
    
   
	<div id="code">
	<pre class="prettyprint">
&lt;?xml version = "1.0"?>    
&lt;employees>
    &lt;employee id="1">
        &lt;firstname>Mark&lt;/firstname>
        &lt;lastname>Carter&lt;/lastname>
    &lt;/employee>
    &lt;employee id="2">
        &lt;firstname>James&lt;/firstname>
        &lt;lastname>Joseph&lt;/lastname>
    &lt;/employee>
    &lt;employee id="3">
        &lt;firstname>John&lt;/firstname>
        &lt;lastname>Hogg&lt;/lastname>
    &lt;/employee>
&lt;/employees>
	</pre>
	</div>

	<div id="code">
	<pre class="prettyprint">
//JDOM2 parser
import java.io.FileWriter;
import java.io.IOException;

import org.jdom2.Attribute;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;

public class JDOM2FileWriter {
    public static void main(String[] args) {
       
        try {
            Element employees = new Element("employees");
            Document doc = new Document(employees);

            Element employee = new Element("employee");
            employee.setAttribute(new Attribute("id", "1"));
            employee.addContent(new Element("firstname").setText("Mark"));
            employee.addContent(new Element("lastname").setText("Carter"));

            doc.getRootElement().addContent(employee);

            Element employee2 = new Element("employee");
            employee2.setAttribute(new Attribute("id", "2"));
            employee2.addContent(new Element("firstname").setText("James"));
            employee2.addContent(new Element("lastname").setText("Joseph"));
  		
            doc.getRootElement().addContent(employee2);
  		
            Element employee3 = new Element("employee");
            employee3.setAttribute(new Attribute("id", "3"));
            employee3.addContent(new Element("firstname").setText("John"));
            employee3.addContent(new Element("lastname").setText("Hogg"));

            doc.getRootElement().addContent(employee3);

            XMLOutputter xmlOutput = new XMLOutputter();

            xmlOutput.setFormat(Format.getPrettyFormat());
            xmlOutput.output(doc, new FileWriter("c:\\employees.xml"));
            
        } catch (IOException  e) {
            e.printStackTrace();
        } 
    }
}
	</pre>
	</div>
	
   <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>	
    
    
    <br>
    References : <br><br><a href="http://www.studytrails.com/java/xml/jdom2/java-xml-jdom2-introduction/">JDOM Introduction</a><br><br>
<a href="https://www.techblogss.com/java/java_domparser">DOM Parser Example</a>

     </div> <!-- blog div-->
    <?php include("../sidebar/sidebar.htm"); ?>

    </div> <!-- content div -->
   
</body>

<?php 
    include("footer.htm");
?>

</html>
