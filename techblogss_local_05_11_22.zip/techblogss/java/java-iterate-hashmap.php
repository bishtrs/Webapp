<?php include("../header.htm"); ?>

<head>
    <title>Iterate HashMap Java</title>
	<meta name="description" content="Iterate HashMap in Java using for loop, Map.Entry Iterator, KeySet Iterator, Java 8 foreach" />
    <link rel="canonical" href="https://www.techblogss.com/java/java-iterate-hashmap" />
</head>

<body>
	<?php include("../navigation.htm");	?>
   	
	<div id="content" >
	<div id="problem">
		<h1>Iterate HashMap Java</h1>
	    <p>
        There are various ways of iterating over a <code>Map</code> type in Java. We will use <code>HashMap</code> to show various ways of iterating through a <code>Map</code> and same can be used for other <code>Map</code> implementations.
        </p>
	</div>
	<div id="solution">
		<h4>1) Iterate HashMap using enhanced for loop (Java 5) on Map entrySet</h4>
        <p>You can iterate a <code>HashMap</code> using for loop on a <code>Set&lt;Map.Entry&lt;String, String&gt;&gt;</code>. 
        You can get <code>Set&lt;Map.Entry&lt;String, String&gt;&gt;</code> by calling <code>HashMap entrySet()</code> method.
        The <code>Set</code> is backed by original <code>HashMap</code> so any changes in the <code>HashMap</code> will be reflected in the <code>Set</code> and vice-versa.
        </p>
        <p>
        Also we will use enhanced for loop so that you don't need to get the iterator. You need to call <code>getKey()</code> on <code>Map.Entry&lt;String, String&gt;</code> object to get the <code>Map</code> key and <code>getValue()</code> to get the value.</code> 
        </p>
	</div>
	<div id="code">
	<pre class="prettyprint">
// Iterate HashMap using for loop on Set&lt;Map.Entry&lt;String, String&gt;&gt;    
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
	
public class MyClass {
    public static void main(String[] args) {
        Map&lt;String, String&gt; map = new HashMap&lt;String, String&gt;();
        map.put("key1", "value1");
        map.put("key2", "value2");
        map.put("key3", "value3");
        Set&lt;Map.Entry&lt;String, String&gt;&gt; entry  = map.entrySet();
        
        for (Map.Entry&lt;String, String&gt; pair : entry) {
            System.out.println("key=" + pair.getKey() + "::value=" + pair.getValue());
        }
   }
}	</pre></div>

	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
key=key1::value=value1
key=key2::value=value2
key=key3::value=value3
		</pre></div><br>
	
	<div id="solution">
		<h4>2) Iterate HashMap using Iterator on Map entrySet</h4>
        <p>
        You can also get <code>Iterator</code> for the <code>entrySet</code> and iterate over it. This is helpful when you want to remove any entry from the <code>HashMap</code> using <code>Iterator.</code>
       </p>
	</div>
    
	<div id="code">
	<pre class="prettyprint">
// Iterate HashMap using Iterator on Set&lt;Map.Entry&lt;String, String&gt;&gt;        
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
	
public class MyClass {
    public static void main(String[] args) {
        Map&lt;String, String&gt; map = new HashMap&lt;String, String&gt;();
        map.put("101.102.2.3", "www.abc.com");
        map.put("101.102.2.4", "www.def.com");
        map.put("101.102.2.5", "www.ghi.com");
        
        Iterator&lt;Map.Entry&lt;String, String&gt;&gt; iterator = map.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry&lt;String, String&gt; entry = iterator.next();
            System.out.println("key=" + entry.getKey() + "::value=" + entry.getValue());
        }
    }
}	</pre></div>

    <div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
key=101.102.2.5::value=www.ghi.com
key=101.102.2.3::value=www.abc.com
key=101.102.2.4::value=www.def.com		</pre></div><br>
	
	<div id="solution">
		<h4>3) Iterate HashMap using HashMap keySet values</h4>
        <p>
        You can iterate a <code>HashMap</code> using for loop on <code>Set&lt;K&gt;</code> of <code>HashMap</code> keys. You can get <code>Set&lt;K&gt;</code> of keys by calling <code>HashMap keySet()</code> method. You can loop over the keySet and then use the keys to get corresponding values (by calling <b><i>map.get(key)</b></i>).
        </p>
        <p>
        The <code>keySet</code> is backed by original <code>HashMap</code> so any changes in the <code>HashMap</code> will be reflected in the <code>keySet</code> and vice-versa.
        </p>
	</div>
	<div id="code">
	<pre class="prettyprint">
// Iterate HashMap using for loop on Set&lt;K&gt; 
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
	
public class TestClass { 
 
    public static void main(String[] args) {  
      
        Map&lt;Integer, String&gt; map= new HashMap<>();
        map.put(1, "Apple");
        map.put(2, "Orange");
        map.put(3, "PineApple");
        Set&lt;Integer&gt; keySet = map.keySet();
		
        for (Integer key : keySet) {
           System.out.println("key=" + key + "::value=" + map.get(key));
       }
    }  
}	</pre></div>

	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
key=1::value=Apple
key=2::value=Orange
key=3::value=PineApple		</pre></div><br>

    <div id="solution">
		<h4>4) Iterate HashMap using forEach loop (Java 8)</h4>
        <p>
        Using Java 8 you can iterate over a <code>HashMap</code> by using lambda expression. <code>HashMap forEach</code> method will accept a <code>BiConsumer</code> (a functional interface) type object which can be used to iterate its keys and values. The two arguments k,v passed to <code>BiConsumer accept(Object, Object)</code> method represent the <code>HashMap</code> key and its corresponding value.
        </p>
	</div>
	<div id="code">
	<pre class="prettyprint">
import java.util.HashMap;
import java.util.Map;
	
public class TestClass { 
 
    public static void main(String[] args) {  
      
        Map&lt;Integer, String&gt; map= new HashMap&lt;&gt;();
        map.put(1, "Apple");
        map.put(2, "Orange");
        map.put(3, "PineApple");
        map.forEach((k,v) -> System.out.println("Index [" + k + "] Fruit  [" + v + "]"));
    }  
}
	</pre>
	</div>

	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Index [1] Fruit  [Apple]
Index [2] Fruit  [Orange]
Index [3] Fruit  [PineApple]		</pre></div><br>	

    <div id="solution">
        <h4>5) Iterate HashMap using Stream API (Java 8)</h4>
        <p>
        Using Java 8 you can also iterate over a <code>HashMap</code> by using <code>Stream forEach</code> method will accept a <code>Consumer</code> (a functional interface) type object which can be used to iterate its keys and values. The Entry object is passed to <code>Consumer accept(Object)</code> method  and then you can get the <code>HashMap</code> key and its corresponding value by calling <b><i>entry.getKey() & entry.getValue()</b></i>.
        </p>
	</div>
	<div id="code">
	<pre class="prettyprint">
import java.util.HashMap;
import java.util.Map;
	
public class TestClass { 
 
    public static void main(String[] args) {  
      
        Map&lt;Integer, String&gt; map= new HashMap<>();
        map.put(1, "Apple");
        map.put(2, "Orange");
        map.put(3, "PineApple");
        map.entrySet().stream().forEach(entry -> System.out.println("Key : "+entry.getKey()+" Value : "+entry.getValue()));
    }  
}
	</pre>
	</div>

	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Key : 1 Value : Apple
Key : 2 Value : Orange
Key : 3 Value : PineApple		</pre></div><br>    


References : <br><br>

<a href="https://docs.oracle.com/javase/8/docs/api/java/util/HashMap.html#entrySet--" target="_blank">Oracle Docs HashMap entrySet()</a>	<br><br>
<a href="https://docs.oracle.com/javase/8/docs/api/java/util/HashMap.html#keySet--" target="_blank">Oracle Docs HashMap keySet()</a>	
	
	</div>
<?php include("share.htm"); ?>	
</body>

<?php 
    include("footer.htm");
?>

</html>
