<?php 
    include("../header.htm");
?>

<head>
    <title>Multiple threads in Java and Multithreading in Java</title>
	<meta name="description" content="Multiple threads in Java and Multithreading in Java." />
	<link rel="canonical" href="https://www.techblogss.com/java/java_threadmultiple">
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
	<div id="problem">
		<h1>Multiple threads in Java, Multithreading in Java</h1>
	<p>The examples below show how to create multiple threads.
        </p> 

	</div>
	<div id="solution">
        <h4>1) Create multiple threads by extending Thread Class </h4>
		 
	</div>
	
	<div id="code">
	<pre class="prettyprint">
// Multiple threads in Java
public class MyThread extends Thread {
			
    public void run() { 
        System.out.println(Thread.currentThread().getName() + " started");        
    }

    public static void main(String[] args) {
        MyThread myThread = new MyThread();
        Thread threadOne = new Thread(myThread, "Thread 1"); // creates first thread
        Thread threadTwo = new Thread(myThread, "Thread 2");  // creates second thread
        Thread threadThree = new Thread(myThread, "Thread 3"); // creates third thread
        
        threadOne.start();
        threadTwo.start();
        threadThree.start();
    }

}
	</pre>
	</div>
	
	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Thread 1 started
Thread 2 started
Thread 3 started
		</pre>
	</div>	
	
    
<div id="solution">
        <h4>2) Create multiple threads by implementing Runnable interface </h4>
	</div>

<div id="code">
	<pre class="prettyprint">
// Creates multiple threads by implementing Runnable Interface	
public class MyThread implements Runnable {

    public void run() { 
        System.out.println(Thread.currentThread().getName() + "  started");
    }
    
    public static void main(String[] args) {
        MyThread myThread = new MyThread();
        Thread threadOne = new Thread(myThread, "Thread 1"); // creates first thread
        Thread threadTwo = new Thread(myThread, "Thread 2");  // creates second thread
        Thread threadThree = new Thread(myThread, "Thread 3"); // creates third thread
        
        threadOne.start();
        threadTwo.start();
        threadThree.start();
    }

}
	</pre>
	</div>

	<div id="solution">
		<h4>Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
Thread 1 started
Thread 2 started
Thread 3 started
		</pre>
	</div>	

	<div id="comments">
		<h4>Comments on above approach:</h4>
		<ul>
            <li>Please note that same instance of Runnable should be passed to multiple threads.</li>
        </ul>
	</div>
	
	
References : <br>
<ul>
<li><a href="https://docs.oracle.com/cd/E19455-01/806-5257/6je9h032e/index.html">Oracle Docs Multithreading   </a>	</li><br>
<li><a href="https://docs.oracle.com/javase/8/docs/api/java/lang/Thread.html">Oracle Docs Thread</a>	<br><br></li>	
	</ul></div>
</body>

<?php 
    include("footer.htm");
?>
</html>
