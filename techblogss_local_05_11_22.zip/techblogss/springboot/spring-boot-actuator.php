    <?php include("../header.htm");?>

    <head>
        <title>Spring Boot actuator example</title>
        <meta name="description" content="spring boot actuator metrics, spring boot actuator health, spring boot actuator configuration,
        actuator in spring boot, spring boot health check" />
        <link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-actuator" />
    </head>

    <body>
        <?php include("../navigation.htm");?>
        
        <div id="content">
        <div id="blog">
        <div id="problem">
            <h1>Spring Boot actuator example</h1>
        </div>
        <div id="solution">
            <p>
            Using <b><i>Spring Boot Actuator</b></i> you can monitor your spring boot application. <b><i>Spring Boot Actuator</b></i> 
            exposes health and metrics from the application. This example shows how to configure actuator in <b><i>Spring Boot</b></i> 
            application.
            </p> 
        </div>
        
        <h4>Step 1) In pom.xml add spring-boot-starter-actuator dependency</h4>
        <div id="code">
        <pre class="prettyprint">
&lt;dependency&gt;
    &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
    &lt;artifactId&gt;spring-boot-starter&lt;/artifactId&gt;
&lt;/dependency&gt;
&lt;dependency&gt;
    &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
    &lt;artifactId&gt;spring-boot-starter-web&lt;/artifactId&gt;
&lt;/dependency&gt;                
&lt;dependency&gt;
    &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
    &lt;artifactId&gt;spring-boot-starter-actuator&lt;/artifactId&gt;
&lt;/dependency&gt;        </pre></div><br>
     
         <h4>Step 2) Create HelloWorldApplication class</h4>
         <p>When run, HelloWorldApplication class will start the embedded Tomcat server and will have a preconfigured Spring MVC setup.</p>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
    public class HelloWorldApplication {

    public static void main(String[] args) {
        SpringApplication.run(HelloWorldApplication.class, args);
    }
}        </div></pre><br>
 
        <h4>Step 3) Run HelloWorldApplication</h4>

        <h4>Step 4) Testing HelloWorldApplication </h4>
        Launch any browser and open <a href="http://localhost:8080/actuator" target="_blank">http://localhost:8080/actuator</a>. 
        You will see below page displayed in the broswer.
     
        <div>
            <p><img src="../images/sb_actuator_1.jpg" alt="Maven Build" style="width:500px;height:400px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    
        <h4>Step 5) Exposing more endpoints</h4>
        <p>By default only <b><i>/actuator/health</b></i> and <b><i>/actuator/info</b></i> endpoints are exposed by <b><i>Spring Boot Actuator</b></i>.
        To expose more endpoints you need to add following in the application.properties file (under src/main/resources )</p>
    
        <div id="code">
        <pre class="prettyprint">
management.endpoints.web.exposure.include=* 
        </pre></div><br>
        
        <div>
            <p><img src="../images/sb_logging.jpg" alt="Maven Build" style="width:400px;height:200px;"></p>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br>

        <div>
        Now go to <a href="http://localhost:8080/actuator" target="_blank">http://localhost:8080/actuator</a>. You will see more endpoints.
        </div>
    
        <div>
            <p><img src="../images/sb_actuator_2.jpg" alt="Maven Build" style="width:500px;height:600px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    
    
        <h4>Step 6) Exposing more details for <b><i>/actuator/health</b></i> endpoint</h4>
        <div>
        By default <a href="http://localhost:8080/actuator/health">http://localhost:8080/actuator/health</a> will display status as only
        <b><i>UP OR DOWN</b></i>. 
        <p>To expose more details you need to add following in the application.properties file (under src/main/resources )</p>
        </div>
    
        <div id="code">
        <pre class="prettyprint">
management.endpoint.health.show-details=always    </pre></div><br>
    
        <div>
            <p><img src="../images/sb_actuator_3.jpg" alt="Maven Build" style="width:400px;height:300px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br><br><br><br>
    
        <h4>Step 7) Checking details for <b><i>/actuator/metrics</b></i> endpoint</h4>
        <div>
        If you navigate to <a href="http://localhost:8080/actuator/metrics" target="_blank">http://localhost:8080/actuator/metrics</a>, you will 
        see list of metrics exposed. To view details of a particular metric, say <b>jvm memory used</b>, you need to navigate to
        <a href="http://localhost:8080/actuator/metrics/jvm.memory.used" target="_blank">http://localhost:8080/actuator/metrics/jvm.memory.used</a> 
        </div>
        <br>
    
        References : <br><br>
        <a href="https://docs.spring.io/spring-boot/docs/current/reference/html/production-ready-features.html">Spring Boot Actuator</a>    <br><br>
        </div> <!-- blog div-->
        
        <?php include("../sidebar/sidebar.htm"); ?>
    
        </div> <!-- content div -->
        
         <div id="content">
            <?php include '../blogs/entry.php';?>
        </div>
        
         <?php include("share.htm"); ?>
    </body>

    <?php 
        include("footer.htm");
    ?>
    </html>