<?php include("../header.htm"); ?>
<head>    <title>Spring Boot Data JPA tutorial</title>    <meta name="description" content="Spring Boot Data JPA tutorial" />    <link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-data-jpa-example" /></head>
<body>
    <?php include("../navigation.htm"); ?>
    <div id="content">        <div id="blog">        <div id="problem">            <h2>Spring Boot Data JPA tutorial</h2>        </div>
        <div id="solution">        <p>        <code>Spring Boot Data JPA</code> helps Java based applications access backend repository like <code>in-memory DB, Oracle DB, MongoDB, LDAP,</code> etc. and perform <code>CRUD</code> operations. It provides boilerplate code so that developers can focus on business logic.        </p> 
        <p>        <code>JPA (Java Persistence API)</code> provides specification for object/relational mapping to manage relational data.         Hibernate is one of the implementations of JPA. Spring Boot by default comes with <code>H2</code> in-memory DB which will be        used in this tutorial.        </p>        <p>        This tutorial shows how to use Spring Boot Data JPA to access a repository of Celebrities.        </p>        </div>
        <h4>Step 1) Add below dependencies to pom.xml</h4>
        <div id="code">
        <pre class="prettyprint">&lt;dependency&gt;    &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;    &lt;artifactId&gt;spring-boot-starter-data-data-jpa&lt;/artifactId&gt;&lt;/dependency&gt;
&lt;dependency&gt;    &lt;groupId&gt;com.h2database&lt;/groupId&gt;    &lt;artifactId&gt;h2&lt;/artifactId&gt;&lt;/dependency&gt;</pre></div><br>
            <h4>Step 2) Create Celebrity POJO class</h4>        <p>        Celebrity class is annotated as <code>@Entity</code> which means it will be used to persist the data in DB.         The JPA specification specifies that <code>@Entity</code> annotation should be used for POJO class that will be used as entity class.        <code>@Id</code> annotation is used as primay key and to identify a Celebrity row in the DB.        </p>             <div id="code">        <pre class="prettyprint">import javax.persistence.Entity;import javax.persistence.GeneratedValue;import javax.persistence.GenerationType;import javax.persistence.Id;@Entitypublic class Celebrity {
    @Id    @GeneratedValue(strategy = GenerationType.AUTO)    private Long id;    private String name;
    public Celebrity() {    }
    public Celebrity(Long id) {        this.id = id;    }        public Celebrity(String name) {        this.name = name;    }
    public Long getId() {        return id;    }
    public String getName() {        return name;    }
    public void setName(String name) {        this.name = name;    }    @Override    public String toString() {        return "Customer [id=" + id + ", name=" + name + "]";    }}</div></pre><br>
        <h4>Step 3) Create CelebrityRepository, CelebrityService classes</h4>        <p>        CelebrityRepository interface extends <code>CrudRepository</code> which provides CRUD operations for the entity (Celebrity)         by default. You can add more methods to query the repository like findByName, findById. The Spring Data repository will generate query        by striping the prefixes like find…By, read…By, and get…By from the method name and use rest of the method name to generate the query.        </p>     
        <div id="code">        <pre class="prettyprint">         import java.util.List;import org.springframework.data.repository.CrudRepository;    public interface CelebrityRepository extends CrudRepository&lt;Celebrity, Long> {        List&lt;Celebrity> findByName(String name);        Celebrity findById(long id);}</pre></div><br>      
        <div id="code">        <pre class="prettyprint">import java.util.List;import org.springframework.beans.factory.annotation.Autowired;import org.springframework.stereotype.Service;
@Servicepublic class CelebrityService {    @Autowired    private CelebrityRepository customerRepository;
    public void save(Celebrity customer) {        customerRepository.save(customer);    }
    public Celebrity findById(long id) {        return customerRepository.findById(id);    }
    public List&lt;Celebrity> findAll() {        return (List&lt;Celebrity>) customerRepository.findAll();    }
    List&lt;Celebrity> findByName(String name) {        return (List&lt;Celebrity>) customerRepository.findByName(name);    }
} </div></pre><br>
        <h4>Step 4) Write SpringBootDataJPAApplication class</h4>        <p>On startup ,SpringBootDataJPAApplication will call CelebrityService methods to save few records and then queries the records.</p>
        <div id="code">            <pre class="prettyprint">import org.slf4j.Logger;import org.slf4j.LoggerFactory;import org.springframework.boot.CommandLineRunner;import org.springframework.boot.SpringApplication;import org.springframework.boot.autoconfigure.SpringBootApplication;import org.springframework.context.annotation.Bean;
@SpringBootApplicationpublic class SpringBootDataJPAApplication {
    private static final Logger log = LoggerFactory.getLogger(SpringBootDataJPAApplication.class);
    public static void main(String[] args) {        SpringApplication.run(SpringBootDataJPAApplication.class, args);    }
    @Bean    public CommandLineRunner demo(CelebrityService service) {        return (args) -> {            log.info("saving customers");            service.save(new Celebrity("John Wick"));            service.save(new Celebrity("Bob Dylan"));            log.info("Customers found with findAll():");            for (Celebrity customer : service.findAll()) {                log.info(customer.toString());            }            // fetch an individual by ID            Celebrity customer = service.findById(1L);            log.info("Customer found with findById(1L):");            log.info(customer.toString());
            service.findByName("John Wick").forEach(john -> {
            log.info(john.toString());
            });        };    }}       </pre></div><br>    
        <h4>Step 5) Run SpringBootDataJPAApplication</h4>
        <div id="solution">           <h4>Console Output : </h4>        </div>
        <div id="code">            <pre class="prettyprint">2021-12-20 14:49:56.592  INFO 6152 --- [main] data.SpringBootDataJPAApplication:Started SpringBootDataJPAApplication in 4.625 seconds (JVM running for 5.377)2021-12-20 14:49:56.607  INFO 6152 --- [main] data.SpringBootDataJPAApplication:saving customers2021-12-20 14:49:56.659  INFO 6152 --- [main] data.SpringBootDataJPAApplication:Customers found with findAll():2021-12-20 14:49:56.691  INFO 6152 --- [main] o.h.h.i.QueryTranslatorFactoryInitiator  : HHH000397: Using ASTQueryTranslatorFactory2021-12-20 14:49:56.850  INFO 6152 --- [main] data.SpringBootDataJPAApplication:Customer [id=1, name=John Wick]2021-12-20 14:49:56.850  INFO 6152 --- [main] data.SpringBootDataJPAApplication:Customer [id=2, name=Bob Dylan]2021-12-20 14:49:56.866  INFO 6152 --- [main] data.SpringBootDataJPAApplication:Customer found with findById(1L):2021-12-20 14:49:56.866  INFO 6152 --- [main] data.SpringBootDataJPAApplication:Customer [id=1, name=John Wick]2021-12-20 14:49:56.897  INFO 6152 --- [main] data.SpringBootDataJPAApplication:Customer [id=1, name=John Wick]  </pre></div>            </div> <!-- blog div-->    <?php include("../sidebar/sidebar.htm"); ?>
    </div> <!-- content div -->
    <div id="content">            <?php include '../blogs/entry.php';?>    </div>           <?php include("share.htm"); ?>
    </body>
    <?php         include("footer.htm");    ?>
</html>