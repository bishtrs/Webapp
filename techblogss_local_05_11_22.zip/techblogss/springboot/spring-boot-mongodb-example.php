    <?php include("../header.htm"); ?>

    <head>
        <title>Spring Boot Mongodb example</title>
        <meta name="description" content="spring boot mongodb example, spring boot mongodb crud example" />
        <link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-mongodb-example" />
    </head>

    <body>
        <?php include("../navigation.htm"); ?>
        
        <div id="content">
        <div id="blog">
        <div id="problem">
            <h1>Spring Boot Mongodb example</h1>
        </div>
        <div id="solution">
            <p>This tutorial shows how to configure and use <code>Mongodb</code> for <code>CRUD</code> operations in a <code>Spring Boot</code> application. We will use <code>MongoTemplate</code> to invoke <code>CRUD</code> operations on <code>Mongodb</code> on a <code>User</code> type object.</p> 
        </div>
        
        <h4>Step 1) Add spring-boot-starter-data-mongodb dependency to pom.xml</h4>
        <div id="code">
        <pre class="prettyprint">
&lt;dependency&gt;
    &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
    &lt;artifactId&gt;spring-boot-starter-data-mongodb&lt;/artifactId&gt;
&lt;/dependency&gt;</pre></div><br>
        
         <h4>Step 2) Create User POJO class</h4>
        
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import java.util.Arrays;
import org.springframework.data.annotation.Id;

public class User {

    @Id
    private int id;
    private String email;
    private String[] addresses;
    
    public User() {}
    
    public User(int id, String email) {
     this.id = id;
     this.email = email;
    }

    //removed getter, setter for brevity
    
    @Override
    public String toString() {
        return "User [id=" + id + ", email=" + email + ", 
            addresses=" + Arrays.toString(addresses) + "]";
    }

    
}        </div></pre><br>
        
        <h4>Step 3) Create UserRepository class</h4>
        <p>
        UserRepository class contains <code>CRUD</code> operations that will be invoked on MongoDB. This will be injected with 
        <code>MongoTemplate</code> by Spring framework which will connect to <code>mongodb</code> server at <code>localhost:27017</code> 
        and use test collection. You can change the configuration by creating <code>MongoTemplate</code> as a seperate bean.
        </p>
         
        <div id="code">
        <pre class="prettyprint">         
package com.example.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;

@Configuration
public class MongoConfig {

    @Bean
    public MongoClient mongo() {
        ConnectionString connectionString = new ConnectionString("mongodb://localhost:27017/test");
        MongoClientSettings mongoClientSettings 
            = MongoClientSettings.builder().applyConnectionString(
                connectionString).build();
        return MongoClients.create(mongoClientSettings);
    }

    @Bean
    public MongoTemplate mongoTemplate() throws Exception {
        return new MongoTemplate(mongo(), "test");
    }

} </pre></div><br>
        
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import java.util.List;

import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import com.mongodb.client.result.UpdateResult;

@Component
public class UserRepository {

    private final MongoTemplate mongoTemplate;

    UserRepository(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    public List&lt;User> findAll() {
        return mongoTemplate.findAll(User.class);
    }

    public User findById(long id) {
        return mongoTemplate.findById(id, User.class);
    }

    public User save(User user) {
        mongoTemplate.save(user);
        return user;
    }

    public UpdateResult update(String[] addresses) {
        Query query = new Query();
        query.addCriteria(Criteria.where("id").is(1));
        Update update = new Update();
        update.set("addresses", addresses);
        //return mongoTemplate.updateFirst(query, update, User.class);
        return mongoTemplate.upsert(query, update, User.class);

    }
    
    public void deleteAll() {
        mongoTemplate.findAllAndRemove(new Query(), User.class);
    }
    
    public void delete(int id) {
        Query query = new Query();
        query.addCriteria(Criteria.where("id").is(1));
        mongoTemplate.remove(query, User.class);
    }
}
            </div>
        </pre>
        <br>

        <h4>Step 4) Write UserApplication class</h4>
        <p>UserApplication class calls <code>CRUD</code> operations on <code>MongoDB</code> for a User object using UserRepository</p>
 
       <div id="code">
            <pre class="prettyprint">
package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserApplication implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;

    public static void main(String[] args) {
        SpringApplication.run(UserApplication.class, args);

    }

    public void run(String... args) {
        String[] addresses = new String[] {"address1", "address2"};
        System.out.println("users in db " + userRepository.findAll());
        System.out.println("deleting all users in db ");
        userRepository.deleteAll();
        System.out.println("users in db " + userRepository.findAll());
        System.out.println("adding users in db ");
        userRepository.save(new User(1, "john@hotmail.com"));
        userRepository.save(new User(2, "mike@gmail.com"));
        System.out.println("users in db " + userRepository.findAll());
        System.out.println("looking for user with user id 1 in db");
        System.out.println(userRepository.findById(1));
        System.out.println("updating user in db ");
        userRepository.update(addresses);
        System.out.println(userRepository.findById(1));
    }
}            </pre></div><br>    

        <h4>Step 5) Run UserApplication</h4>
      
       <div id="solution">
            <h4>Console Output : </h4>
        </div>
        
        <div id="code">
            <pre class="prettyprint">
2021-08-18 15:43:52.576  INFO 816 --- [main] com.example.demo.UserApplication : Started UserApplication in 6.796 seconds (JVM running for 7.544)
2021-08-18 15:43:52.808  INFO 816 --- [main] org.mongodb.driver.connection : Opened connection [connectionId{localValue:2, serverValue:14}] to localhost:27017
users in db [User [id=1, email=john@hotmail.com, addresses=[address1, address2]], User [id=2, email=mike@gmail.com, addresses=null]]
deleting all users in db 
users in db []
adding users in db 
users in db [User [id=1, email=john@hotmail.com, addresses=null], User [id=2, email=mike@gmail.com, addresses=null]]
looking for user with user id 1 in db
User [id=1, email=john@hotmail.com, addresses=null]
updating user in db 
User [id=1, email=john@hotmail.com, addresses=[address1, address2]]   </pre></div>        

      
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
        
    <div id="content">
            <?php include '../blogs/entry.php';?>
    </div>
        
    <?php include("share.htm"); ?>
    </body>

    <?php 
        include("footer.htm");
    ?>
    </html>