<?php 
    include("../header.htm");
?>

<head>
    <title>Spring Boot Kafka example</title>
    <meta name="description" content="Spring Boot Kafka example" />
    <link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-kafka-example" />
</head>

<body>
        <?php include("../navigation.htm"); ?>
        
    <div id="content">
    <div id="blog">
        <div id="problem">
            <h1>Spring Boot Kafka example</h1>
        </div>
        <div id="solution">
            <p>
            <code>Kafka</code> is a distributed publish/subscribe messaging system which is highly scalable, durable and fast. It supports multiple consumers, multiple subscribers, durable messages by persisting them to disk, highly scalable and provides execellent performance.
            </p>
            <p>This example shows how to build a <b><i>Spring Boot Kafka</b></i> application. We will create a Spring Boot application which will send message to <code>Kafka</code> topic and will also consume the message published to <code>Kafka</code> topic.</p> 
        </div>
        
        <h4>Step 1) Install and configure zookeeper</h4>
        Download <code>zookeeper</code> from here <a href="http://zookeeper.apache.org/releases.html" target="_blank">http://zookeeper.apache.org/releases.html</a>
        <p>
        After extracting <code>zookeeper</code>, rename file "zoo_sample.cfg" to "zoo.cfg" (under &lt;zookeeper_dir>/conf). Then edit and change dataDir=/tmp/zookeeper to &lt;zookeeper_dir>\data .<br>
        Set JAVA_HOME=C:\Program Files\Java\jre1.8.0_261 & launch <code>zookeeper</code> using :: zkserver (under &lt;zookeeper_dir>/bin)
        </p>
        
        <h4>Step 2) Install and configure Kafka server</h4>
        Download <code>Kafka</code> from here <a href="http://kafka.apache.org/downloads.html" target="_blank">http://kafka.apache.org/downloads.html</a>
        <p>
        After extracting <code>Kafka</code>, edit &lt;kafka_dir>\server.properties and change log.dirs=/tmp/kafka-logs to &lt;kafka_dir>\kafka-logs .<br>
        Launch <code>Kafka</code> server using :: kafka-server-start.bat ../../config/server.properties
        </p>
        
        <h4>Step 3) Create pom.xml for Spring Boot Kafka Producer and Consumer application</h4>
        <p>Create a pom.xml file and add below maven dependencies.
        </p>
        
        <div id="code">
        <pre class="prettyprint">
&lt;dependency&gt;
    &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
    &lt;artifactId&gt;spring-boot-starter-web&lt;/artifactId&gt;
&lt;/dependency&gt;	

&lt;dependency&gt;
    &lt;groupId&gt;org.springframework.kafka&lt;/groupId&gt;
    &lt;artifactId&gt;spring-kafka&lt;/artifactId&gt;
&lt;/dependency&gt; </pre></div> <br>

    <h4>Step 4) Create application.yml which contains kafka configuration</h4>
    <p>
    <ul>
        <li><code>bootstrap-servers</code> : a list of host:port that producer/consumer will use to establish connection to kafa cluster</li>
        <li><code>group-id</code> : consumer group to which the consumer belongs to</li>
        <li><code>auto-offset-reset</code> : it will let consumer read a record from a partition from a particular point, default value is <code>latest</code> which means consumer will read the latest record after it starts up.</li>
        <li><code>key-deserializer</code> : name of the Class that will be use to deserialize the message key received by kafka</li>
        <li><code>value-deserializer</code> : name of the Class that will be use to serialize the message value received by kafka</li>
        <li><code>key-serializer</code> : name of the Class that will be use to serialize the message key send to kafka</li>
        <li><code>value-serializer</code> : name of the Class that will be use to serialize the message value send to kafka</li>
    </ul>
    </p><br>
    
    <div id="code">
    <pre class="prettyprint">
server: 
    port: 9000
spring:
   kafka:
     consumer:
        bootstrap-servers: localhost:9092
        group-id: group_id
        auto-offset-reset: earliest
        key-deserializer: org.apache.kafka.common.serialization.StringDeserializer
        value-deserializer: org.apache.kafka.common.serialization.StringDeserializer
     producer:
        bootstrap-servers: localhost:9092
        key-serializer: org.apache.kafka.common.serialization.StringSerializer
        value-serializer: org.apache.kafka.common.serialization.StringSerializer</div></pre><br>
        
    <p>Alternatively you can also create configuration using Java class as shown below</p>    
    <div id="code">
    <pre class="prettyprint">    
package com.example;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

@Configuration
public class KafkaProducerConfig {

    @Bean
    public ProducerFactory&lt;String, String> producerFactory() {
        Map&lt;String, Object> producerConfiguration = new HashMap<>();
        producerConfiguration.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        producerConfiguration.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        producerConfiguration.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        return new DefaultKafkaProducerFactory&lt;>(producerConfiguration);
    }

    @Bean
    public KafkaTemplate&lt;String, String> kafkaTemplate() {
        return new KafkaTemplate&lt;>(producerFactory());
    }
} </div></pre><br>

    <div id="code">
    <pre class="prettyprint">    
package com.example;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;

@Configuration
public class KafkaConsumerConfig {

    @Bean
    public ConsumerFactory&lt;String, String> consumerFactory() {
        Map&lt;String, Object> consumerConfiguration = new HashMap&lt;>();
        consumerConfiguration.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        consumerConfiguration.put(ConsumerConfig.GROUP_ID_CONFIG, "group_id");
        consumerConfiguration.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        consumerConfiguration.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        return new DefaultKafkaConsumerFactory&lt;>(consumerConfiguration);
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory&lt;String, String> kafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory&lt;String, String> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory());
        return factory;
    }

}</div></pre><br>

    <h4>Step 5) Create KafKaProducerService to publish message to a topic</h4>
    <p>
    Spring provides <code>KafkaTemplate</code> to publish a message to a <code>Kafka</code> topic. The topic will be created when <code>KafkaTemplate  send("test", message)</code> is called where "test" it the topic name. You can also create topic explicitly using following:<br> <code>kafka-topics.bat --create --topic test --partitions 1 --replication-factor 1 --bootstrap-server localhost:9092</code>
     </p>
    <div id="code">
    <pre class="prettyprint">
package com.example;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class KafKaProducerService {
    private static final Logger logger = LoggerFactory.getLogger(KafKaProducerService.class);

    @Autowired
    private KafkaTemplate&lt;String, String> kafkaTemplate;

    public void sendMessage(String message) {
        this.kafkaTemplate.send("test", message);
        logger.info(String.format("Message sent -> %s", message));
    }
}  </div>    </pre>	    <br>
    
    <h4>Step 6) Create KafkaProducerController class that will expose an endpoint to send message from browser</h4>
    <div id="code">
    <pre class="prettyprint">
package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/kafka")
public class KafkaProducerController {
    private final KafKaProducerService producerService;

    @Autowired
    public KafkaProducerController(KafKaProducerService producerService) {
        this.producerService = producerService;
    }

    @GetMapping(value = "/publish")
    public void sendMessageToKafkaTopic(@RequestParam("message") String message) {
        this.producerService.sendMessage(message);
    }
}    </div></pre><br>    
    
    <h4>Step 7) Create KafKaConsumerService that will consumer the message</h4>
    <div id="code">
    <pre class="prettyprint">
package com.example;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class KafKaConsumerService {
    private final Logger logger = LoggerFactory.getLogger(KafKaConsumerService.class);

    @KafkaListener(topics = "test", groupId = "group_id")
    public void consume(String message) {
        logger.info(String.format("Message recieved -> %s", message));
    }

}      </div></pre> <br>

 <h4>Step 8) Create KafkaApplication class to run the Spring Boot application</h4>
    <div id="code">
    <pre class="prettyprint">
package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaApplication {

    public static void main(String[] args) {
        SpringApplication.run(KafkaApplication.class, args);
    }
}        </div></pre> <br>
        
        
     <h4>Step 9) Testing KafkaApplication </h4>
     Start KafkaApplication, open any browser and launch <a href="http://localhost:9000/kafka/publish?message=hello" target="_blank">http://localhost:9000/kafka/publish?message=hello</a>
     <p>Above url will invoke <code>REST</code> endpoint <code>/kafka/publish</code> exposed by <code>KafkaProducerController</code>. It will call <code>KafKaProducerService sendMessage()</code> which will publish the message to <code>Kakfa</code> topic "test". Finally message will be consumed by <code>KafKaConsumerService consume</code> method. You will see message is published and received by above consumer as shown in below logs.
     </p>
   
    <div id="code">
    <pre class="prettyprint">
2021-02-05 13:14:29.794  INFO 21032 --- [nio-9000-exec-1] o.a.kafka.common.utils.AppInfoParser     : Kafka version : 2.0.1
2021-02-05 13:14:29.794  INFO 21032 --- [nio-9000-exec-1] o.a.kafka.common.utils.AppInfoParser     : Kafka commitId : fa14705e51bd2ce5
2021-02-05 13:14:29.812  INFO 21032 --- [ad | producer-1] org.apache.kafka.clients.Metadata        : Cluster ID: WzUf88tISwO55b5mbmMj1Q
2021-02-05 13:14:29.840  INFO 21032 --- [nio-9000-exec-1] com.example.KafKaProducerService         : Message sent -> hello
2021-02-05 13:14:29.915  INFO 21032 --- [ntainer0-0-C-1] com.example.KafKaConsumerService         : Message recieved -> hello
    </div></pre> <br>
    
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
        
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
        
    <?php include("share.htm"); ?>
    </body>

    <?php 
        include("footer.htm");
    ?>
    </html>