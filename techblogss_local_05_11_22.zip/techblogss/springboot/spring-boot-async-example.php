<?php include("../header.htm");?>

    <head>
        <title>Spring Boot @Async example</title>
        <meta name="description" content="Spring Boot @Async example" />
        <link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-async-example" />
    </head>

    <body>
        <?php include("../navigation.htm");?>
        
        <div id="content">
        <div id="blog">
        <div id="problem">
            <h1>Spring Boot @Async example</h1>
        </div>
        <div id="solution">
            <p>
            Sometimes you might have a time taking service call which you want to run asynchronously in a seperate Thread so that the calling Thread
            can be freed up and can perform other task. To do this, you have to mark that method as <code>@Async</code> and application as 
            <code>@EnableAsync</code>.
            </p>
            
            <p>
            By default Sprint Boot will create an instance of <code>TaskExecutor</code> and identify the method marked with 
            <code>@Async</code> controller and run the method asynchronously.
            </p>
            
            <p>
            Below example shows how to call UserService get method asynchronously from UserController.
            </p> 
        </div>
        
        <h4>Step 1) Add below dependency in pom.xml</h4>
    <div id="code">
        <pre class="prettyprint">&lt;dependency&gt;
    &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
    &lt;artifactId&gt;spring-boot-starter-web&lt;/artifactId&gt;
&lt;/dependency&gt;        </pre></div><br>
    
        <h4>Step 2) Create UserController class which will invoke get() and getAddress() asynchronously</h4>
        <p>CompletableFuture.allOf(user, userAddress).join() will combine the results of the multiple CompletableFuture calls.</p>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;
    private static Logger logger = LoggerFactory.getLogger(UserController.class);

    @GetMapping("/{id}")
    public String getUser(@PathVariable("id") String id) throws Exception {
        logger.info("getting user & address");
        CompletableFuture&lt;User> user = userService.get(id);
        CompletableFuture&lt;Address> userAddress = userService.getAddress(id);
        CompletableFuture.allOf(user, userAddress).join();
        logger.info("returning user details");
        return user.get().toString() + "," + userAddress.get().toString();
    }

} </div></pre><br>

        <h4>Step 3) Create UserService class which will send reponse asynchronously using CompletableFuture</h4>
        <p>get() & getAddress() methods are marked as <code>@Async</code> which means these will be invoked in a seperate thread.</p>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    private static Logger logger = LoggerFactory.getLogger(UserService.class);
    private Map&lt;String, User> users = new HashMap&lt;>();
    private Map&lt;String, Address> addresses = new HashMap<>();

    @Async
    public CompletableFuture&lt;User> get(String id) throws Exception {
        logger.info("getting user");
        Thread.sleep(2000);
        return CompletableFuture.completedFuture(users.get(id));
    }
    
    @Async
    public CompletableFuture&lt;Address> getAddress(String id) throws Exception {
        logger.info("getting user address");
        Thread.sleep(2000);
        return CompletableFuture.completedFuture(addresses.get(id));
    }

    public void create(User user) {
        users.put(user.getId(), user);
    }
    
    public void createAddress(Address address) {
        addresses.put(address.getId(), address);
    }
}     </div></pre><br>

        <h4>Step 4) Create User & Address classes as domain object</h4>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

public class User {

    private String id;
    private String firstName;
    private String lastName;
    private int age;
    
    public User() {}
        
    public User(String id, String firstName, String lastName, int age) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
    }

    // removed getter, setters

    @Override
    public String toString() {
        return "User [id=" + id + ", firstName=" + firstName + ", lastName="
                + lastName + ", age=" + age + "]";
    }
    
}    </div></pre><br>

<div id="code">
        <pre class="prettyprint">
package com.example.demo;

public class Address {

    private String id;
    private String address;

    public Address() {
    }

    public Address(String id, String address) {
        this.id = id;
        this.address = address;
    }

    // removed getter, setters
    
    @Override
    public String toString() {
        return "Address [id=" + id + ", address=" + address + "]";
    }

}   </div></pre><br>

    <h4>Step 5) Create UserApplication class</h4>
    <div id="solution">
        <p>
        Instead of using default <code>ThreadPoolTaskExecutor</code> created by Spring Boot, you can also create your own 
        <code>ThreadPoolTaskExecutor</code> in which you can specify thread pool size, thread name, etc. as shown below using
        bean name "asyncExecutor", though below will run fine even if you don't create this bean.
        </p>
    </div>  
    
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import java.util.concurrent.Executor;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@EnableAsync
@SpringBootApplication
public class UserApplication {

    public static void main(String[] args) {
        SpringApplication.run(UserApplication.class, args);
    }
    
    @Bean(name = "asyncExecutor")
    public Executor asyncExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(4);
        executor.setMaxPoolSize(16);
        executor.setQueueCapacity(125);
        executor.setThreadNamePrefix("thread-exec");
        executor.initialize();
        return executor;
    }
    
    @Bean
    public ApplicationRunner userInitializer(UserService userService) {
        return args -> {
            userService.create(new User("ironman", "Robert", "Downey", 45));
            userService.create(new User("batman", "Christian", "Bale", 36));
            userService.create(new User("superman", "Henry", "Cavill", 28));
            userService.createAddress(new Address("ironman", "New York"));
            userService.createAddress(new Address("batman", "Amsterdam"));
            userService.createAddress(new Address("superman", "London"));
        };
    }
    
}    </div></pre><br>

    <h4>Step 6) Running UserApplication</h4>
    <p>Open any browser and launch <b>http://localhost:8080/users/ironman</b>. You will see user details for the user ironman in the browser.</p>
    <p><b>
    User [id=ironman, firstName=Robert, lastName=Downey, age=45],Address [id=ironman, address=New York]    
    </b></p>
    <div id="solution">
        <h4>Console Output : </h4>
    </div>   

    <p>
    Note that in the logs below, a new thread <b><i>thread-exec1</i></b> is started in the backend to handle the get() request while 
    <b><i>thread-exec2</i></b> is started to get user address. 
    </p>    
    
    <div id="code">
            <pre class="prettyprint">
2021-09-24 20:37:18.507  INFO 5896 --- [main] com.example.demo.UserApplication         : Started UserApplication in 4.329 seconds (JVM running for 4.963)
2021-09-24 20:37:22.612  INFO 5896 --- [nio-8080-exec-1] o.a.c.c.C.[Tomcat].[localhost].[/]       : Initializing Spring DispatcherServlet 'dispatcherServlet'
2021-09-24 20:37:22.612  INFO 5896 --- [nio-8080-exec-1] o.s.web.servlet.DispatcherServlet        : Initializing Servlet 'dispatcherServlet'
2021-09-24 20:37:22.626  INFO 5896 --- [nio-8080-exec-1] o.s.web.servlet.DispatcherServlet        : Completed initialization in 14 ms
2021-09-24 20:37:22.818  INFO 5896 --- [nio-8080-exec-1] com.example.demo.UserController          : getting user & address
2021-09-24 20:37:22.834  INFO 5896 --- [thread-exec1] com.example.demo.UserService                : getting user
2021-09-24 20:37:22.834  INFO 5896 --- [thread-exec2] com.example.demo.UserService                : getting user address
2021-09-24 20:37:24.843  INFO 5896 --- [nio-8080-exec-1] com.example.demo.UserController          : returning user details
    </pre></div><br>
   
           
  
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
    
    </div> <!-- blog div-->
        
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
        
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
        
    <?php include("share.htm"); ?>
    </body>

    <?php 
        include("footer.htm");
    ?>
    </html>