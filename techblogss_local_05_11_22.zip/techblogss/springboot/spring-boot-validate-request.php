<?php include("../header.htm"); ?>

    <head>
        <title>Spring Boot validate request body</title>
        <meta name="description" content="Spring Boot validate request body" />
        <link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-validate-request" />
    </head>

    <body>
        <?php include("../navigation.htm"); ?>
        
        <div id="content">
        <div id="blog">
        <div id="problem">
            <h1>Spring Boot validate request body</h1>
        </div>
        <div id="solution">
            <p>
            When we expose any endpoint using <code>Spring Controllers</code>, it is important to validate the input request body. It not only helps
            in avoiding unnecessary service/db hit from controller layer, but also prevents security attacks like <code>SQL injection</code>.
            We can easily validate request body using Java Bean validation annotations. These annotations are present in 
            <code>javax.validation.constraints.*</code> package. You need to add <code>spring-boot-starter-validation</code> dependency in pom.xml file.
            </p>
        </div>
        
        <h4>Step 1) Add below dependencies in pom.xml</h4>
        
<div id="code">
<pre class="prettyprint">
&lt;dependencies>
    &lt;dependency>
        &lt;groupId>org.springframework.boot&lt;/groupId>
        &lt;artifactId>spring-boot-starter-web&lt;/artifactId>
    &lt;/dependency>
    &lt;dependency>
        &lt;groupId>org.springframework.boot&lt;/groupId>
        &lt;artifactId>spring-boot-starter-data-jpa&lt;/artifactId>
    &lt;/dependency>
    &lt;dependency>
        &lt;groupId>org.springframework.boot&lt;/groupId>
        &lt;artifactId>spring-boot-starter-validation&lt;/artifactId>
    &lt;/dependency>
    &lt;dependency>
        &lt;groupId>com.h2database&lt;/groupId>
        &lt;artifactId>h2&lt;/artifactId>
        &lt;scope>runtime&lt;/scope>
        &lt;/dependency>
&lt;/dependencies>   </pre></div><br>
    
         <h4>Step 2) Create User, UserController, UserExceptionHandler, UserApplication classes</h4>
         <p>
            Note that for user name we are using <code>@NotEmpty</code> & <code>@Size</code> annotations while for phone number we are using <code>@NotNull</code> annotation to validate request body which contains the user information.
         </p>
         
        <div id="code">
        <pre class="prettyprint">
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class User {

    @NotEmpty(message = "user name can't be empty")
    @Size(min=1, max=128)
    private String name;

    @NotNull(message = "phone number can't be null")
    private Long phoneNumber;

    public User() {
    }

    public User(String name, Long phoneNumber) {
        this.name = name;
        this.phoneNumber = phoneNumber;
    }
    
    // removed getter & setters
}  </div></pre><br>

<div id="code">
        <pre class="prettyprint">
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/users")
public class UserController {

    private List&lt;User> users = new ArrayList<>();

    public UserController() {
        users.add(new User("John", Long.valueOf(5417543010l)));
    }

    @GetMapping("/{id}")
    public Optional&lt;User> getUser(@PathVariable("id") String id) {
        return users.stream().filter(user -> user.getName().equalsIgnoreCase(id)).findAny();
    }

    @PostMapping("/")
    public User addUser(@Valid @RequestBody User user) {
        users.add(user);
        return user;
    }

} </div></pre><br>
    
<div id="code">
        <pre class="prettyprint">
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserApplication {

    public static void main(String[] args) {
        SpringApplication.run(UserApplication.class, args);
    }
}  </div></pre><br> 

    <h4>Step 3) Running  UserApplication</h4>
    <div id="solution">
        <p>
        Run the UserApplication and post a request to create a new User either using curl utility or POSTMAN.
        You will see that UserApplication returns 400 response code since we didn't pass any phoneNumber and hence request body
        validation fails in the UserApplication.
        </p>
    </div>
    
    <div id="largeimg">
        <p><img src="../images/springboot/sb_validate_1.jpg" alt="basic" style="width:800px;height:400px;"></p>
    </div>
    
    <div id="smallimg">
        <p><img src="../images/springboot/sb_validate_1.jpg" alt="basic" style="width:500px;height:400px;"></p>
    </div>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        
    <div id="solution">
        <p>
        Since we do not get any useful information about request failure, we need to write a custom ExceptionHandler as shown below to return meaningful error message back to caller.
        </p>
    </div>
       
    <h4>Step 4) Create UserExceptionHandler classes</h4>
    
<div id="code">
        <pre class="prettyprint">
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation
.ResponseEntityExceptionHandler;

@ControllerAdvice
public class UserExceptionHandler extends ResponseEntityExceptionHandler {

    @Override
    protected ResponseEntity&lt;Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
        HttpHeaders headers, HttpStatus status, WebRequest request) {

        Map&lt;String, Object> body = new HashMap&lt;>();
        List&lt;String> errorList = ex.getBindingResult()
                .getFieldErrors()
                .stream()
                .map(x -> x.getDefaultMessage())
                .collect(Collectors.toList());

        body.put("errors", errorList);

        return new ResponseEntity<>(body, headers, status);
    }

} </div></pre><br>
    
    <h4>Step 5) Running  UserApplication</h4>
    <div id="solution">
        <p>
        Now if you post the request, you will see below error message in response.
        </p>
    </div>
    
    <div id="largeimg">
        <p><img src="../images/springboot/sb_validate_2.jpg" alt="basic" style="width:800px;height:400px;"></p>
    </div>
    
    <div id="smallimg">
        <p><img src="../images/springboot/sb_validate_2.jpg" alt="basic" style="width:500px;height:400px;"></p>
    </div>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    
    <div id="largeimg">
        <p><img src="../images/springboot/sb_validate_3.jpg" alt="basic" style="width:800px;height:400px;"></p>
    </div>
    
    <div id="smallimg">
        <p><img src="../images/springboot/sb_validate_3.jpg" alt="basic" style="width:500px;height:400px;"></p>
    </div>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

     
    </div> <!-- blog div-->
        
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->

    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
        
    <?php include("share.htm"); ?>
    </body>

    <?php 
        include("footer.htm");
    ?>
    </html>