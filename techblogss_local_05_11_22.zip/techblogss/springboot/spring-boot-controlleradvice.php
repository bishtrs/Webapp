<?php include("../header.htm"); ?>

    <head>
        <title>Spring Boot controlleradvice exception handler example</title>
        <meta name="description" content="Spring Boot controlleradvice exception handler example" />
        <link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-controlleradvice" />
    </head>

    <body>
        <?php include("../navigation.htm"); ?>
        
        <div id="content">
        <div id="blog">
        <div id="problem">
            <h1>Spring Boot @Controlleradvice Exception handler example</h1>
        </div>
        <div id="solution">
            <p>
            By default <code>Spring Boot</code> shows a default or custom error page in case any <code>Exception</code> occurs.
            Sometimes instead of displaying an error page, you can return <code>ResponseEntity</code> with the appropriate HTTP status code 
            and exception details. This can be achieved with the help of <code>@ExceptionHandler</code> and <code>@ControllerAdvice</code> annotations.
            </p>
            <p>You can also just use <code>@ExceptionHandler</code> for a particular endpoint or you can reuse the same <code>@ExceptionHandler</code>
            for whole application by moving the code to a seperate class and marking the class with <code>@ControllerAdvice</code> annotation.
            </p>
        </div>
        
        <h4>Step 1) Add below dependencies in pom.xml</h4>
        
<div id="code">
   <pre class="prettyprint">
&lt;dependencies&gt;
    &lt;dependency&gt;
        &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
        &lt;artifactId&gt;spring-boot-starter-web&lt;/artifactId&gt;
    &lt;/dependency&gt;        
&lt;/dependencies&gt;        </pre></div><br>
    
         <h4>Step 2) Create User, UserController, UserService, UserApplication classes</h4>
         
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

public class User {

    private String id;
    private String firstName;
    private String lastName;

    // removed getter, setters, constructor

    @Override
    public String toString() {
        return "User [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + "]";
    }

}      </div></pre>



<div id="code">
        <pre class="prettyprint">
package com.example.demo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;
    private static Logger logger = LoggerFactory.getLogger(UserController.class);

    @GetMapping("/{id}")
    public User get(@PathVariable("id") String id) throws Exception {
        logger.info("getting user");
        return userService.get(id);
    }

}  </div></pre><br>
    
<div id="code">
        <pre class="prettyprint">
package com.example.demo;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    private static Logger logger = LoggerFactory.getLogger(UserService.class);
    private Map&lt;String, User> users = new HashMap&lt;>();

    public User get(String id) {
        logger.info("getting user");
        if (!users.containsKey(id)) {
            throw new UserNotFoundException();
        }
        return users.get(id);
    }

    public void create(User user) {
        users.put(user.getId(), user);
    }
} </div></pre><br>

<div id="code">
        <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class UserApplication {

    public static void main(String[] args) {
        SpringApplication.run(UserApplication.class, args);
    }
    
    @Bean
    public ApplicationRunner userInitializer(UserService userService) {
        return args -> {
            userService.create(new User("tom", "Tom", "Cruise"));
            userService.create(new User("harry", "Harry", "Potter"));
            userService.create(new User("bond", "James", "Bond"));
        };
    }
}     </div></pre><br>
    
    <h4>Step 3) Create UserNotFoundException and UserExceptionHandler classes</h4>
    <div id="solution">
    <p>
    <code>UserNotFoundException</code> is our custom exception class which is a Runtime exception and is thrown when a user is not found.
    <code>UserExceptionHandler</code> is the exception handler class which handles <code>UserNotFoundException</code> thrown by the application
    and is annotated with <code>@ControllerAdvice</code> which means it will handle exceptions thrown from anywhere in the application.
    </p>
    </div>
    
    <div id="code">
        <pre class="prettyprint">
package com.example.demo;

public class UserNotFoundException extends RuntimeException {

    private static final long serialVersionUID = 1L;

}  </div></pre><br>

    <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class UserExceptionHandler {

    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity&lt;Object> userNotFoundException() {
        return new ResponseEntity&lt;>("User not found", HttpStatus.NOT_FOUND);
    }

}   </div></pre><br>

   
     <h4>Step 4) Running  UserApplication </h4>
     <p>Run the UserApplication and open any browser and launch</p> <a href="http://localhost:8080/users/ironman" target="_blank">http://localhost:8080/users/ironman</a> 
     <p>You will see below message displayed on the browser.</p>
     <p><b>User not found</b></p><br><br>

    <h4>Using ExceptionHandler locally</h4>
    <div id="solution">
    <p>
    Note that if you don't want to create a global exception handler and want to use the exception handler only for a particular controller or
    endpoint, then you do not need to use a seperate <code>UserExceptionHandler</code> class and no need to annotate with
    <code>@ControllerAdvice</code>, instead you can add the logic in the particular controller itself as shown below. 
    </p>
    </div>     
 
    <div id="code">
        <pre class="prettyprint">
@Autowired
private UserService userService;
private static Logger logger = LoggerFactory.getLogger(UserController.class);

@GetMapping("/{id}")
public User get(@PathVariable("id") String id) throws Exception {
    logger.info("getting user");
    return userService.get(id);
}
    
@ExceptionHandler(UserNotFoundException.class)
public ResponseEntity&lt;Object> userNotFoundException() {
    return new ResponseEntity&lt;>("User not found", HttpStatus.NOT_FOUND);
}</pre></div><br><br><br><br><br>
 
    </div> <!-- blog div-->
        
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->

    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
        
    <?php include("share.htm"); ?>
    </body>

    <?php 
        include("footer.htm");
    ?>
    </html>