<?php include "../header.htm";?>

<head>
    <title>How to create war file using maven in spring boot</title>
	<meta name="description" content="How to create war file using maven in spring boot" />
	<link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-create-war-file" />
</head>

<body>
	<?php include("../navigation.htm");?>
   	
	<div id="content">
	<div id="problem">
		<h1>How to create war file using maven in spring boot</h1>
	</div>
    
	<div id="solution">
        <p>
        When you want to deploy a <code>Spring Boot</code> application to an external servlet container like <code>Tomcat</code>, you need to create
        a <code>WAR</code> file. To generate a <code>WAR</code> file using <code>maven</code> in a <code>Spring Boot</code> application, you need to follow below steps: 
        </p>        
	</div>

    <div id="pom">    
    <h4>Step 1) pom.xml changes</h4>
    <p>
    1. Change packaging from JAR to WAR &lt;packaging>war&lt;/packaging><br>
    2. Change the scope to <code>provided</code> so that Spring Boot plugin will not add the libraries to the default WEB-INF/lib.
    </p>
    
	<div id="code">
    <pre class="prettyprint">
&lt;dependencies&gt;
    &lt;dependency&gt;
        &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
        &lt;artifactId&gt;spring-boot-starter-web&lt;/artifactId&gt;
    &lt;/dependency&gt;
    
    &lt;dependency&gt;
        &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
        &lt;artifactId&gt;spring-boot-starter-tomcat&lt;/artifactId&gt;
        &lt;scope>provided&lt;/scope>
    &lt;/dependency&gt;
&lt;/dependencies&gt;
</pre>
	</div>
    </div>
    
    <br>
	
	<h4>Step 2) Create SampleWebApplication class which extends SpringBootServletInitializer</h4>
    <p>When you extend SpringBootServletInitializer, you also need to override </code>configure</code> method.</p>
     
    <div id="code">
    <pre class="prettyprint">import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication
public class SampleWebApplication extends SpringBootServletInitializer {

    public static void main(String[] args) {
        SpringApplication.run(SampleWebApplication.class, args);
    }

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(SampleWebApplication.class);
    }
}</div></pre> <br>

    <h4>Step 3) Create SampleController class</h4>
    <p>When you extend SpringBootServletInitializer, you also need to override </code>configure</code> method.</p>
	
    <div id="code">
    <pre class="prettyprint">import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SampleController {

    @GetMapping
    public String hello() {
        return "This is sample spring boot web application";
    }

}</div></pre> <br>	

    <h4>Step 4) Build application</h4>
    <p>
    Build the application using <code>maven (mvn clean install)</code>, you will see that a <code>WAR</code> file is generated in the target folder.
    </p>
	
    <div>
    When you deploy the war file in an external container like Tomcat, the application will be accessible at <a href="http://localhost/&lt;war file name>:8080">http://localhost/&lt;war file name>:8080<a>
    instead of <a href="http://localhost:8080">http://localhost:8080</a>.
    </div>
    
	</div>
    
     <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
</body>

<?php include("footer.htm");?>

</html>