<?php include("../header.htm");?>

<head>
    <title>Spring Boot Bean configuration</title>
	<meta name="description" content="Spring Boot Bean configuration, Spring Boot @Bean example" />
	<link rel="canonical" href="https://www.techblogss.com/springboot/sb_bean" />
</head>

<body>
	<?php include("../navigation.htm");	?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>Spring Boot Bean configuration example</h1>
        <p><code>@Bean</code> annotation is a method-level annotation and is invoked when the class is marked with
        <code>@Configuration</code> annotation.
        </p>
	</div>
	<div id="solution">
        <h3>1) This example shows how to configure a class as Spring Bean using <code>@Bean</code> annotation and use it in application.
        </h3> 
	</div>

    <h4>Step 1) Create pom.xml and add below maven dependency</h4>
    
	<div id="code">
    <pre class="prettyprint">
&lt;dependencies&gt;
    &lt;dependency&gt;
        &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
        &lt;artifactId&gt;spring-boot-starter&lt;/artifactId&gt;
    &lt;/dependency&gt;
&lt;/dependencies&gt;
</pre>
	</div>
    
	<br>
	 <h4>Step 2) Create Component class and BeanDemoApplication class</h4>
     <p><b><i>Spring Boot</b></i> has an interface <b><i>ApplicationRunner</b></i>, which can be used to run code after application startup. 
     When <b><i>Spring Boot</b></i> detects a bean of type <b><i>ApplicationRunner</b></i>, it will invoke its run method after application has started.</p>
     
	<div id="code">
    <pre class="prettyprint">
package com.example.demo;

public interface Printer {
    void print(String data);
}
	</div>
	</pre>

<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.stereotype.Component;

@Component
public class SimplePrinter implements Printer {
	
    public void print(String data) {
        System.out.println(data);
    }

}	</div></pre>

<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class BeanDemoApplication {
	
    public static void main(String[] args) {
        SpringApplication.run(BeanDemoApplication.class, args);
    }
	
    @Bean
    public ApplicationRunner printRunner(Printer printer) {
        return args -> {printer.print("Hello from BeanDemoApplication");};
    }

} 	</div></pre><br>
    
 
    <h4>Step 3) Running BeanDemoApplication</h4>
    
    <div id="solution">
		<h4>Console Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
2019-08-29 19:03:58.306  INFO 2080 --- [main] com.example.demo.BeanDemoApplication     : Starting BeanDemoApplication on ssss-PC with PID 2080 (C:\Dev\eclipse\workspace\SpringBoot\target\classes started by sss in C:\Dev\eclipse\workspace\SpringBoot)
2019-08-29 19:04:00.261  INFO 2080 --- [main] o.s.web.context.ContextLoader            : Root WebApplicationContext: initialization completed in 1848 ms
2019-08-29 19:04:00.882  INFO 2080 --- [main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat started on port(s): 8080 (http) with context path ''
2019-08-29 19:04:00.886  INFO 2080 --- [main] com.example.demo.BeanDemoApplication     : Started BeanDemoApplication in 3.15 seconds (JVM running for 3.639)
Hello from BeanDemoApplication		</pre></div>		
	
    <br>
    <div id="solution">
        <h3>2) This example shows how to configure a application configuration class as Spring Bean and use it in application.</h3> 
	</div>
    
    <h4>Step 1) Create pom.xml as shown in Example above</h4>
    
    <h4>Step 2) Create AppConfiguration interface and BeanDemoApplication class</h4>
    
    <h5>Create AppConfiguration.java</h5>
	<div id="code">
    <pre class="prettyprint">
package com.example.demo;

public interface AppConfiguration {
   String getName();
}
	</div>
	</pre>

    <h5>Create resources/application.properties</h5>
<div id="code">
    <pre class="prettyprint">
app.name=BeanDemoApplication
	</div>
	</pre>
    <h5>Create BeanDemoApplication.java</h5>
<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class BeanDemoApplication implements CommandLineRunner {
	
    @Autowired  private AppConfiguration appName;
	
    @Bean
    public AppConfiguration getAppName(@Value("${app.name}") String appName) {
        return () -> appName;
    }
	
    public static void main(String[] args) {
        SpringApplication.run(BeanDemoApplication.class, args);
    }
	
    @Override
    public void run(String... args) throws Exception {
        System.out.println("Application name: {}" + appName.getName());
    }
} 	</div></pre><br>
    
    <h4>Step 3) Running BeanDemoApplication</h4>
    
    <div id="solution">
		<h4>console Output : </h4>
	</div>
    
    <div id="code">
    <pre class="prettyprint">
2019-08-30 20:40:29.608  INFO 1796 --- [main] com.example.demo.BeanDemoApplication     : Starting BeanDemoApplication on ssss-PC with PID 1796 (C:\Dev\eclipse\workspace\SpringBoot\target\classes started by sss in C:\Dev\eclipse\workspace\SpringBoot)
2019-08-30 20:40:32.144  INFO 1796 --- [main] o.s.s.concurrent.ThreadPoolTaskExecutor  : Initializing ExecutorService 'applicationTaskExecutor'
2019-08-30 20:40:32.601  INFO 1796 --- [main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat started on port(s): 8080 (http) with context path ''
2019-08-30 20:40:32.606  INFO 1796 --- [main] com.example.demo.BeanDemoApplication     : Started BeanDemoApplication in 3.59 seconds (JVM running for 4.081)
Application name: BeanDemoApplication	</div></pre>
    
    </div> <!-- blog div-->
        
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
    
     <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>
</html>