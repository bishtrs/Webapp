<?php include("../header.htm"); ?>

    <head>
        <title>Spring boot method execution time annotation</title>
        <meta name="description" content="Spring Boot validate request body" />
        <link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-measure-execution-time" />
    </head>

    <body>
        <?php include("../navigation.htm"); ?>
        
        <div id="content">
        <div id="blog">
        <div id="problem">
            <h1>Spring boot method execution time using annotation</h1>
        </div>
        <div id="solution">
            <p>
            In this example we will show how to measure time taken by a REST API or any method in a Spring boot application. We will use annotation
            & Around advice so that we can measure time in a declarative way, else the code gets cluttered with time measuring logic.
            </p>
        </div>
        
        <h4>Step 1) Add below dependencies in pom.xml</h4>
        
<div id="code">
<pre class="prettyprint">
&lt;dependencies>
    &lt;dependency>
        &lt;groupId>org.springframework.boot&lt;/groupId>
        &lt;artifactId>spring-boot-starter-web&lt;/artifactId>
    &lt;/dependency>
    &lt;dependency>
        &lt;groupId>org.springframework.boot&lt;/groupId>
        &lt;artifactId>spring-boot-starter-aop&lt;/artifactId>
    &lt;/dependency>
&lt;/dependencies>   </pre></div><br>

        <h4>Step 2) Write MeasureTime annotation, MeasureTimeAdvice class</h4>
         <p>
            MeasureTime annotation will be used at method level for the methods for which we want to measure time. MeasureTimeAdvice is a Around 
            advice that contains logic to measure time taken by the method.
         </p>
         
        <div id="code">
        <pre class="prettyprint">
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface MeasureTime {

}  </div></pre><br>

<div id="code">
        <pre class="prettyprint">
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

@Aspect
@Component
public class MeasureTimeAdvice {
	
    private static Logger logger = LoggerFactory.getLogger(MeasureTimeAdvice.class);

    @Around("@annotation(com.example.demo.MeasureTime)")
    public Object measureTime(ProceedingJoinPoint point) throws Throwable {
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        Object object = point.proceed();
        stopWatch.stop();
        logger.info("Time take by " + point.getSignature().getName() + "() method is " 
            + stopWatch.getTotalTimeMillis() + " ms");
        return object;
    }
}</div></pre><br>
    
        <h4>Step 3) Create User, UserController, UserExceptionHandler, UserApplication classes</h4>
               
        <div id="code">
        <pre class="prettyprint">
public class User {

    private String name;
    private String age;

    public User() {
    }

    public User(String name, String age) {
        this.name = name;
        this.age = age;
    }

    // removed getter, setters

} </div></pre><br>

<div id="code">
        <pre class="prettyprint">
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/users")
public class UserController {

    private List&lt;User> users = new ArrayList&lt;>();

    public UserController() {
        users.add(new User("Vladimir", "35"));
    }

    @MeasureTime
    @GetMapping("/{id}")
    public Optional&lt;User> getUser(@PathVariable("id") String id) {
        return users.stream().filter(user -> user.getName().equalsIgnoreCase(id)).findAny();
    }
	
}</div></pre><br>
    
<div id="code">
        <pre class="prettyprint">
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserApplication {

    public static void main(String[] args) {
        SpringApplication.run(UserApplication.class, args);
    }

} </div></pre><br> 

    <h4>Step 4) Running  UserApplication</h4>
    <div id="solution">
        <div>
        Run the UserApplication and launch this url <a href="http://localhost:8080/users/Vladimir" target="_blank">http://localhost:8080/users/Vladimir</a>
        </div>
    </div>
    
    <p>Observe the logs below which shows the log messages from the MeasureTimeAdvice class. It prints time taken by the rest api /users.</p>    
    <div id="code">
        <pre class="prettyprint">2022-06-02 17:19:09.520  INFO 15572 --- [nio-8080-exec-1] com.example.demo.MeasureTimeAdvice       : Time take by getUser() method is 28 ms</pre></div>
        
    </div> <!-- blog div-->
        
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->

    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
        
    <?php include("share.htm"); ?>
    </body>

    <?php 
        include("footer.htm");
    ?>
    </html>