<?php include 'header.php';?>

<head>
    <title>Spring Boot Hello world example</title>
    <meta name="description" content="This example shows how to build and launch your first Spring Boot Hello world application" />
    <link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-helloworld-example" />
</head>

<body>
    <?php 
        include("navigation.htm");
    ?>
        
    <div id="content">
        <div id="blog" style="float:left;">
        <div id="problem">
            <h1>Spring Boot Hello world example</h1>
        </div><br>
        
        <div id="solution">
            <h2>This example shows how to build and launch your first <b><i>Spring Boot</b></i> Hello world application.</h2> 
            <p>We will use <b><i>spring-boot-starter-web</b></i> maven dependency as this application is a web application and will 
            expose a REST endpoint. When we invoke this REST endpoint, it will simply print "Hello World" message.</p>
        </div><br>
        
        <h3>Step 1) Create pom.xml</h3>
	The <b><i>spring-boot-starter-web</b></i> will pull in all the dependencies needed to start a basic Spring Boot application.
	<div id="code">
    <pre class="prettyprint">
&lt;?xml version="1.0" encoding="UTF-8"?&gt;
&lt;project xmlns="http://maven.apache.org/POM/4.0.0" 
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd"&gt;
	
    &lt;modelVersion&gt;4.0.0&lt;/modelVersion&gt;
	
    &lt;parent&gt;
        &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
        &lt;artifactId&gt;spring-boot-starter-parent&lt;/artifactId&gt;
        &lt;version&gt;2.1.6.RELEASE&lt;/version&gt;
        &lt;relativePath/&gt;
    &lt;/parent&gt;
	
    &lt;groupId&gt;com.example&lt;/groupId&gt;
    &lt;artifactId&gt;demo&lt;/artifactId&gt;
    &lt;version&gt;0.0.1-SNAPSHOT&lt;/version&gt;
    &lt;name&gt;demo&lt;/name&gt;
    &lt;description&gt;Spring Boot Hello World&lt;/description&gt;

    &lt;properties&gt;
        &lt;java.version&gt;1.8&lt;/java.version&gt;
    &lt;/properties&gt;

    &lt;dependencies&gt;
        &lt;dependency&gt;
            &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
            &lt;artifactId&gt;spring-boot-starter-web&lt;/artifactId&gt;
        &lt;/dependency&gt;

    &lt;/dependencies&gt;
    &lt;!-- To create an executable jar --&gt;
    &lt;build&gt;
        &lt;plugins&gt;
            &lt;plugin&gt;
                &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
                &lt;artifactId&gt;spring-boot-maven-plugin&lt;/artifactId&gt;
            &lt;/plugin&gt;
        &lt;/plugins&gt;
    &lt;/build&gt;

&lt;/project&gt;    </pre>
	</div>
         
        <br>
         <h3>Step 2) Create HelloWorldApplication class</h3>
         <p>When run, HelloWorldApplication class will start the embedded Tomcat server and will have a preconfigured Spring MVC setup.</p>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloWorldApplication {

    public static void main(String[] args) {
        SpringApplication.run(HelloWorldApplication.class, args);
    }
}       </div>
        </pre>
        <br>
    <h3>Step 3) Create HelloWorldController class</h3>
    <p>HelloWorldController will expose an endpoint for Hello World Spring Boot application. <b><i>@GetMapping</b></i> annotation maps the hello method to every GET request that arrives at /.</p>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloWorldController {

    @GetMapping("/")
    public String hello() {
        return "Hello World";
    }
}        </pre>	
        </div> <br>
        
    <h3>Step 4) Building HelloWorldApplication</h3>
        <p>
        a) To build Hello World Spring Boot application in eclipse, you can right click on HelloWorldApplication project
        , select <b>Run as </b>&rarr; <b>Maven build </b>. In Goals provide <b>clean install</b><br>
        <p>
        
        <div>
            <p><img src="../images/sb_maven.jpg" alt="Build Spring Boot Hello World" title="Build Spring Boot Hello World"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        <p>
        b) To build Hello World Spring Boot application from command prompt, use following command &rarr; <b>mvn clean install</b>.
        <br><br>
        </p>
    
     <h3>Step 5) Running HelloWorldApplication</h3>
     <p>
        a) To Run Hello World Spring Boot application in eclipse, you can right click on HelloWorldApplication class
        , select <b>Run as </b>&rarr; <b>Java Application</b><br><br>
        b) To Run Hello World Spring Boot application from command prompt, use following command &rarr; <b>java -jar demo-0.0.1-SNAPSHOT.jar</b></p>
        
    <div id="solution">
            <h3>Output : </h3>
        </div>
        
        <div id="code">
            <pre class="prettyprint">
2019-08-07 09:15:16.753  INFO 148 --- [main] o.s.b.w.embedded.tomcat.TomcatWebServer  : Tomcat started on port(s): 8080 (http) with context path ''
2019-08-07 09:15:16.758  INFO 148 --- [main] com.example.demo.HelloWorldApplication   : Started HelloWorldApplication in 3.87 seconds (JVM running for 4.344)          </pre>
        </div><br>
        
     <h3>Step 6) Testing HelloWorldApplication </h3>
     Open any browser and launch <a href="http://localhost:8080" target="_blank">http://localhost:8080</a>. 
     <p>You will see 'Hello World' message displayed in the broswer.</p><br><br>
     
        <div>
            <p><img src="../images/sb_helloworld.jpg" alt="Hello World Testing" title ="Hello World Testing" style="width:700px;height:400px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br>
        
    References : <br><br>
    <a href="https://docs.spring.io/spring-boot/docs/current/reference/html/getting-started-first-application.html">Spring Boot First Application</a>	<br><br>
      </div> <!-- blog div-->
        
       <?php include("../sidebar/sidebar.htm"); ?>
    
        </div> <!-- content div -->
        
         <div id="content">
            <?php include '../blogs/entry.php';?>
        </div>
        
         <?php include("share.htm"); ?>
    </body>

    <?php 
        include("footer.htm");
    ?>
    </html>