    <?php 
        include("../header.htm");
    ?>

    <head>
        <title>Spring Boot Rest Template</title>
        <meta name="description" content="Spring Boot Rest Template, RestTemplate in Spring Boot, RestTemplate get example,
        Spring Boot ResponseEntity, RestTemplate postforobject example, RestTemplate getforentity, RestTemplate query parameters" />
        <link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-rest-template" />
    </head>

    <body>
        <?php 
            include("navigation.htm");
        ?>
        
        <div id="content">
        <div id="blog" style="float:left;">
        <div id="problem">
            <h2>Spring Boot Rest Template examples</h2>
        </div>
        <div id="solution">
            <p>
            <b><i>RestTemplate</b></i> class is a synchronous client to perform HTTP requests provided by Spring. <b><i>RestTemplate</b></i>
            is used by the applications to consume the web services.
            </p> 
            <p>
                <b><i>RestTemplate</b></i> class contains following useful methods : 
                <ul>
                    <li><b><i>delete(String url</b></i>) : deletes the resources at the specified URI.</li>
                    <li><b><i>exchange(String url, HttpMethod method)</b></i> : executes the HTTP method to the given URI template, writing the given request entity
                    to the request, and returns the response as ResponseEntity.</li>
                    <li><b><i>exchange(RequestEntity&lt;?> requestEntity, Class&lt;T> responseType)</b></i> executes the request specified in the
                    given RequestEntity and return the response as ResponseEntity.</li>
                    <li><b><i>execute(String url, HttpMethod method)</b></i> : executes the HTTP method to the given URI template, writing the given 
                    request entity to the request, and returns the response as ResponseEntity.</li>
                    <li>
                        <b><i>getForEntity(String url, Class&lt;T> responseType)</b></i> : retrieves a representation by doing a GET on the URI 
                        template.
                    </li>
                    <li><b><i>getForObject(String url)</b></i> : retrieves a representation by doing a GET on the URI template.</li>
                    <li><b><i>postForEntity()</b></i> : creates a new resource by POSTing the given object to the URI template, and returns 
                    the response as HttpEntity.</li>
                    <li><b><i>postForObject(String url)</b></i> : creates a new resource by POSTing the given object to the URL, and returns the 
                    response as ResponseEntity.</li>
                </ul>
            </p>
        <p>     
           This examples below show how to use RestTemplate <b><i>getForEntity(), exchange(), getForObject(), delete(), postForObject()</b></i> methods.
          </p>
        </div>
        
        <h3>1) Create movie service application as shown below</h3>
        <h4>Create pom.xml file</h4>
        
        <div id="code">
        <pre class="prettyprint">
&lt;?xml version="1.0" encoding="UTF-8"?&gt;
&lt;project xmlns="http://maven.apache.org/POM/4.0.0" 
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd"&gt;
       
    &lt;modelVersion&gt;4.0.0&lt;/modelVersion&gt;
        
    &lt;parent&gt;
        &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
        &lt;artifactId&gt;spring-boot-starter-parent&lt;/artifactId&gt;
        &lt;version&gt;2.1.6.RELEASE&lt;/version&gt;
        &lt;relativePath/&gt;
    &lt;/parent&gt;
        
    &lt;groupId&gt;com.example&lt;/groupId&gt;
    &lt;artifactId&gt;movie-service&lt;/artifactId&gt;
    &lt;version&gt;0.0.1-SNAPSHOT&lt;/version&gt;
    &lt;name&gt;movie-service&lt;/name&gt;
    &lt;description&gt;Demo project for Spring Boot&lt;/description&gt;

    &lt;properties&gt;
        &lt;java.version&gt;1.8&lt;/java.version&gt;
    &lt;/properties&gt;

    &lt;dependencies&gt;
        &lt;dependency&gt;
            &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
            &lt;artifactId&gt;spring-boot-starter&lt;/artifactId&gt;
        &lt;/dependency&gt;

    &lt;dependency&gt;
            &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
            &lt;artifactId&gt;spring-boot-starter-web&lt;/artifactId&gt;
    &lt;/dependency&gt;		
                   
    &lt;/dependencies&gt;
    &lt;!-- To create an executable jar --&gt;
    &lt;build&gt;
        &lt;plugins&gt;
            &lt;plugin&gt;
                &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
                &lt;artifactId&gt;spring-boot-maven-plugin&lt;/artifactId&gt;
            &lt;/plugin&gt;
        &lt;/plugins&gt;
    &lt;/build&gt;
        
&lt;/project&gt;        </pre>
        </div>
        <br>
        
         <h4>Create Movie, MovieRestController & MovieServiceApplication classes</h4>
        <div id="code">
        <pre class="prettyprint">
public class Movie {

    private String title;
    private String genre;

    public Movie() {}

    public Movie(String title, String genre) {
        this.title = title;
        this.genre = genre;
    }

    public String getTitle() {
        return title;
    }

    public String getGenre() {
        return genre;
    }

    @Override
    public String toString() {
        return "Movie [title=" + title + ", genre=" + genre + "]";
    }

}        </div>
        </pre>
        <br>
        
        <div id="code">
        <pre class="prettyprint">
package com.example;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MovieRestController {
	
    List&lt;Movie> movies = new ArrayList<>();
        
    public MovieRestController() {
        movies.add(new Movie("Lord of the Rings", "Fantasy"));
        movies.add(new Movie("The Specialist", "Thriller"));
    }
        
    @RequestMapping(value = "/movies") 
    public List&lt;Movie> getMoviesList() {
        System.out.println("returning list of movies " + movies);
        return movies;
    }
        
    @RequestMapping(value = "/movie/{id}") 
    public Movie getMovie(@PathVariable int id) {
        System.out.println("returning movie " + movies.get(id));
        return movies.get(id);
    }
        
    @RequestMapping(value = "/movie/{id}" , method = RequestMethod.DELETE)
    public Movie deleteMovie(@PathVariable int id) {
        System.out.println("removing movie " + movies.get(id));
        return movies.remove(id);
    }
        
    @RequestMapping(value = "/movie" , method = RequestMethod.POST) 
    public Movie addMovie(@RequestBody Movie movie) {
        System.out.println("adding movie " + movie);
        movies.add(movie);
        return movie;
    }

    @RequestMapping(value = "/movie")
    public Movie getMovie(@RequestParam int id, @RequestParam String genre) {
        Movie movie = movies.get(id);
        if (genre.equalsIgnoreCase(movie.getGenre())) {
            System.out.println("returning movie " + movies.get(id));
            return movies.get(id);
        }
        return null;
    }    

}        </div>
        </pre>	
        <br>
        
        <div id="code">
        <pre class="prettyprint">
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(MovieServiceApplication.class, args);
    }

}      </div>
        </pre>
        <br>

<h4>Launch  MovieServiceApplication</h4>      
  Launch <a href="http://localhost:8080/movies" target="_blank">http://localhost:8080/movies</a> in browser and you will see the list of movies.

<h3>2) Create movie client application that will consume movie service created above</h3>  
    <h4>Create MovieClientApplication to launch client application that consumes movie service APIs</h4>
          <div id="code">
        <pre class="prettyprint">
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class MovieClientApplication {
	
    @Bean
    RestTemplate restTemplate() {
        return new RestTemplate();
    }
        
    public static void main(String[] args) {
        SpringApplication.run(MovieClientApplication.class, args);
    }

}  </div>
        </pre>
        <br>
        
    <h4>Create application.yml file </h4>
  <div id="code">
        <pre class="prettyprint">       
spring:
  application:
    name: movie-client

server:
  port: 8081 </div>
        </pre>
        <br>
<h4>a) Create DeleteMovieClientApplication which shows how to use RestTemplate delete method </h4>
Launch <a href="http://localhost:8081/delete/movie/0" target="_blank">http://localhost:8081/delete/movie/0</a> in browser and you will 
see that one movie is removed <br>from the list of  movies.
          <div id="code">
        <pre class="prettyprint">
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/delete")
public class DeleteMovieClientApplication {
	
    @Autowired
    RestTemplate restTemplate;

    @RequestMapping("/movie/{id}")
    public void deleteMovie(@PathVariable int id) {
        this.restTemplate.delete("http://localhost:8080/movie/"+id);
    }
	
}    </div>
        </pre>
        <br>


<h4>b) Create GetMovieClientApplication showing usage of RestTemplate getForObject()</h4>
<p>This application uses RestTemplate <b><i>getForObject()</b></i> method to call movie service. <b><i>getForObject()</b></i> returns the response
 type that is passed as the argument.</p>
Launch <a href="http://localhost:8081/getForObject/movies" target="_blank">http://localhost:8081/getForObject/movies</a> in browser and you will 
see the list of movies.<br>
Launch <a href="http://localhost:8081/getForObject/movie/0" target="_blank">http://localhost:8081/getForObject/movie/0</a> in browser and you will 
see movie details.

          <div id="code">
        <pre class="prettyprint">
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/getForObject/")
public class GetMovieClientApplication {

    @Autowired
    RestTemplate restTemplate;

    @RequestMapping("/movies")
    public String getMovieList() { 
        return this.restTemplate.getForObject("http://localhost:8080/movies", String.class);
    }
	
    @RequestMapping("/movie/{id}")
    public Movie getMovie(@PathVariable int id) { 
        return this.restTemplate.getForObject("http://localhost:8080/movie/"+id, Movie.class);
    }
	
}   </div>
        </pre>
        <br>

<h4>c)  Create GetMovieClientApplication showing usage of RestTemplate getForEntity()</h4>
    <div id="solution">
        <p>This application uses RestTemplate <b><i>getForEntity()</b></i> method to call movie service. <b><i>getForEntity()</b></i> returns 
        ResponseEntity as the response type. ResponseEntity is extension of HttpEntity that adds a HttpStatus status code.
        </p>
    </div>
Launch <a href="http://localhost:8081/getForEntity/movies" target="_blank">http://localhost:8081/getForEntity/movies</a> in browser and you will 
see the list of movies.<br>
Launch <a href="http://localhost:8081/getForEntity/movie/1" target="_blank">http://localhost:8081/getForEntity/movie/1</a> in browser and you will 
see movie details.

          <div id="code">
        <pre class="prettyprint">
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/getForEntity/")
public class GetMovieClientApplication {

    @Autowired
    RestTemplate restTemplate;

    @RequestMapping("/movies")
    public ResponseEntity&lt;String> getMovieList() { 
        ResponseEntity&lt;String> response 
            = this.restTemplate.getForEntity("http://localhost:8080/movies", String.class);
        System.out.println(response.getStatusCode());
        return response;
    }
	
    @RequestMapping("/movie/{id}")
    public ResponseEntity&lt;Movie> getMovie(@PathVariable int id) { 
        ResponseEntity&lt;Movie> response 
            = this.restTemplate.getForEntity("http://localhost:8080/movie/"+id, Movie.class);
        System.out.println(response.getStatusCode());
        System.out.println(response.getBody());
        return response;
    }

}  </div>
        </pre>
        <br>

<h4>d) Create GetMovieClientApplication showing usage of RestTemplate exchange()</h4>
    <div id="solution">
        <p>
        This application uses <b><i>RestTemplate exchange()</b></i> method to call movie service. <b><i>exchange()</b></i> returns ResponseEntity 
        as the response type. ResponseEntity is extension of HttpEntity that adds a HttpStatus status code.
        </p>
    
        Launch <a href="http://localhost:8081/exchange/movies" target="_blank">http://localhost:8081/exchange/movies</a> in browser and you will 
        see the list of movies.<br>
        Launch <a href="http://localhost:8081/exchange/movie/1" target="_blank">http://localhost:8081/exchange/movie/1</a> in browser and you will 
        see movie details.<br><br>

        Also you can pass multiple query parameters in <b><i>RestTemplate exchange()</b></i> method as shown in below url<br>
        Launch <a href="http://localhost:8081/exchange/movie?id=0&genre=Fantasy" target="_blank">http://localhost:8080/exchange/movie?id=0&genre=Fantasy</a>
        in browser and you will see movie details.
    </div>

          <div id="code">
        <pre class="prettyprint">
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

    @RestController
    @RequestMapping("/exchange/")
    public class GetMovieClientApplication {

    @Autowired
    RestTemplate restTemplate;

    @RequestMapping("/movies")
    public ResponseEntity&lt;String> getMovieList() {  
        return restTemplate.exchange("http://localhost:8080/movies",
            HttpMethod.GET, null, String.class);
    }
        
    @RequestMapping("/movie/{id}")
    public ResponseEntity&lt;Movie> getMovie(@PathVariable int id) { 
        return restTemplate.exchange("http://localhost:8080/movie/"+id,
            HttpMethod.GET, null, Movie.class);
    }

    @RequestMapping("/movie")
    public String getMovie(@RequestParam int id, @RequestParam String genre) { 
			
        UriComponentsBuilder builder = UriComponentsBuilder
			.fromHttpUrl("http://localhost:8080/movie?id="+id)
	        .queryParam("id", id)
	        .queryParam("genre", genre);

        HttpHeaders headers = new HttpHeaders();
        headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
        HttpEntity&lt;?> entity = new HttpEntity&lt;>(headers);

        HttpEntity&lt;String> response = restTemplate.exchange(builder.toUriString(), 
		        HttpMethod.GET, entity, String.class);
        System.out.println(response.getBody());
        return response.getBody();
    }		
}  </div>
        </pre>
        <br>       

<h4>e) Create AddMovieClientApplication showing usage of RestTemplate postForObject()</h4>
    <div id="solution">
        <p>
        This application uses RestTemplate <b><i>postForObject()</b></i> method to call movie service.
        </p>
    </div>
Launch <a href="http://localhost:8081/postForObject/movie" target="_blank">http://localhost:8081/postForObject/movie</a> in browser and you will 
see that it has added a new movie in the backend.<br>

          <div id="code">
        <pre class="prettyprint">
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/postForObject")
public class AddMovieClientApplication {

    @Autowired
    RestTemplate restTemplate;

    @RequestMapping("/movie")
    public Movie addMovie() { 
        Movie movie = new Movie("The Matrix", "Sci Fi");
        return this.restTemplate.postForObject("http://localhost:8080/movie", movie, Movie.class);
    }
	
}  </div>
   </pre>
    <br>   
        
    References : <br><br>
    <a href="https://docs.spring.io/spring-framework/docs/current/javadoc-api/org/springframework/web/client/RestTemplate.html" target="_blank">
    Spring Boot RestTemplate</a>	<br><br>
        <a href="https://docs.spring.io/spring-framework/docs/current/javadoc-api/org/springframework/http/ResponseEntity.html" target="_blank">
    Spring Boot ResponseEntity</a>	<br><br>
    
      </div> <!-- blog div-->
        
       <?php include("../sidebar/sidebar.htm"); ?>
    
        </div> <!-- content div -->
        
         <div id="content">
            <?php include '../blogs/entry.php';?>
        </div>
        
         <?php include("share.htm"); ?>
    </body>

    <?php 
        include("footer.htm");
    ?>
    </html>