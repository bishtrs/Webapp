<?php include("../header.htm");?>

    <head>
        <title>Spring Boot Swagger example</title>
        <meta name="description" content="swagger in spring boot, swagger ui spring boot, spring boot swagger example" />
        <link rel="canonical" href="https://www.techblogss.com/springboot/spring-boot-swagger-example" />
    </head>

    <body>
        <?php include("../navigation.htm");?>
        
        <div id="content">
        <div id="problem">
            <h1>Spring Boot Swagger example</h1>
        </div>
        <div id="solution">
            <p>
            Using <b><i>Spring Boot Swagger</b></i> you can automate API documentation for the APIs exposed by your <code>Spring Boot</code>
            application. <code>Swagger</code> helps in creating a user interface using which user can understand API details, try out
            and develop against the API. This example show how to configure <code>Swagger UI</code> using <code>Spring Boot</code>.
            </p> 
        </div>
        
        <h4>Step 1) Add swagger 2 dependencies to pom.xml</h4>
        <div id="code">
        <pre class="prettyprint">
&lt;dependencies&gt;
    &lt;dependency&gt;
        &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
        &lt;artifactId&gt;spring-boot-starter-web&lt;/artifactId&gt;
    &lt;/dependency&gt;
        
    &lt;dependency&gt;
         &lt;groupId&gt;io.springfox&lt;/groupId&gt;
         &lt;artifactId&gt;springfox-swagger-ui&lt;/artifactId&gt;
         &lt;version&gt;2.9.2&lt;/version&gt;
    &lt;/dependency&gt;
		
    &lt;dependency&gt;
        &lt;groupId&gt;io.springfox&lt;/groupId&gt;
        &lt;artifactId&gt;springfox-swagger2&lt;/artifactId&gt;
        &lt;version&gt;2.9.2&lt;/version&gt;
    &lt;/dependency&gt;		
&lt;/dependencies&gt;</pre></div><br>
        
        <h4>Step 2) Create UserApplication class</h4>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserApplication {

    public static void main(String[] args) {
        SpringApplication.run(UserApplication.class, args);
    }
}       </div></pre><br>

   <h4>Step 3) Create UserController class.</h4>
    <p>UserController class defines the REST API endpoints. Code for <b><i>User & UserService</b></i> classes is not included here for sake of brevity. Please visit following page to see details of these classes:
   <a href="https://www.techblogss.com/springboot/spring-boot-rest-api#1" target="_blank">Spring Boot REST API example</a></p>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;
import java.util.Collection;
import java.util.Optional;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/users")
public class UserController {

    private final UserService userService;
    
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping()
    public Collection&lt;User&gt; getAllUsers() {
        return userService.getAll();
    }
    
    @GetMapping("/{id}")
    public Optional&lt;User&gt; get(@PathVariable("id") String id) {
        return userService.get(id);
    }
    
    @PostMapping()
    public User create(@RequestBody User user) {
        return userService.create(user);
    }
}        </div></pre><br>
		
		 <h4>Step 4) Create SwaggerConfiguration class to create API documentation for UserController class</h4>
         <p>
         We will use <b><i>Swagger 2</b></i> based configuration class. It will create a <b><i>Docket</b></i> bean to configure 
         <b><i>Swagger 2</b></i> for the application. It instructs spring where to scan for API controllers. 
         </p>
         
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import static springfox.documentation.builders.PathSelectors.regex;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class SwaggerConfiguration {

    @Bean
    public Docket postsApi() {
        return new Docket(DocumentationType.SWAGGER_2)
        .apiInfo(metadata())
        .select()
        .paths(regex("/users.*")).build();
    }

    private ApiInfo metadata() {
        return new ApiInfoBuilder()
        .title("Swagger example")
        .description("Description of UserController API")
        .termsOfServiceUrl("https://www.techblogss.com/")
        .version("2.0").build();	
    }
}        </div></pre><br>

       

     <h4>Step 5) Run UserApplication & view Swagger UI</h4>
     <div>
     Launch any browser and open <a href="http://localhost:8080/swagger-ui.html" target="_blank">http://localhost:8080/swagger-ui.html</a>. 
     You will see below page displayed in the broswer.
     </div>
        <div>
            <p><img src="../images/sb_swagger_1.jpg" alt="Maven Build" style="width:600px;height:500px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <div>
    Click on  <a href="http://localhost:8080/v2/api-docs" target="_blank">http://localhost:8080/v2/api-docs</a>. 
     You will see below page displayed in the broswer.
     </div>
        <div>
            <p><img src="../images/sb_swagger_2.jpg" alt="Maven Build" style="width:400px;height:600px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    
    References : <br><br>
    <a href="https://springfox.github.io/springfox/docs/current/" target="_blank">Springfox Reference Documentation</a>	<br><br>
        </div>
        
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
        
    <?php include("share.htm");?>
    </body>

    <?php include("footer.htm");?>
    </html>