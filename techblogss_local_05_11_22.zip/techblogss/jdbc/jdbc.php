<?php include "../header.htm" ;?>

<head>
    <title>Tech Blogss</title>
	<meta name="description" content="JDBC posts" />
    <link rel="canonical" href="https://www.techblogss.com/jdbc/jdbc">
    <!-- added for google search -->
    <script async src="https://cse.google.com/cse.js?cx=7d9bc37a65153d27d"></script>
</head>

<body>
    <?php include("../navigation.htm");?>
    
    <div id="posts">
        
        <div id="postLeft">
            <div id="postHeader"><h3><a href="../jdbc/jdbc-mysql-connect" target="_blank">How to connect to MySQL using JDBC</a></h3></div>
            <div id="postText"><p>If you want to connect to MySQL database in Java, you need MySQL JDBC ...</p></div>
            <div id="postFooter"><p>Uses mysql-connector 8.0.28</p></div>
        </div>
        
        <div id="postRight">
            <div id="postHeader"><h3><a href="../jdbc/jdbc-create-table" target="_blank">How to create table in MySQL database</a></h3></div>
            <div id="postText"><p>In this example we will show how to create a table in MYSQL DB using Java ...</p></div>
            <div id="postFooter"><p>Uses mysql-connector 8.0.28</p></div>
        </div>
        
        <div id="postLeft">
            <div id="postHeader"><h3><a href="../jdbc/jdbc-insert-prepared-statement" target="_blank">Insert Row using JDBC</a></h3></div>
            <div id="postText"><p>PreparedStatement extends Statement interface and provides ...</p></div>
            <div id="postFooter"><p>Uses mysql-connector 8.0.28</p></div>
        </div>
        
        <div id="postRight">
            <div id="postHeader"><h3><a href="../jdbc/jdbc-update-prepared-statement" target="_blank">Update Row using JDBC</a></h3></div>
            <div id="postText"><p>In this example we will show how to update a row in a MYSQL ...</p></div>
            <div id="postFooter"><p>Uses mysql-connector 8.0.28</p></div>
        </div>
        <!-- How to get Connection object from DataSource in Java -->
        <!-- jOOQ example -->
        <?php include("../sidebar/ad.htm"); ?>
        
    </div>
	
	
    <?php include("../sidebar/sidebarHomePage.htm"); ?>
	
</body>

<?php include("footer.htm");?>

</html>
