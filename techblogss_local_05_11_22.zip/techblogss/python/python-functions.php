<?php 
    include("header.htm");
?>

<head>
    <title>Python Functions</title>
	<meta name="description" content="Python Functions" />
	<link rel="canonical" href="https://www.techblogss.com/python/python-functions" />
	<style>
		table, td, th {
		  border: 1px solid black;
		}
		th, td {
		  padding: 10px;
		  text-align: center;
		}
	</style>
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>Python Functions</h1>
	</div>
	<div id="solution">
		<p>
		A <b><i>function</b></i> is a set of statments that performs a computation. A <b><i>function</b></i> It contains line of code that are 
		executed sequentially from top to bottom by Python interpreter.
		</p>
		
		<p><b><i>Functions</b></i> can be categorized into following:</p>
		
		<h2>1. Module</h2>
		<p>
		A module is a file containing Python definitions (i.e. functions) and statements. Definitions from the module can be used within 
		the code of a program. To use these modules in the program, a programmer needs to import the module. Once you import a module, you
		can reference any of its functions or variables in your code. You can import a module in following ways:
		</p>
		
		<h4>a) import</h4>
		<p>You can import a module using <b><i>import</b></i> keyword. For example you can import math module (which is stored as math.py in python
		library) as <pre>>>> import math</pre> Now to invoke a function, you need to use dot notation as shown below which will print output as 5.0</p>

<pre class="prettyprint">
>>> import math
>>> math.sqrt(25)
5.0
</pre> 
		
		<h4>b) From statment</h4>
		<p>
			<b><i>From</b></i> statment is used to get a specific function in the code instead of the complete module file. If we know beforehand
			which function(s), we need, then we can use <b><i>from</b></i> as shown below.
		</p>

<pre class="prettyprint">
>>> from math import sqrt
>>> math.sqrt(64)
8.0
</pre> 	

		<p>You can also use wildcard to import all the functions from a moddule using below statment <pre>>>> from modulename import *</pre></p>
		
		<p>You can view list of functions available in Python Math, String, DateTime libraries using below links </p>
		<a href="https://docs.python.org/3/library/math.html" target="_blank">https://docs.python.org/3/library/math.html</a><br>
		<a href="https://docs.python.org/3/library/string.html" target="_blank">https://docs.python.org/3/library/string.html</a><br>
		<a href="https://docs.python.org/3/library/datetime.html" target="_blank">https://docs.python.org/3/library/datetime.html</a>

        <br><br>
		<h2>2. Built in Functions</h2>
		<p>
			<b><i>Built in functions</b></i> are built into Python and can be accessed by a programmer without importing any module (file). 
			Below is the list of some <b><i>built in functions</b></i>. Complete list of <b><i>built in functions</b></i> can be viewed here
		</p>
		<a href=" https://docs.python.org/3/library/functions.html" target="_blank">https://docs.python.org/3/library/functions.html</a>
		<br><br>
		
		<table>
			<tr>
				<th style="width:20%;">Name</th>
				<th style="width:40%;">Description</th>
				<th style="width:40%;">Example</th>
		    </tr>
			<tr>
				<td>abs (x)</td>
				<td>Returns distance between x and zero</td>
				<td>>>>abs(-15)<br>15</td>
		    </tr>
			<tr>
				<td>max( x, y, z, .... )</td>
				<td>Returns the largest of its arguments</td>
				<td>>>>max(10, 100, 1000)<br>1000</td>
		    </tr>
			<tr>
				<td>len (s)</td>
				<td>Return the length (the number of items) of an object.</td>
				<td>>>> a= [1,2,3]<br>>>>len (a)<br>3</td>
		    </tr>
		</table>
		
		<br>
		
		<h2>Composition</h2>
		<p>
			<b><i>Composition</b></i> is a way of combining simple function(s) to build more complicated ones, i.e. result of one function is used as the
			input to another.<br>
			
			For example suppose we have two functions f1 & f2, such that a= f2 (x) b= f1 (a) then we can combine the two functions as 
			b= f1 (f2 (x))
		</p>
<pre class="prettyprint">>>> print(len('string'))
6
</pre>
        <br>
        
        <h2>3. User Defined Functions</h2>
		<p>
			You have seen functions come with Python either in some file (module) or in interpreter itself (built in), but it is also possible for programmer to write
            their own function(s). These functions can then be combined to form a module which can then be used in other programs by importing them.
		</p>
        <p>
            To define a function keyword def is used. After the keyword comes an identifier i.e. name of the function, followed by list of parameters in parenthesis.
            This first line is called <b><i>Function Header</b></i>.
            After that you write block of statement(s) (one or more lines of code) that are the part of function. This is called the <b><i>Function Body</b></i>.
        </p>
        <p>In Python, statements in a block are written with indentation. Usually, a block begins when a line is indented (by four spaces) and all the statements
        of the block should be at same indent level. A block within block begins when its first statement is indented by four space, i.e. in total eight spaces.
        Below is an example of user defined function.
		</p>
<pre class="prettyprint">>>> def printHello ():
        print ("Hello World")
</pre> 

        <p>Now invoke above function</p>
        
<pre class="prettyprint">>>> printHello()
Hello World
</pre>  
        
        <br>
        <h2>Parameters and Arguments</h2>
		<p>
			Parameters are the value(s) provided in the parenthesis when we write function header. These are the values required by function to work.
		</p> 
        <p>
            Arguments are the value(s) provided in when a function is called/invoked. List of arguments should be supplied in same order as parameters are listed.
        </p>
         <p>
            In the example below length and width are parameters for area function which calculates area of a rectangle.
        </p>
     
<pre class="prettyprint">>>> def area (length, width):
        area = length*width
        return area
</pre> 

        <p>Now invoke above function</p>
        
<pre class="prettyprint">>>> area(3,4)
12
</pre>  
        
        <br>
        <h2>Scope of Variables</h2>
		<p>
			Scope of a variable refers to the part of the program, where it is visible, i.e., area where you can refer (use) it.
            There are two types of variable scopes - global scope or local scope.
		</p>     
        <h4>1. Global Scope</h4>
        <p>
        A variable which has global scope can be used anywhere in the program. It can be created by defining a variable outside the scope of any function/block.
        </p>
<pre class="prettyprint">
>>> x=10
>>> def test ():
        print ('Inside test x is', x)
</pre>  

<pre class="prettyprint">>>> test()
Inside test x is 10
</pre> 

        <!--<p>
        If you modify a global variable, it will be changed permanently as shown below.
        </p>

<pre class="prettyprint">
>>> x=10
>>> def test ():
        global x
        x+=10
</pre>  -->

<pre class="prettyprint">>>> print ('Outside test x is', x)
Inside test x is 10
</pre> 
        
        <br>
        <h4>2. Local Scope</h4>
        <p>
        A variable with local scope can be accessed only within the function/block that it is created in. A local variable only exists while the function is executing.
        </p>
        
<pre class="prettyprint">
>>> def test ():
        x=10
        print ('Inside test x is', x)
</pre>  

<pre class="prettyprint">>>> test()
Inside test x is 10
</pre>  
        <p>
        If you try to access x outside function test, it will not be accessible and you will get error as shown below
        </p>

<pre class="prettyprint">
print ('Outside test x is', x)
NameError: name 'y' is not defined
</pre>  

        <br>
        <h2>Default Parameter Values</h2>
		<p>
			Functions can also have <b><i>default parameter values</b></i>. In case the user does not want to provide values (argument) for all of them at the time of
            calling, we can provide <b><i>default argument values</b></i>. In the example below b & c parameters have default values as 5 & 10. So in case values for b & c 
            parameters are not passed while calling the test() function, <b><i>default values</b></i> will be used.
		</p> 

<pre class="prettyprint">
>>> def test (a, b=5, c=10):
        print ('a = ', a, ', b = ', b, ', c = ', c)
</pre>  

<pre class="prettyprint">>>> test(1,2,3)
a =  1 , b =  2 , c =  3
>>> test(1)
a =  1 , b =  5 , c =  10
</pre>        
        
    </div>
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>

	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>
</html>