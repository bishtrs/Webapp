<?php include "../header.htm" ;?>

<head>
    <title>Tech Blogss</title>
	<meta name="description" content="JSON posts" />
    <link rel="canonical" href="https://www.techblogss.com/json/json">
    <!-- added for google search -->
    <script async src="https://cse.google.com/cse.js?cx=7d9bc37a65153d27d"></script>
</head>

<body>
    <?php include("../navigation.htm");?>
    
    <div id="posts">
        
        <div id="postLeft">
            <div id="postHeader"><h3><a href="../java/java_JSONToXML" target="_blank">Convert JSON to XML</a></h3></div>
            <div id="postText"><p>You can convert a JSON object to XML using JSON-Java library...</p></div>
            <div id="postFooter"><p>Uses JSON 20190722</p></div>
        </div>
        
        <div id="postRight">
            <div id="postHeader"><h3><a href="../java/java_parsejson" target="_blank">Parse JSON in Java</a></h3></div>
            <div id="postText"><p>JSON (JavaScript Object Notation) is a lightweight data-interchange format ...</p></div>
            <div id="postFooter"><p>Uses JSON simple 1.1.1</p></div>
        </div>
        
        <div id="postLeft">
            <div id="postHeader"><h3><a href="../java/java_parsejson_gson" target="_blank">Parse JSON using Gson</a></h3></div>
            <div id="postText"><p>For converting small- or medium-sized lists, Gson provides a better...</p></div>
            <div id="postFooter"><p>Uses Gson 2.8.5</p></div>
        </div>
        
        <div id="postRight">
            <div id="postHeader"><h3><a href="../java/java_json_gsonreadwrite" target="_blank">Gson JsonReader and JsonWriter</a></h3></div>
            <div id="postText"><p>Gson provides APIs to read and write JSON as ...</p></div>
            <div id="postFooter"><p>Uses Gson 2.8.5</p></div>
        </div>
        
        <div id="postLeft">
            <div id="postHeader"><h3><a href="../java/java-convert-json-to-object-jackson" target="_blank">JSON to Java Object using Jackson</a></h3></div>
            <div id="postText"><p>Jackson provides APIs which is a high-performance ...</p></div>
            <div id="postFooter"><p>Uses Jackson-core 2.9.8</p></div>
        </div>
        
        <div id="postRight">
            <div id="postHeader"><h3><a href="../java/java-json-schema-validation" target="_blank">JSON Schema validation in Java</a></h3></div>
            <div id="postText"><p>Sometimes it is required to validate JSON objects before ...</p></div>
            <div id="postFooter"><p>Uses Json schema 1.11.1</p></div>
        </div>
        
        <div id="postLeft">
            <div id="postHeader"><h3><a href="../java/java-jsonpath-example" target="_blank">JsonPath example</a></h3></div>
            <div id="postText"><p>Like XPath is used to extract data from a XML document  ...</p></div>
            <div id="postFooter"><p>Uses jsonpath 2.0.0</p></div>
        </div>
        
        <div id="postRight">
            <div id="postHeader"><h3><a href="../java/java-write-json-to-file-gson" target="_blank">Write JSON to file Java using Gson</a></h3></div>
            <div id="postText"><p>In this example we will create a Java object and then write ...</p></div>
            <div id="postFooter"><p>Uses gson 2.9.0</p></div>
        </div>
        <!--<li><a href="java/java_parsejson">Jackson annotations ?</a></li>-->   
        
        <?php include("../sidebar/ad.htm"); ?>
    </div>
	
	
    <?php include("../sidebar/sidebarHomePage.htm"); ?>
	
</body>

<?php include("footer.htm");?>

</html>
