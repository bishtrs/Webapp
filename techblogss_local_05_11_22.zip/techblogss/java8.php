<?php header_remove("X-Powered-By"); ?>

<?php include("header.htm");?>


<head>
    <title>Tech Blogss</title>
	<meta name="description" content="Solutions to problems in Java 8" />
    <link rel="canonical" href="https://www.techblogss.com/java8">
    <!-- added for google search -->
    <script async src="https://cse.google.com/cse.js?cx=7d9bc37a65153d27d"></script>
</head>

<body>
   	<?php include("navigation.htm");?>
    
	<div id="posts">
        <div id="postLeft">
            <div id="postHeader"><h3><a href="java/java_lambda" target="_blank">Lambda Expressions</a></h3></div>
            <div id="postText"><p>A Lambda expression (introduced in Java 8) is a concise way of writing an instance ...</p></div>
            <div id="postFooter"><p>Uses Java 1.8</p></div>
        </div>
        
        <div id="postRight">
            <div id="postHeader"><h3><a href="java/java_cj_foreach_continue" target="_blank">Java 8 forEach continue</a></h3></div>
            <div id="postText"><p>continue inside loop is not supported by forEach. As a workaround ...</p></div>
            <div id="postFooter"><p>Uses Java 1.8</p></div>
        </div>
        
        <div id="postLeft">
            <div id="postHeader"><h3><a href="java/java8-predicate" target="_blank">Predicate example</a></h3></div>
            <div id="postText"><p>Predicate in Java is a functional interface whose functional method ...</p></div>
            <div id="postFooter"><p>Uses Java 1.8</p></div>
        </div>
        
        <div id="postRight">
            <div id="postHeader"><h3><a href="java/java_j8_stringjoiner" target="_blank">Java 8 StringJoiner example</a></h3></div>
            <div id="postText"><p>StringJoiner is used to create a sequence of characters that are separated by a ...</p></div>
            <div id="postFooter"><p>Uses Java 1.8</p></div>
            
        </div><div id="postLeft">
            <div id="postHeader"><h3><a href="java/java8-xmx-xms" target="_blank">Java Heap sizing</a></h3></div>
            <div id="postText"><p>If the heap is too small, the application will spend too much ...</p></div>
            <div id="postFooter"><p>Uses Java 1.8</p></div>
        </div>
        
        <div id="postRight">
            <div id="postHeader"><h3><a href="java/java8-garbage-collection-algorithms" target="_blank">Garbage Collection Algorithms</a></h3></div>
            <div id="postText"><p>Java provides Garbage Collection feature to remove the objects ...</p></div>
            <div id="postFooter"><p>Uses Java 1.8</p></div>
        </div>
        
        <div id="postLeft">
            <div id="postHeader"><h3><a href="java/java8-completablefuture" target="_blank">CompletableFuture example</a></h3></div>
            <div id="postText"><p>CompletableFuture example showing how to use complete ...</p></div>
            <div id="postFooter"><p>Uses Java 1.8</p></div>
        </div>
        
        <div id="postRight">
            <div id="postHeader"><h3><a href="java/java8-spliterator" target="_blank">Spliterator example</a></h3></div>
            <div id="postText"><p>A Spliterator object is used to traverse a collection or stream and it can split ...</p></div>
            <div id="postFooter"><p>Uses Java 1.8</p></div>
        </div>
       
        <div id="postLeft">
            <div id="postHeader"><h3><a href="java/java8-stream-findanyfindfirst" target="_blank">Stream findAny(), findFirst()</a></h3></div>
            <div id="postText"><p>Java 8 Stream search examples using Stream findAny() ...</p></div>
            <div id="postFooter"><p>Uses Java 1.8</p></div>
        </div>
        
        <div id="postRight">
            <div id="postHeader"><h3><a href="java/java8-stream-allanynonematch" target="_blank">allMatch(), anyMatch(), noneMatch()</a></h3></div>
            <div id="postText"><p>Java Stream allMatch, anymatch, noneMatch examples ...</p></div>
            <div id="postFooter"><p>Uses Java 1.8</p></div>
        </div>
        
        <div id="postLeft">
            <div id="postHeader"><h3><a href="java/java_streamflatmap" target="_blank">flatMap() example</a></h3></div>
            <div id="postText"><p>Java 8 Stream flatmap example to convert two dimensional array of String  ...</p></div>
            <div id="postFooter"><p>Uses Java 1.8</p></div>
        </div>
        
        <div id="postRight">
            <div id="postHeader"><h3><a href="java/java8-stream-convert-list-to-map" target="_blank">Convert List to Map</a></h3></div>
            <div id="postText"><p>Below example shows how to convert a List to Map in Java 8 using ...</p></div>
            <div id="postFooter"><p>Uses Java 1.8</p></div>
        </div>
        
        <div id="postLeft">
            <div id="postHeader"><h3><a href="java/java8-stream-groupingby" target="_blank">Collectors groupingBy() example</a></h3></div>
            <div id="postText"><p>Example that shows how to group the objects by any attribute using ...</p></div>
            <div id="postFooter"><p>Uses Java 1.8</p></div>
        </div>
        
        <div id="postRight">
            <div id="postHeader"><h3><a href="java/java8-collectors" target="_blank">joining(), minBy(), maxBy() example</a></h3></div>
            <div id="postText"><p>Below example shows Java 8 Collectors examples ...</p></div>
            <div id="postFooter"><p>Uses Java 1.8</p></div>
        </div>
        
        <div id="postLeft">
            <div id="postHeader"><h3><a href="java/java8-stream-reduce" target="_blank">Stream reduce() example</a></h3></div>
            <div id="postText"><p>Below examples show Java 8 Stream reduce examples ...</p></div>
            <div id="postFooter"><p>Uses Java 1.8</p></div>
        </div>
        
        <div id="postRight">
            <div id="postHeader"><h3><a href="java/java8-stream-sorted" target="_blank">Sort List using Stream sorted()</a></h3></div>
            <div id="postText"><p>The Stream interface includes sorted() method that can be used to sort a stream ...</p></div>
            <div id="postFooter"><p>Uses Java 1.8</p></div>
        </div>
        
        <div id="postLeft">
            <div id="postHeader"><h3><a href="java/java8-sort-hashmap" target="_blank">Sort Map</a></h3></div>
            <div id="postText"><p>Below examples show how to sort HashMap by key or value Java 8 ...</p></div>
            <div id="postFooter"><p>Uses Java 1.8</p></div>
        </div>
        
        <div id="postRight">
            <div id="postHeader"><h3><a href="java/java8-optional" target="_blank">Optional example for null check</a></h3></div>
            <div id="postText"><p>An Optional is used to represent a object which may or may not contain ...</p></div>
            <div id="postFooter"><p>Uses Java 1.8</p></div>
        </div>

        <!--When to use parallel streams in Java 8-->
    </div> <!-- posts div -->
               
    
    <?php include("sidebar/sidebarHomePage.htm"); ?>

</body>


<?php include("footer.htm");?>
	
</html>
