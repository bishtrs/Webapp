<?php include("../header.htm");?>

<head>
    <title>Spring Boot circuit Breaker Resilience4j example</title>
    <meta name="description" content="Spring Boot Circuit Breaker Resilience4j example" />
    <link rel="canonical" href="https://www.techblogss.com/microservices/microservices-circuit-breaker" />
</head>

<body>
    <?php include("../navigation.htm");?>
        
    <div id="content">
    <div id="blog">
        <div id="problem">
            <h1>Spring Boot Circuit Breaker Resilience4j example</h1>
        </div>
        <div id="solution">
            <p>
			When we call a service A from another service B and service A doesn't provide any response for long time, then we can implement
            <code>Circuit Breaker</code> in service B as to prevent unnecessary calls and take appropriate action. 
			<code>Circuit Breaker</code> also provides a fallback mechanism to handle service call failure gracefully. We can also configure
            after how many failed calls, <code>Circuit Breaker</code> would be turned on or after home much time to wait for state to change 
            from open to half-open.
            </p>
            <p>
            <code>Resilience4j</code> library provide fault tolerance in microservice applications. It provides <code>Circuit Breaker</code>,
            <code>Retry</code>, <code>Bulkhead</code>, <code>Rate Limit</code>, <code>Fallback</code> capabilities for fault tolerance.
            Below example shows how to implement <code>Circuit Breaker</code> and <code>Fallback</code> in a Spring Boot application
            using <code>Resilience4j</code>.
			</p>    
           
        </div>
        
        <h3>1) Create CourseServiceApplication</h3>
        <p>First let us create a Spring Boot based CourseService application which provided list of courses available.</p>
        
        <h4>Step 1) Create pom.xml file and add spring-boot-starter-web dependency</h4>
        
        <div id="code">
        <pre class="prettyprint">
&lt;dependency>
    &lt;groupId>org.springframework.boot&lt;/groupId>
    &lt;artifactId>spring-boot-starter-web&lt;/artifactId>
&lt;/dependency>        </pre>        </div> <br>

    <h4>Step 2) Create Course, CourseRestController, CourseServiceApplication classes to create Course microservice </h4>
    <div id="code">
    <pre class="prettyprint">public class Course {
    private int id;
    private String description;
    // removed getters and setters
}  </div> </pre>	

<div id="code">
    <pre class="prettyprint">
package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(CourseServiceApplication.class, args);
    }

}  </div></pre>	

<div id="code">
    <pre class="prettyprint">
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CourseRestController {

	private static final Logger LOG = LoggerFactory.getLogger(CourseRestController.class);

	List&lt;Course> courses = new ArrayList&lt;>();

	public CourseRestController() {
		courses.add(new Course(1, "Computer Science"));
		courses.add(new Course(2, "Mathematics"));
		courses.add(new Course(3, "Physics"));
	}

	@RequestMapping(value = "/courses") // http://localhost:8090/courses
	public List&lt;Course> listAll() {
		LOG.info("returning list of courses");
		return courses;
	}

}  </div>    </pre>      <br>
    
    <h4>Step 3) Create application.yml file under src/main/resources</h4>
    <div id="code">
    <pre class="prettyprint">
spring:
  application:
    name: course-service

server:
  port: 8090   </div> </pre><br>	
    
    <h4>Step 4) Launch CourseApplication</h4>
    
    <div id="solution">
        Launch <a href="http://localhost:8090/courses" target="_blank">http://localhost:8090/courses</a> in the browser.
        You will see below page with list of courses in the broswer.
    </div><br>
    
    <div>
        <img src="../images/microservices/circuitbreaker_2.jpg" alt="CircuitBreaker" style="width:380px;height:300px;">
    </div>
        
    <br><br><br><br><br><br><br><br><br><br><br><br>
    
    <h3>2) Create CourseClient Application</h3>
    <p>
    Now create CourseClient Application enabled with Resilience4j Circuit Breaker. It means when CourseClient calls CourseService, and it
    is down, we will still get a response that can be gracefully handled.
    </p>
    
    <h4>Step 1) Create pom.xml file with below dependencies</h4>
        <div id="code">
        <pre class="prettyprint">
&lt;parent>
    &lt;groupId>org.springframework.boot&lt;/groupId>
    &lt;artifactId>spring-boot-starter-parent&lt;/artifactId>
    &lt;version>2.6.3&lt;/version>
    &lt;relativePath /> &lt;!-- lookup parent from repository -->
&lt;/parent>

&lt;dependencies>
    &lt;dependency>
        &lt;groupId>org.springframework.boot&lt;/groupId>
        &lt;artifactId>spring-boot-starter-web&lt;/artifactId>
    &lt;/dependency>
    &lt;dependency>
        &lt;groupId>org.springframework.cloud&lt;/groupId>
        &lt;artifactId>spring-cloud-starter-circuitbreaker-reactor-resilience4j&lt;/artifactId>
    &lt;/dependency>
    &lt;dependency>
        &lt;groupId>org.springframework.boot&lt;/groupId>
        &lt;artifactId>spring-boot-starter-webflux&lt;/artifactId>
    &lt;/dependency>
&lt;/dependencies>
	
&lt;dependencyManagement>
    &lt;dependencies>
        &lt;dependency>
            &lt;groupId>org.springframework.cloud&lt;/groupId>
            &lt;artifactId>spring-cloud-dependencies&lt;/artifactId>
            &lt;version>2021.0.1&lt;/version>
            &lt;type>pom&lt;/type>
            &lt;scope>import&lt;/scope>
        &lt;/dependency>
    &lt;/dependencies>
&lt;/dependencyManagement>       </pre>	  </div>     <br>
        
         <h4>Step 2) Create CircuitBreakerCourseApplication, CourseController, CourseClientResilience4J classes</h4>
    <div id="code">
    <pre class="prettyprint">
import java.time.Duration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cloud.circuitbreaker.resilience4j.ReactiveResilience4JCircuitBreakerFactory;
import org.springframework.cloud.circuitbreaker.resilience4j.Resilience4JCircuitBreakerFactory;
import org.springframework.cloud.circuitbreaker.resilience4j.Resilience4JConfigBuilder;
import org.springframework.cloud.client.circuitbreaker.Customizer;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig;
import io.github.resilience4j.timelimiter.TimeLimiterConfig;

@SpringBootApplication
public class CircuitBreakerCourseApplication {

	@Bean
	public RestTemplate rest(RestTemplateBuilder builder) {
		return builder.build();
	}

	// Default Configuration for Resilience4JCircuitBreakerFactory
	@Bean
	public Customizer&lt;Resilience4JCircuitBreakerFactory> defaultCustomizer() {
		return factory -> factory.configureDefault(id -> new Resilience4JConfigBuilder(id)
                .timeLimiterConfig(TimeLimiterConfig.custom().timeoutDuration(Duration.ofSeconds(4)).build())
                .circuitBreakerConfig(CircuitBreakerConfig.ofDefaults()).build());
	}
    
    // Default Configuration for ReactiveResilience4JCircuitBreakerFactory
	@Bean
	public Customizer&lt;ReactiveResilience4JCircuitBreakerFactory> defaultReactiveCustomizer() {
	    return factory -> factory.configureDefault(id -> new Resilience4JConfigBuilder(id)
	            .circuitBreakerConfig(CircuitBreakerConfig.ofDefaults())
	            .timeLimiterConfig(TimeLimiterConfig.custom().timeoutDuration(Duration.ofSeconds(4)).build()).build());
	}
	
	public static void main(String[] args) {
		SpringApplication.run(CircuitBreakerCourseApplication.class, args);
	}

} </pre> </div>
       
        
<div id="code">
    <pre class="prettyprint">
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CourseController {
	
	@Autowired
	private CourseClientResilience4J courseClient;
	
	@RequestMapping("/allCourses") // http://localhost:8080/allCourses
	public String getCourseList() {
		return courseClient.courseList();
	}

} </pre> </div> <br>

<div id="code">
    <pre class="prettyprint">
import java.net.URI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.circuitbreaker.resilience4j.Resilience4JCircuitBreaker;
import org.springframework.cloud.circuitbreaker.resilience4j.Resilience4JCircuitBreakerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class CourseClientResilience4J {

	private static final Logger LOG = LoggerFactory.getLogger(CourseClientResilience4J.class);
	private final RestTemplate restTemplate;
	private final Resilience4JCircuitBreaker circuitBreaker;

	public CourseClientResilience4J(Resilience4JCircuitBreakerFactory circuitBreakerFactory,
			RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
		this.circuitBreaker = circuitBreakerFactory.create("courses");
	}

	public String courseList() {
		URI uri = URI.create("http://localhost:8090/courses");
		return circuitBreaker.run(() -> this.restTemplate.getForObject(uri, String.class),
            throwable -> {
			    LOG.error("error while calling course service", throwable);
			    return "{id:1, description: Computer Science}";
		});
	}

}</pre> </div> <br>
   
    <div id="solution">
        <h4>Step 3) Run CircuitBreakerCourseApplication</h4>
        <div>
        Launch <a href="http://localhost:8080/allCourses" target="_blank">http://localhost:8080/allCourses</a> in the browser.
        You will see below page with list of courses in the broswer.
        </div>
    </div><br>
    
        <div>
            <p><img src="../images/microservices/circuitbreaker_3.jpg" alt="CircuitBreaker" style="width:400px;height:300px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br><br>
    
    <div id="solution">
        <h4>Step 4) Shutdown CourseServiceApplication</h4>
        <div>
        Shutdown CourseServiceApplication and refresh <a href="http://localhost:8080/allCourses" target="_blank">http://localhost:8080/allCourses</a> in the browser.
        </div>
        
        <p>
        Now circuit breaker will come into picture and will not send rqeuests to CourseServiceApplication. Instead it will return the data
        provided by the fallback mechanism.
        </p>
    </div>
        <br>
        <div>
            <p><img src="../images/microservices/circuitbreaker.jpg" alt="Maven Build" style="width:300px;height:100px;"></p>
        </div>
        <br><br><br><br><br><br><br>
        
    <h3>3) Using ReactiveCircuitBreaker</h3>
    <div id="solution">    
    <p>
    In this example we have used <code>Resilience4JCircuitBreaker</code>, but you can also use <code>ReactiveCircuitBreaker</code> in 
    case we are using reactive data like <code>Mono</code>, <code>Flux</code>. Write CourseClientReactiveResilience4J class and then use it in
    CourseController class.
    </p>
    </div>
    
    <div id="code">
    <pre class="prettyprint">
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.circuitbreaker.resilience4j.ReactiveResilience4JCircuitBreakerFactory;
import org.springframework.cloud.client.circuitbreaker.ReactiveCircuitBreaker;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

import reactor.core.publisher.Mono;

@Service
public class CourseClientReactiveResilience4J {

	private static final Logger LOG = 
            LoggerFactory.getLogger(CourseClientReactiveResilience4J.class);
	private final WebClient webClient;
	private final ReactiveCircuitBreaker reactiveCircuitBreaker;

	public CourseClientReactiveResilience4J(
            ReactiveResilience4JCircuitBreakerFactory circuitBreakerFactory, 
            RestTemplate restTemplate) {
        this.webClient = WebClient.builder().baseUrl("http://localhost:8090").build();
        this.reactiveCircuitBreaker = circuitBreakerFactory.create("courses");
    }

	public Mono&lt;String> courseList() {
		return reactiveCircuitBreaker.run(webClient.get().
                uri("/courses").retrieve().bodyToMono(String.class),
                throwable -> {
                    LOG.error("error while calling course service", throwable);
                    return Mono.just("{id:1, description: Computer Science}");
                });
	}
}
</pre> </div> <br>

<div id="code">
    <pre class="prettyprint">
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import reactor.core.publisher.Mono;

@RestController
public class CourseController {
	
	@Autowired
	private CourseClientReactiveResilience4J reactiveCourseClient;
	
	@RequestMapping("/allCoursesReactive") // http://localhost:8080/allCoursesReactive
	public Mono&lt;String> getCourseListReactive() {
		return reactiveCourseClient.courseList();
	}
}</pre> </div> <br>
        
        <br><br><br><br><br>
    References : <br><br>
    <a href="https://docs.spring.io/spring-cloud-circuitbreaker/docs/current/reference/html/">Spring Cloud Circuit Breaker</a>	<br><br>
        
        </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
        
    <div id="content">
    <?php include '../blogs/entry.php';?>
    </div>
        
    <?php include("share.htm"); ?>
    </body>

    <?php 
        include("../footer.htm");
    ?>
    </html>