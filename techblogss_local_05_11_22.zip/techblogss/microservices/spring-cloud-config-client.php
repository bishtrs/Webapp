<?php include("../header.htm");?>

<head>
    <title>Spring Boot Config Client example</title>
    <meta name="description" content="Spring Boot Config Client example" />
    <link rel="canonical" href="https://www.techblogss.com/microservices/spring-cloud-config-client" />
</head>

<body>
    <?php include("../navigation.htm");?>
        
    <div id="content">
        <div id="blog">
        <div id="problem">
            <h1>Spring Boot Config Client Example</h1>
        </div>
        <div id="solution">
            <p>This tutorial shows how to create a <b><i>Spring Boot</b></i> <b><i>Config Client</b></i> that will its read application configuration
            from a <b><i>Spring Boot</b></i> <b><i>Config Server</b></i> that externally keeps the application configuration wtih local & dev
            profiles.</p> 
           <p>To configure a <b><i>Config Server</b></i> locally, view this page</p> 
           <a href="https://www.techblogss.com/microservices/spring-cloud-config-server" target="_blank">
           https://www.techblogss.com/microservices/spring-cloud-config-server</a>
        </div>
        
        <h4>Step 1) Create pom.xml for config client project</h4>

        <div id="code">
        <pre class="prettyprint">
&lt;dependencyManagement&gt;
    &lt;dependencies&gt;
        &lt;dependency&gt;
            &lt;groupId&gt;org.springframework.cloud&lt;/groupId&gt;
            &lt;artifactId&gt;spring-cloud-dependencies&lt;/artifactId&gt;
            &lt;version&gt;2.1.6.RELEASE&lt;/version&gt;
        &lt;/dependency&gt;
    &lt;/dependencies&gt;
&lt;/dependencyManagement&gt;
 
&lt;dependencies&gt;
    &lt;dependency&gt;
        &lt;groupId&gt;org.springframework.cloud&lt;/groupId&gt;
        &lt;artifactId&gt;spring-cloud-starter-config&lt;/artifactId&gt;
        &lt;version&gt;2.1.6.RELEASE&lt;/version&gt;
    &lt;/dependency&gt;
    &lt;dependency&gt;
        &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
        &lt;artifactId&gt;spring-boot-starter-web&lt;/artifactId&gt;
    &lt;/dependency&gt;
    &lt;dependency&gt;
        &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
        &lt;artifactId&gt;spring-boot-starter-actuator&lt;/artifactId&gt;
    &lt;/dependency&gt;
    &lt;dependency&gt;
        &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
        &lt;artifactId&gt;spring-boot-starter-test&lt;/artifactId&gt;
        &lt;scope&gt;test&lt;/scope&gt;
    &lt;/dependency&gt;
&lt;/dependencies&gt;
    
&lt;repositories&gt;
    &lt;repository&gt;
        &lt;id&gt;central-repo&lt;/id&gt;
        &lt;name&gt;Central Repository&lt;/name&gt;
        &lt;url&gt;https://repo1.maven.org/maven2&lt;/url&gt;
    &lt;/repository&gt;
&lt;/repositories&gt; </pre></div><br>

         <h4>Step 2) Create ConfigClient class that will launch config client, AppConfiguration class that holds configuration & 
         MessageRestController</h4>
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.cloud.context.config.annotation.RefreshScope;

@SpringBootApplication
public class ConfigClient {
    public static void main(String[] args) {
        SpringApplication.run(ConfigClient.class, args);
    }
}        </pre>
        </div>
        <br>
        
        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;

@RefreshScope
public class AppConfiguration {

    @Value("${message:Hello default}")
    private String message;

    String getMessage() {
        return this.message;
    }

}        </pre>
        </div>
        <br>

        <div id="code">
        <pre class="prettyprint">
package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MessageRestController {
	
    @Autowired
    private AppConfiguration configuration; 
	
    @RequestMapping("/message")
    String getMessage() {
        return configuration.getMessage();
    }

}        </pre>
        </div>
        <br>
        
  
    <h4>Step 3) Create application.properties, bootstrap.yml, bootstrap-local.yml, bootstrap-dev.yml files and keep in src/main/resources folder</h4>
 
 <p><b><i>application.properties</b></i></p>
        <div id="code">
        <pre class="prettyprint">
management.endpoints.web.exposure.include=*</div>
        </pre> 

<p><b><i>bootstrap.yml (to load the configuration from config server.)</b></i></p>
        <div id="code">
        <pre class="prettyprint">
spring:
  application:
    name: config-server</div>
        </pre> 
 
<p><b><i>bootstrap-local.yml</b></i></p>
        <div id="code">
        <pre class="prettyprint">
spring:
  cloud:
    config:
     uri: http://localhost:8888
          
logging:
  file: C:/Users/bisht/configuration-server.log
  level:
    ROOT: 'INFO'          </div>
        </pre> 
 
<p><b><i>bootstrap-dev.yml</b></i></p>
        <div id="code">
        <pre class="prettyprint">
spring:
  cloud:
    config:
     uri: http://localhost:8888
          
logging:
  file: C:/Users/bisht/configuration-server.log
  level:
    ROOT: 'INFO'    </div>
        </pre> 
  
        <br>

        <h4>Step 4) Launch ConfigClient application using dev/local profile</h4>
        <p> To Run this Spring Boot application using dev profile, use following command &rarr; <br> <b>java -Dspring.profiles.active=dev -jar demo-0.0.1-SNAPSHOT.jar</b></p>
        <p> To Run this Spring Boot application using local profile, use following command &rarr; <br> <b>java -Dspring.profiles.active=local -jar demo-0.0.1-SNAPSHOT.jar</b></p>


    <h4>Step 5) Validating Config Client</h4>
    <p>Open any browser and launch <a href="// http://localhost:8080/message" target="_blank">http://localhost:8080/message</a>. You will see below details displayed for dev & local profiles in the broswer.</p><br>
     
        <div>
            <p><img src="../images/microservices/configclient.png" alt="Maven Build" style="width:500px;height:200px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br>
        
        <div>
            <p><img src="../images/microservices/configclient_2.png" alt="Maven Build" style="width:500px;height:200px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br>
        
    <h4>Step 6) Updating and refreshing configuration.</h4>
    <p>Now update application-local.properties in config server and run below command to refresh the properties in client config. Observe
    the property that was updated without restarting config-server or config-client application.</p>

<div id="code">
        <pre class="prettyprint">
C:\Users\bisht>curl -X POST http://localhost:8080/actuator/refresh -d {} -H "Content-Type: application/json"
["config.client.version","message"]  </div>
        </pre>  
    <br>     

    <div>
            <p><img src="../images/microservices/configclient_3.png" alt="Maven Build" style="width:500px;height:200px;"></p>
    </div>
        
        <br><br><br><br><br><br><br><br><br><br>    
    
    References : <br><br>
    <a href="https://cloud.spring.io/spring-cloud-config/reference/html/" target="_blank">Spring Cloud Config</a> <br><br>
      </div> <!-- blog div-->
        
       <?php include("../sidebar/sidebar.htm"); ?>
    
        </div> <!-- content div -->
        
        <div id="content">
            <?php include '../blogs/entry.php';?>
        </div>
        
         <?php include("share.htm"); ?>
    </body>

    <?php include("../footer.htm");?>
    </html>