<?php include("../header.htm"); ?>

    <head>
        <title>Spring Cloud Sleuth Zipkin example</title>
        <meta name="description" content="Spring Cloud Sleuth Zipkin example" />
        <link rel="canonical" href="https://www.techblogss.com/microservices/spring-cloud-sleuth-zipkin" />
    </head>

    <body>
        <?php include("../navigation.htm"); ?>
        
        <div id="content">
        <div id="blog">
        <div id="problem">
            <h1>Spring Cloud Sleuth Zipkin example</h1>
        </div>
        <div id="solution">
            <p>
            When using microservices architecture, a single transaction may span multiple microservices. If you want to debug any transaction
            or you want to investigate an issue, you need a unique id to identify the flow of transaction. 
            <code>Spring Cloud Sleuth</code> provides the solution by mplementing distributed tracing solution for Spring Cloud.
            </p>
            <p>
            <code>Spring Cloud Sleuth</code> uses <code>correlation IDs (traceid)</code> to trace logs. A <code>correlation ID</code> is a unique number or
            string (e.g. order id, user id) that's assigned to a transaction when a transaction is initiated. As the transaction flows across 
            multiple services, the <code>correlation ID</code> is propagated from one service call to another. With <code>Spring Cloud Sleuth</code>,
            you'll automatically get <code>correlation IDs</code> added to the log statements you put in your microservices.
            </p> 
            <p>
            We will also configure <code>Zipkin</code> in these microservices so that API calls statistics will be send to <code>Zipkin</code> server. 
            <code>Zipkin</code> is a distributed tracing platform that will allow us to trace transactions across multiple service invocations. 
            Using <code>Zipkin</code> we can graphically check the time consumed by each microservice API.
            </p>
        </div>
        
        <h4>Step 1) Add <code>spring-cloud-starter-sleuth</code> dependency to pom.xml</h4>
<div id="code">
        <pre class="prettyprint">
&lt;parent>
    &lt;groupId>org.springframework.boot&lt;/groupId>
    &lt;artifactId>spring-boot-starter-parent&lt;/artifactId>   
    &lt;version>2.1.6.RELEASE&lt;/version>
    &lt;relativePath />
&lt;/parent>

&lt;properties>
    &lt;java.version>1.8&lt;/java.version>
    &lt;spring-cloud.version>2.1.3.RELEASE&lt;/spring-cloud.version>
&lt;/properties>

&lt;dependencies>
    &lt;dependency>
        &lt;groupId>org.springframework.boot&lt;/groupId>
        &lt;artifactId>spring-boot-starter-web&lt;/artifactId>
    &lt;/dependency>

&lt;dependency>
    &lt;groupId>org.springframework.cloud&lt;/groupId>
        &lt;artifactId>spring-cloud-starter-sleuth&lt;/artifactId>
        &lt;version>${spring-cloud.version}&lt;/version>
    &lt;/dependency>

&lt;dependency>
	&lt;groupId>org.springframework.cloud&lt;/groupId>
	&lt;artifactId>spring-cloud-sleuth-zipkin&lt;/artifactId>
	&lt;version>${spring-cloud.version}&lt;/version>
&lt;/dependency>
        
&lt;/dependencies></pre></div><br>
    
    <h4>Step 2) Create first microservice</h4>
    <div id="solution">
    <p>
    Add SleuthApplication, SleuthRestController classes and application.yml file. SleuthRestController will expose an endpoint
    that will we will call from browser and it will internally call second microservice to get the results. By default <code>Zipkin</code> server 
    runs at port 9411. It it is running on some other port or host, we can configure the zipkin url using <code>spring.zipkin.baseUrl</code> 
    property in <code>application.yml</code> file.
    </p>
    <p>
    We will need to define how often each service should write data to <code>Zipkin</code>. By default only 10% data is sent to <code>Zipkin</code>.
    However for our testing purpose we can make it 100% by using <code>spring.sleuth.sampler.percentage</code> property which should be set between
    0 & 1. It is not recommended to set it to 1 as it will put hugh load on <code>Zipkin</code> server.
    </p>
    </div>
         
    <div id="code">
        <pre class="prettyprint">
package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class SleuthApplication {

    public static void main(String[] args) {
        SpringApplication.run(SleuthApplication.class, args);
    }
    
    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }

}       </div></pre><br>

       <div id="code">
        <pre class="prettyprint">
package com.example;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class SleuthRestController {

    private final Logger LOG = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private RestTemplate restTemplate;

    @RequestMapping(value = "/api")
    public String hello() {
        LOG.info("Hello Sleuth");

        return restTemplate.getForObject("http://localhost:8082/api2", String.class);
    }

}   </div></pre><br>

 <div id="code">
        <pre class="prettyprint">
spring:
  application:
    name: sleuth-demo
  zipkin:
    baseUrl: http://localhost:9411
  sleuth:
    sampler:
      probability: 1.0
     
server:
  port: 8081  </div></pre><br>
  
    <h4>Step 3) Create second microservice</h4>
    <p>
    Add SleuthApplication2, SleuthRestController classes and application.properties file. SleuthRestController will expose an endpoint
    that will be called by first microservice.
    </p>
         
    <div id="code">
    <pre class="prettyprint">
package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SleuthApplication2 {

    public static void main(String[] args) {
        SpringApplication.run(SleuthApplication2.class, args);
    }

}       </div></pre><br>

       <div id="code">
        <pre class="prettyprint">
package com.example;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SleuthRestController {
    
    private final Logger LOG = LoggerFactory.getLogger(this.getClass());

    
    @RequestMapping(value = "/api2") 
    public String hello() {
        LOG.info("Hello Sleuth you have invoked second microservice");
        return "Hello Sleuth you have invoked second microservice";
    }

}  </div></pre><br>

 <div id="code">
        <pre class="prettyprint">
spring:
  application:
    name: sleuth-demo-2
  zipkin:
    baseUrl: http://localhost:9411
  sleuth:
    sampler:
      probability: 1.0
     
server:
  port: 8082 </div></pre><br>  

<h4>Step 4) Configure Zipkin server</h4>
    <div>
    You can launch <code>Zipkin</code> server in 2 ways. One is by downloading executable jar from 
    <a href="https://search.maven.org/remote_content?g=io.zipkin&a=zipkin-server&v=LATEST&c=exec">latest release</a>
    and then start the server using <code>java -jar zipkin.jar</code> command.
    </div>
    <p>
    Other way is to configure using Spring Boot by adding below dependency and then starting application with <code>@EnableZipkinServer</code>.
    </p>
         
    <div id="code">
    <pre class="prettyprint">
&lt;properties&gt;
    &lt;project.build.sourceEncoding&gt;UTF-8&lt;/project.build.sourceEncoding&gt;
    &lt;project.reporting.outputEncoding&gt;UTF-8&lt;/project.reporting.outputEncoding&gt;
    &lt;java.version&gt;1.8&lt;/java.version&gt;
    &lt;spring-cloud.version&gt;Edgware.RELEASE&lt;/spring-cloud.version&gt;
&lt;/properties&gt;

&lt;dependencies&gt;
    &lt;dependency&gt;
        &lt;groupId&gt;io.zipkin.java&lt;/groupId&gt;
        &lt;artifactId&gt;zipkin-server&lt;/artifactId&gt;
    &lt;/dependency&gt;
    &lt;dependency&gt;
        &lt;groupId&gt;io.zipkin.java&lt;/groupId&gt;
        &lt;artifactId&gt;zipkin-autoconfigure-ui&lt;/artifactId&gt;
    &lt;/dependency&gt;
    &lt;dependency&gt;
         &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
         &lt;artifactId&gt;spring-boot-starter-test&lt;/artifactId&gt;
         &lt;scope&gt;test&lt;/scope&gt;
    &lt;/dependency&gt;
&lt;/dependencies&gt;     </div></pre><br>

       <div id="code">
        <pre class="prettyprint">
package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import zipkin.server.EnableZipkinServer;


@EnableZipkinServer
@SpringBootApplication
public class ZipkinServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZipkinServiceApplication.class, args);
	}
	
} </div></pre><br>

  
     <h4>Step 4) Running the microservices and Zipkin server</h4>
     <div>
     Run SleuthApplication, SleuthApplication2 and ZipkinServiceApplication, launch any browser and open <a href="http://localhost:8081/api" 
     target="_blank">http://localhost:8081/api</a>.  You will see below page displayed in the broswer.
     </div>
     <p><b>Hello Sleuth you have invoked second microservice</b></p>
         
    <div id="solution">
        <h4>Console Output : </h4>
    </div>
    
    <div id="solution">
    <p>
    Observe the logs in SleuthApplication, it prints <code>sleuth-demo,61a0a37a9c5988af,61a0a37a9c5988af,true</code>
    </p>
    </div>
    <p>
    <ul>
        <li><b><i>sleuth-demo</b></i> is the name of the service being logged.</li>
        <li><b><i>61a0a37a9c5988af</b></i> is the <b><i>Trace ID</b></i> which is a unique identifier for the user's request that will be carried 
        across all service calls in that request.</li>
        <li>Next <b><i>61a0a37a9c5988af</b></i> is the <b><i>Span ID</b></i> which is a unique identifier for a single segment in the overall user
        request. For multi-service calls, there will be one span ID for each service call in the user transaction.</li>
        <li><b><i>true</b></i> is the flag indicating whether the data will be sent to the Zipkin server for tracing.</li>
    </ul>
    </p>
    
    <div id="solution">
    <p>
    Observe the logs in SleuthApplication2, it prints <code>sleuth-demo-2,61a0a37a9c5988af,f7d587d622ac96cc,true</code>
    where <code>f7d587d622ac96cc</code> is the span id.
    </p>
    </div><br> 

    <h4>Step 5) Check microservices stats in Zipkin UI</h4>
    <div>
    As Zipkin server is running on 9411 port, launch <a href="http://localhost:9411" target="_blank">http://localhost:9411</a> url in browser
    to check time taken by each call in microservice in Zipkin UI. You need to click on 'Find a trace' to find the transaction flows across the
    microservices.
    </div> 

    <div id="largeimg">
        <p><img src="../images/microservices/zipkin_1.jpg" alt="Zipkin UI" style="width:800px;height:500px;"></p>
    </div>
    
    <div id="smallimg">
        <p><img src="../images/microservices/zipkin_1.jpg" alt="Zipkin UI" style="width:400px;height:250px;"></p>
    </div>
        
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br> 
    <p>If you click on '2 spans' you will see how much time is taken by each microservice. You can also search for a specific transaction
    by providing trace id like <code>61a0a37a9c5988af</code>
    </p>
    
    <div id="largeimg">
        <p><img src="../images/microservices/zipkin_2.jpg" alt="Zipkin UI" style="width:800px;height:500px;"></p>
    </div>
    
    <div id="smallimg">
        <p><img src="../images/microservices/zipkin_2.jpg" alt="Zipkin UI" style="width:400px;height:250px;"></p>
    </div>
        
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>     

    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>    
    
    <br>
    References : <br><br>
    <a href="https://spring.io/projects/spring-cloud-sleuth" target="_blank">Spring Cloud Sleuth</a>    <br><br>
    <a href="https://zipkin.io/pages/quickstart.html" target="_blank">OpenZipkin</a>    <br><br>
    
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
        
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
        
    <?php include("share.htm"); ?>
    </body>

    <?php include("../footer.htm"); ?>
    </html>