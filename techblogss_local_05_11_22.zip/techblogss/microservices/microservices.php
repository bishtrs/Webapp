<?php include "../header.htm" ;?>

<head>
    <title>Tech Blogss</title>
	<meta name="description" content="Microservices posts" />
    <link rel="canonical" href="https://www.techblogss.com/microservices/microservices">
    <!-- added for google search -->
    <script async src="https://cse.google.com/cse.js?cx=7d9bc37a65153d27d"></script>
</head>

<body>
    <?php include("../navigation.htm");?>
    
    <div id="posts">
        
        <div id="postLeft">
            <div id="postHeader"><h3><a href="../microservices/zuul-api-gateway" target="_blank">Zuul API Gateway</a></h3></div>
            <div id="postText"><p>A service API gateway acts as an intermediary between the service client and a service...</p></div>
            <div id="postFooter"><p>Uses Spring Boot 2.1, Spring Cloud Hoxton</p></div>
        </div>
        
        <div id="postRight">        
            <div id="postHeader"><h3><a href="../microservices/spring-cloud-sleuth-zipkin" target="_blank">Spring Cloud Sleuth Zipkin</a></h3></div>
            <div id="postText"><p>When using microservices architecture, a single transaction may span multiple...</p></div>    
            <div id="postFooter"><p>Uses Spring Boot 2.1.6, Spring Cloud 2.1.3</p></div>
        </div>
        
        <div id="postLeft">        
            <div id="postHeader"><h3><a href="../microservices/spring-cloud-config-server" target="_blank">Spring Cloud Config Server</a></h3></div>
            <div id="postText"><p>Spring Cloud Config</b></i> provides server as well as client side support...</p></div>    
            <div id="postFooter"><p>Uses Spring Boot 2.1.6, Spring Cloud 2.1.6</p></div>
        </div>
        
        <div id="postRight">        
            <div id="postHeader"><h3><a href="../microservices/spring-cloud-config-client" target="_blank">Spring Cloud Config Client</a></h3></div>
            <div id="postText"><p>This tutorial shows how to create a Spring Boot Config Client that will...</p></div>    
            <div id="postFooter"><p>Uses Spring Boot 2.1.6, Spring Cloud 2.1.6</p></div>
        </div>
        
        <div id="postLeft">
            <div id="postHeader"><h3><a href="../microservices/service-discovery-replication" target="_blank">Service Discovery Replication</a></h3></div>
            <div id="postText"><p><p>When you run Service Discovery in production, you need at least two instances of discovery...</p></div>
            <div id="postFooter"><p>Uses Spring Boot 2.2.1, Spring Cloud Hoxton</p></div>
        </div>
        
         <div id="postRight">        
            <div id="postHeader"><h3><a href="../microservices/microservices-circuit-breaker" target="_blank">Circuit Breaker</a></h3></div>
            <div id="postText"><p>A Circuit Breaker is designed to avoid repeating timeouts...</p></div>    
            <div id="postFooter"><p>Uses Spring Boot 2.6.3, Spring Cloud 2021.0.1</p></div>
        </div>
        
        <div id="postLeft">
            <div id="postHeader"><h3><a href="../microservices/spring-cloud-loadbalancing-ribbon" target="_blank">Client side Load Balancing with Ribbon</a></h3></div>
            <div id="postText"><p>Spring Cloud Netflix Ribbon provides client-side load-balancing of service calls from a service ...</p></div>
            <div id="postFooter"><p>Uses Spring Boot 2.1.6, Spring Cloud Greenwich.SR3</p></div>
        </div>
        
        <div id="postRight">
            <div id="postHeader"><h3><a href="../microservices/eureka-service-discovery" target="_blank">Eureka service discovery</a></h3></div>
            <div id="postText"><p>When you are running multiple microservices, you need a mechanism ...</p></div>
            <div id="postFooter"><p>Uses Spring Boot 2.6.3, Spring Cloud 2021.0.3</p></div>
        </div>
        
        <div id="postLeft">
            <div id="postHeader"><h3><a href="../microservices/spring-cloug-gateway-tutorial" target="_blank">Spring Cloud Gateway tutorial</a></h3></div>
            <div id="postText"><p>When we implement API gateway pattern, <code>Spring Cloud Gateway</code> is one of the options ...</p></div>
            <div id="postFooter"><p>Uses Spring Boot 2.6.3, Spring Cloud 2021.0.3</p></div>
        </div>
        
        <ul id="problems">
            <!--<li><a href="../microservices/discovery-client" target="_blank">Spring Cloud DiscoveryClient</a></li>-->
            <!--<li><a href="../microservices/feign client" target="_blank">Spring cloud feign client</a></li>-->
            <!--ELK stack tutorial Spring Boot-->
            <!-- Spring Cloud loadbalancer example -->
		</ul>
        <?php include("../sidebar/ad.htm"); ?>
    </div>
	
	
    <?php include("../sidebar/sidebarHomePage.htm"); ?>
	
</body>

<?php include("../footer.htm");?>

</html>
