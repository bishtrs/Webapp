<?php include("../header.htm");?>

<head>
    <title>Eureka service discovery example</title>
    <meta name="description" content="Eureka service discovery example" />
    <link rel="canonical" href="https://www.techblogss.com/microservices/eureka-service-discovery" />
</head>

<body>
     <?php include("../navigation.htm");?>
        
     <div id="content">
     <div id="blog">
        <div id="problem">
            <h1>Eureka Service Discovery example</h1>
        </div>
        <div id="solution">
            <p>
                When you are running multiple microservices, you need a mechanism to locate a service. You can register each microservice
                in a service registry which is a seperate service. A service registry also helps in loadbalancing, and register or unregister a service when it is not available. A service or client application which wants to use another service can lookup the service in the service registry and then call it.
            </p> 
            
            <p>
                Below Eureka Service Discovery example shows how to register and lookup a microservice using <b><i>Netflix Eureka service 
                registry</b></i>. We will create a <b><i>Eureka Service Registry server</b></i> and register two microservices named 
                <b><i>ToyService</b></i> and <b><i>ToyClientService</b></i> respectively. <b><i>ToyClientService</b></i> microservice will lookup <b><i>ToyService</b></i> microservice in the <b><i>Eureka Service Registry</b></i> and invoke its exposed endpoint.
            </p>    
        </div>
        
        <div>
            <img src="../images/microservices/eureka_2.jpg" alt="Eureka Service Discovery" style="width:600px;height:400px;">
        
            <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        </div>
        
        <h4>Step 1) Add below dependencies in pom.xml</h4>
        
        <div id="code">
        <pre class="prettyprint">
&lt;parent>
    &lt;groupId>org.springframework.boot&lt;/groupId>
	&lt;artifactId>spring-boot-starter-parent&lt;/artifactId>
	&lt;version>2.6.3&lt;/version>
	&lt;relativePath/> 
&lt;/parent>
    
&lt;dependencies&gt;
    &lt;dependency&gt;
        &lt;groupId&gt;org.springframework.cloud&lt;/groupId&gt;
        &lt;artifactId&gt;spring-cloud-starter-netflix-eureka-server&lt;/artifactId&gt;
    &lt;/dependency&gt;
&lt;/dependencies&gt;

&lt;dependencyManagement&gt;
    &lt;dependencies&gt;
        &lt;dependency&gt;
            &lt;groupId&gt;org.springframework.cloud&lt;/groupId&gt;
            &lt;artifactId&gt;spring-cloud-dependencies&lt;/artifactId&gt;
            &lt;version&gt;2021.0.3&lt;/version&gt;
            &lt;type&gt;pom&lt;/type&gt;
            &lt;scope&gt;import&lt;/scope&gt;
        &lt;/dependency&gt;
    &lt;/dependencies&gt;
&lt;/dependencyManagement&gt;</pre></div><br>

    <div id="1">
    <h4>Step 2) Create EurekaServiceApplication class to launch Eureka Service registry</h4>
    <p>
    You need to add <code>@EnableEurekaServer</code> annotation to make sure that the application will run as Eureka server.
    </p>
    
    <div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@EnableEurekaServer
@SpringBootApplication
public class EurekaServiceApplication {

  public static void main(String[] args) {
    SpringApplication.run(EurekaServiceApplication.class, args);
  }
}  </pre></div><br>
    
    <h4>Step 3) Create application.yml file under src/main/resources</h4>
    <p>
    Since the application will run as service registry, we will not register it with service registry by setting <code>register-with-eureka: false</code>.
    </p>
    
    <div id="code">
    <pre class="prettyprint">
server:
  port: 8761
  
spring:  
  application:
    name: discovery-service

eureka:
  client:
    register-with-eureka: false
    fetch-registry: false</pre></div>    

    </div><br>
    
    <h4>Step 4) Launch EurekaServiceApplication and open <a href="http://localhost:8761" target="_blank">http://localhost:8761/</a>
    in the browser.</h4>
    <div>
    You will see below page displayed in the broswer.
    
        <div>
            <p><img src="../images/microservices/eureka_1.jpg" alt="Maven Build" style="width:800px;height:500px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    </div><br>    
    
    <h4>Step 5)  Create ToyService application</h4>
    <p>
    Create pom.xml file similar to one create for EurekaServiceApplication but replace 'spring-cloud-starter-netflix-eureka-server' with 'spring-cloud-starter-netflix-eureka-client' as mentioned below.
    </p>
        <div id="code">
        <pre class="prettyprint">
&lt;dependency>
    &lt;groupId>org.springframework.cloud&lt;/groupId>
    &lt;artifactId>spring-cloud-starter-netflix-eureka-client&lt;/artifactId>
&lt;/dependency>
</div></pre><br>
        
         <h4>Step 6) Create Toy, ToyServiceApplication & ToyRestController classes</h4>
    <div id="code">
    <pre class="prettyprint">
package com.example.demo;

    public class Toy {
        
        private String name;
        private String type;
        private double price;
        
        public Toy(String name, String type, float price) {
            this.name = name;
            this.type = type;
            this.price = price;
        }
    
    //removed getter setter for brevity
   
}   </div></pre>
        
<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ToyServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(ToyServiceApplication.class, args);
    }
}   </div> </pre>

<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ToyRestController {

    private static final Logger LOG = LoggerFactory.getLogger(ToyRestController.class);

    private List&lt;Toy> toys = new ArrayList&lt;>();

    public ToyRestController() {
        toys.add(new Toy("Barbie", "Doll", 45.0));
        toys.add(new Toy("My Little Pony", "Animal", 10.4));
        toys.add(new Toy("Hot Wheels", "Car", 5.4));
    }

    @RequestMapping(value = "/toys") // http://localhost:8090/toys
    public List&lt;Toy> listAll() {
        LOG.info("returning list of toys");
        return toys;
    }
	
    @RequestMapping(value = "/toys/{id}") // http://localhost:8090/toys/1
    public Toy getToy(@PathVariable int id) {
        LOG.info("returning toy");
        return toys.get(id);
    }

}  </div></pre><br>
 
    <h4>Step 7) Create application.yml file under src/main/resources</h4>
    <p>Using <code>defaultZone</code>, we can specify eureka service where the application will be registered.</p>
    <div id="code">
    <pre class="prettyprint">
spring:
  application:
    name: toy-service

server:
  port: 8090
  
eureka:
  client:
    serviceUrl:
      defaultZone: http://localhost:8761/eureka/      </div></pre>     
   <br>    
   
       <h4>Step 8) Create pom.xml file for second microservice ToyClientService similar to one for ToyServiceApplication.</h4>
        <div id="code">
        <pre class="prettyprint">
&lt;groupId&gt;com.example&lt;/groupId&gt;
&lt;artifactId&gt;toy-client-service&lt;/artifactId&gt;
&lt;version&gt;0.0.1-SNAPSHOT&lt;/version&gt;
&lt;packaging&gt;jar&lt;/packaging&gt;        </div> </pre> <br>
        
<h4>Step 9) Create ToyClientServiceApplication & ToyRestController classes</h4>
    <div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class ToyClientServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(ToyClientServiceApplication.class, args);
    }
    
    @Bean
    @LoadBalanced
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
} </div>
    </pre>        

<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class ToyClientServiceRestController {
	
    @Autowired
    private RestTemplate restTemplate;

    private static final Logger LOG = LoggerFactory.getLogger(ToyClientServiceRestController.class);

    @RequestMapping("/toy-client-service/toys") // http://localhost:8090/toys
    public ResponseEntity&lt;?> getToys() {
		LOG.info("calling toy service");
        return restTemplate.getForEntity("http://toy-service/toys/", String.class);
    }
	
    @RequestMapping("/toy-client-service/{id}") // http://localhost:8090/toys/1
    public ResponseEntity&lt;?> getToy(@PathVariable String id) {
		LOG.info("calling toy service");
        return restTemplate.getForEntity("http://toy-service/toys/"+id, String.class);
    }
        
} </div> </pre>      <br>

<h4>Step 10) Create application.yml file under src/main/resources</h4>
    <div id="code">
    <pre class="prettyprint">
spring:
  application:
    name: toy-client-service

server:
  port: 8091
  
eureka:
  client:
    serviceUrl:
      defaultZone: http://localhost:8761/eureka/        </div> </pre>     
   <br>  
   
   <h4>Step 11) Refresh <a href="http://localhost:8761" target="_blank">http://localhost:8761/</a> in the browser.</h4>
    <div>
    You will see below page displayed in the broswer.
    
        <div>
            <p><img src="../images/microservices/eureka_4.jpg" alt="Eureka Service Registry" style="width:800px;height:500px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>    
    </div>
   
    <h4>Step 12) Testing eurake service discovery</h4>
    <div id="solution">
        Launch <code>ToyServiceApplication</code> & <code>ToyClientServiceApplication</code>, in browser navigate to <a href="http://localhost:8091/toy-client-service/1" target="_blank">http://localhost:8091/toy-client-service/1</a>.<br>
        Note that <code>ToyClientServiceApplication</code> internally calls <b><i>http://toy-service/toys/1</b></i> which means <code>ToyServiceApplication</code> instance was fetched from <b><i>Eureka Servie Registry</b></i> and then it was invoked.
    </div>
    
    <p>You will see below page displayed in the broswer.</p>
    
        <div>
            <p><img src="../images/microservices/eureka_3.jpg" alt="Maven Build" style="width:400px;height:150px;"></p>
        </div>
        
        <br><br><br><br><br><br><br>
        
        <div>
            <p><img src="../images/microservices/eureka_5.jpg" alt="Maven Build" style="width:400px;height:300px;"></p>
        </div>
        
        <br><br><br><br><br><br><br>
    </div>
    
    <br>           
<br>   
        
    References : <br><br>
    <a href="https://spring.io/guides/gs/service-registration-and-discovery/" target="_blank">Spring Service Registration and Discovery</a>    <br><br>
        
        </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
        
         <div id="content">
            <?php include '../blogs/entry.php';?>
        </div>
        
         <?php include("share.htm"); ?>
    </body>

    <?php 
        include("footer.htm");
    ?>
    </html>