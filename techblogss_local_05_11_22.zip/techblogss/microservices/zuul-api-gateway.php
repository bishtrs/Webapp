    <?php include("../header.htm");?>

    <head>
        <title>Zuul API Gateway example</title>
        <meta name="description" content="Zuul API Gateway" />
        <link rel="canonical" href="https://www.techblogss.com/microservices/zuul-api-gateway" />
    </head>

    <body>
        <?php include("../navigation.htm");?>
        
        <div id="content">
        <div id="blog">
        <div id="problem">
            <h1>Zuul API Gateway example</h1>
        </div>
        <div id="solution">
            <p>
            A service <code>API gateway</code> acts as an intermediary between the service client and a service being invoked. The service client 
            talks only to a single URL managed by the service gateway. The service <code>API gateway</code> sits as the gatekeeper for all inbound
            traffic to microservice calls within your application. 
            </p>
            <p>
            With a service gateway in place, your service clients never directly call the URL of an individual service, but instead place all calls
            to the service gateway.
            </p>    
            <p>
            You can implement <code>API gateway</code> using <code>Netflix</code> open source project <code>Zuul</code>. <code>Zuul</code>
            is a services gateway that's extremely easy to set up. Below example shows how to configure service registgry, 
            write a simple microservice application (Book Service) and then build a reverse proxy application that uses <code> Netflix Zuul</code> 
            to forward requests to the book service application.
            </p>
        </div>
        
        <div>
            <img src="../images/microservices/zuul_1.jpg" alt="Maven Build" style="width:600px;height:400px;">
        
            <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        </div>
        
        <h4>Step 1) Add below dependencies in pom.xml file as below to create Eureka Service registry </h4>
        
        <div id="code">
        <pre class="prettyprint">
&lt;dependencies&gt;
    &lt;dependency&gt;
        &lt;groupId&gt;org.springframework.cloud&lt;/groupId&gt;
        &lt;artifactId&gt;spring-cloud-starter-netflix-eureka-server&lt;/artifactId&gt;
    &lt;/dependency&gt;
&lt;/dependencies&gt;

&lt;dependencyManagement&gt;
    &lt;dependencies&gt;
        &lt;dependency&gt;
            &lt;groupId&gt;org.springframework.cloud&lt;/groupId&gt;
            &lt;artifactId&gt;spring-cloud-dependencies&lt;/artifactId&gt;
            &lt;version&gt;Hoxton.RELEASE&lt;/version&gt;
            &lt;type&gt;pom&lt;/type&gt;
            &lt;scope&gt;import&lt;/scope&gt;
        &lt;/dependency&gt;
    &lt;/dependencies&gt;
&lt;/dependencyManagement&gt;
        </pre></div><br>

    <div id="1">
    <h4>Step 2) Create EurekaServiceApplication class to launch Eureka Service registry</h4>
    <div id="code">
    <pre class="prettyprint">
package com.example.hello;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@EnableEurekaServer
@SpringBootApplication
public class EurekaServiceApplication {

  public static void main(String[] args) {
    SpringApplication.run(EurekaServiceApplication.class, args);
  }
}
  </div>
    </pre>    
    <br>
    
<h4>Step 3) Create application.properties file under src/main/resources</h4>
    <div id="code">
    <pre class="prettyprint">
server.port=8761

eureka.client.register-with-eureka=false
eureka.client.fetch-registry=false

logging.level.com.netflix.eureka=OFF
logging.level.com.netflix.discovery=OFF
    </div>
    </pre>    

    </div>    

 <br>
<h4>Step 4) Launch EurekaServiceApplication and open <a href="http://localhost:8761" target="_blank">http://localhost:8761/</a>
 in the browser.</h4>
    <div>
    You will see below page displayed in the broswer.
    
        <div>
            <p><img src="../images/microservices/eureka_1.jpg" alt="Maven Build" style="width:800px;height:500px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    </div>
    
<br>        
<h4>Step 5) Add below dependencies in pom.xml file as mentioned below for BookService application</h4>
        <div id="code">
        <pre class="prettyprint">
&lt;dependencies>
    &lt;dependency>
        &lt;groupId>org.springframework.cloud&lt;/groupId>
        &lt;artifactId>spring-cloud-starter-netflix-eureka-client&lt;/artifactId>
    &lt;/dependency>
    &lt;dependency>
        &lt;groupId>org.springframework.boot&lt;/groupId>
        &lt;artifactId>spring-boot-starter-web&lt;/artifactId>
    &lt;/dependency>

&lt;/dependencies>

&lt;dependencyManagement>
    &lt;dependencies>
        &lt;dependency>
            &lt;groupId>org.springframework.cloud&lt;/groupId>
            &lt;artifactId>spring-cloud-dependencies&lt;/artifactId>
            &lt;version>Hoxton.RELEASE&lt;/version>
            &lt;type>pom&lt;/type>
            &lt;scope>import&lt;/scope>
        &lt;/dependency>
    &lt;/dependencies>
&lt;/dependencyManagement>
        </div></pre><br>
        
         <h4>Step 6) Create Book, BookApplication & BookRestController classes</h4>
    <div id="code">
    <pre class="prettyprint">
package com.example.demo;

    public class Book {
        
    private String title;
    private String author;
    private String genre;
        
    public Book(String title, String author, String genre) {
        this.title = title;
        this.author = author;
        this.genre = genre;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getGenre() {
        return genre;
    }

    @Override
    public String toString() {
        return "Book [title=" + title + ", author=" + author + ", genre="
                + genre + "]";
    }
    
}
   </div>
        </pre>
        
<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@EnableEurekaClient
@SpringBootApplication
public class BookApplication {

    public static void main(String[] args) {
        SpringApplication.run(BookApplication.class, args);
    }
}
   </div>
        </pre>

<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BookRestController {
    
    List&lt;Book> books = new ArrayList&lt;>();
        
    public BookRestController() {
        books.add(new Book("The Silence of the Lambs", "Thomas Harris", "Thriller"));
        books.add(new Book("Murder on the Orient Express", "Agatha Christie", "Thriller"));
        books.add(new Book("A Midsummer Night's Dream", "William Shakespeare", "Comedy"));
    }

    @GetMapping("/{id}") 
    public Book get(@PathVariable("id") int id) {
        return books.get(id);
    }
}
   </div>
        </pre>        
        <br>
 
<h4>Step 7) Create application.properties file under src/main/resources</h4>
    <div id="code">
    <pre class="prettyprint">
spring.application.name=book-service
eureka.client.serviceUrl.defaultZone=http://localhost:8761/eureka/
    </div>
    </pre>     
   <br>    
   
       <h4>Step 8) Add below dependencies in pom.xml file as below to create ZuulProxy application.</h4>
        <div id="code">
        <pre class="prettyprint">
&lt;dependencies>
    &lt;dependency>
        &lt;groupId>org.springframework.cloud&lt;/groupId>
        &lt;artifactId>spring-cloud-starter-netflix-eureka-client&lt;/artifactId>
    &lt;/dependency>
    &lt;dependency>
        &lt;groupId>org.springframework.cloud&lt;/groupId>
        &lt;artifactId>spring-cloud-starter-netflix-zuul&lt;/artifactId>
    &lt;/dependency>

&lt;/dependencies>

&lt;dependencyManagement>
    &lt;dependencies>
        &lt;dependency>
            &lt;groupId>org.springframework.cloud&lt;/groupId>
            &lt;artifactId>spring-cloud-dependencies&lt;/artifactId>
            &lt;version>Hoxton.RELEASE&lt;/version>
            &lt;type>pom&lt;/type>
            &lt;scope>import&lt;/scope>
        &lt;/dependency>
    &lt;/dependencies>
&lt;/dependencyManagement>
        </div></pre><br>
        
<h4>Step 9) Create ZuulApplication & SimpleFilter classes</h4>
    <div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
@EnableDiscoveryClient
@EnableZuulProxy
public class ZuulApplication {

    public static void main(String[] args) { 
        SpringApplication.run(ZuulApplication.class, args);
    }

    @Bean
    public SimpleFilter simpleFilter() {
        return new SimpleFilter();
    }

}   </div></pre>        

<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import javax.servlet.http.HttpServletRequest;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.ZuulFilter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SimpleFilter extends ZuulFilter {

    private static Logger log = LoggerFactory.getLogger(SimpleFilter.class);

    @Override
    public String filterType() {
        return "pre";
    }

    @Override
    public int filterOrder() {
        return 1;
    }

    @Override
    public boolean shouldFilter() {
        return true;
    }

    @Override
    public Object run() {
        RequestContext ctx = RequestContext.getCurrentContext();
        HttpServletRequest request = ctx.getRequest();

        log.info(String.format("%s request to %s", request.getMethod(), request
                .getRequestURL().toString()));

        return null;
    }

}
   </div>
    </pre>            
    <br>

<h4>Step 10) Create application.properties file under src/main/resources</h4>
    <div id="code">
    <pre class="prettyprint">
spring.application.name=zuul-gateway
server.port=9999
eureka.client.serviceUrl.defaultZone=http://localhost:8761/eureka/    </div></pre><br>  
   
    <h4>Step 11) Launch BookApplication & ZuulApplication and open <a href="http://localhost:9999/book-service/1" target="_blank">
    http://localhost:9999/book-service/1</a> in the browser.</h4>
    <p>Note that browser will send call to <b><i>Zuul Proxy Gateway</b></i> which internaly forwards the call to <b><i>Book Service</b></i>
    and returns result.</p>
    <div>
    You will see below page displayed in the broswer.
    
        <div>
            <p><img src="../images/microservices/zuul_2.jpg" alt="Zuul" style="width:600px;height:300px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br><br>
    </div>
    
    <br>   
    
    <h4>Step 12) Also refresh <a href="http://localhost:8761" target="_blank">http://localhost:8761/</a> in the browser.</h4>
    <div>
    You will see below page displayed in the broswer.
    
        <div>
            <p><img src="../images/microservices/zuul_3.jpg" alt="Maven Build" style="width:800px;height:500px;"></p>
        </div>
        
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    </div>
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
<br>   
        
    References : <br><br>
    <a href="https://spring.io/guides/gs/routing-and-filtering/">Spring Docs Routing and Filtering</a>    <br><br>
        
        </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
        
         <div id="content">
            <?php include '../blogs/entry.php';?>
        </div>
        
         <?php include("share.htm"); ?>
    </body>

    <?php include("../footer.htm");?>
    </html>