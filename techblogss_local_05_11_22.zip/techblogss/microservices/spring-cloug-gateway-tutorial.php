<?php include("../header.htm");?>

<head>
    <title>Spring Cloud Gateway tutorial</title>
    <meta name="description" content="Spring Cloud Gateway tutorial" />
    <link rel="canonical" href="https://www.techblogss.com/microservices/spring-cloug-gateway-tutorial" />
</head>

<body>
     <?php include("../navigation.htm");?>
        
     <div id="content">
     <div id="blog">
        <div id="problem">
            <h1>Spring Cloud Gateway tutorial</h1>
        </div>
        <div id="solution">
            <p>
                When we implement API gateway pattern, <code>Spring Cloud Gateway</code> is one of the options provided by Spring cloud framework.
                <code>Spring Cloud Gateway</code> enables routing to APIs and solves cross-cutting concerns like security, monitoring, resiliency.
                It is based on <code>Spring 5</code> and uses <code>Netty web server</code> & reactor framework underneath. If you compare <code>Spring Cloud Gateway</code> with Netflix's <code>Zuul 1.0</code>, <code>Spring Cloud Gateway</code> supports asynchronous & non blocking connections while <code>Zuul 1.0</code> does not.
            </p> 
            
            <p>
                <code>Spring Cloud Gateway</code> is based on below three concepts
            </p>             
            <ul>
                <li>
                <code>Route</code>: A route consists of a unique id, destination uri, list of predicates & a list of filters. All predicates need
                to be fullfilled to match a route
                </li>
                <li>
                <code>Predicates</code>: Contains logic to match a uri, for e.g if a request type if GET type, follows a particular path like /customers/
                </li>
                <li>
                <code>Filters</code>: Used to modify the incoming request, for e.g it can be used to add headers, or modify path.
                </li>
            </ul>
            
            <p>
                In this <code>Spring Cloud Gateway</code> tutorial, we will create a Customer service which returns a customer details but the actual service call to Customer service will go through <code>Spring Cloud Gateway</code>. So a caller will send request to gateway which will route the call to the customer service. Similarly you can add more services like order service, account service.
            </p> 
            
        </div>
        
        <div>
            <img src="../images/microservices/springcloudgateway.jpg" alt="Spring Cloud Gateway" style="width:600px;height:400px;">
        
            <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        </div>
        
        <h4>Step 1) Add below dependencies in pom.xml for GatewayApplication</h4>
        
        <div id="code">
        <pre class="prettyprint">
&lt;parent>
    &lt;groupId>org.springframework.boot&lt;/groupId>
    &lt;artifactId>spring-boot-starter-parent&lt;/artifactId>
    &lt;version>2.6.3&lt;/version>
    &lt;relativePath/> 
&lt;/parent>
    
&lt;dependencies&gt;
    &lt;dependency&gt;
        &lt;groupId&gt;org.springframework.cloud&lt;/groupId&gt;
        &lt;artifactId&gt;spring-cloud-starter-gateway&lt;/artifactId&gt;
    &lt;/dependency&gt;
        &lt;dependency&gt;
        &lt;groupId&gt;org.springframework.cloud&lt;/groupId&gt;
        &lt;artifactId&gt;spring-cloud-starter-circuitbreaker-reactor-resilience4j&lt;/artifactId&gt;
    &lt;/dependency&gt;
    &lt;dependency&gt;
        &lt;groupId&gt;org.springframework.cloud&lt;/groupId&gt;
        &lt;artifactId&gt;spring-cloud-starter-contract-stub-runner&lt;/artifactId&gt;
        &lt;exclusions&gt;
            &lt;exclusion&gt;
                &lt;artifactId&gt;spring-boot-starter-web&lt;/artifactId&gt;
                &lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
            &lt;/exclusion&gt;
        &lt;/exclusions&gt;
    &lt;/dependency&gt;
&lt;/dependencies&gt;

&lt;dependencyManagement&gt;
    &lt;dependencies&gt;
        &lt;dependency&gt;
            &lt;groupId&gt;org.springframework.cloud&lt;/groupId&gt;
            &lt;artifactId&gt;spring-cloud-dependencies&lt;/artifactId&gt;
            &lt;version&gt;2021.0.3&lt;/version&gt;
            &lt;type&gt;pom&lt;/type&gt;
            &lt;scope&gt;import&lt;/scope&gt;
        &lt;/dependency&gt;
    &lt;/dependencies&gt;
&lt;/dependencyManagement&gt;</pre></div><br>

    <h4>Step 2) Create Gateway application</h4>
    
    
    <div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class GatewayApplication {

    public static void main(String[] args) {
        SpringApplication.run(GatewayApplication.class, args);
    }

    @Bean
    public RouteLocator myRoutes(RouteLocatorBuilder builder) {
        return builder.routes()
            route(p -> p.method(HttpMethod.GET).and().path("/customers/{id}")
                .filters(f -> f.addRequestHeader("Hello", "World").prefixPath("/v1"))
                    .uri("http://localhost:8080")).build();
    }

}</pre></div><br>

    <h4>Step 3) Add application.yml</h4>
    
    <div id="code">
    <pre class="prettyprint">
server:
  port: 9999 </pre></div><br>
  
  <p>Note that you can also configure routes in application.yml instead of creating in GatewayApplication class as shown below</p>
  
  <div id="code">
    <pre class="prettyprint">
server:
  port: 9999
  
spring:
  cloud:
    gateway:
      routes:
      - id: customer-service
        uri: http://localhost:8080
        predicates:
        - Method=GET
        - Path=/customers/{id}
        filters:
        - AddRequestHeader=Hello, World
        - PrefixPath=/v1</pre></div><br>

    <h4>Step 3) Create CustomerService application which returns a customer details</h4>
    <p>Create CustomerRestController, Customer,  CustomerServiceApplication classes, application.yml file.</p>
    
   
    <div id="code">
    <pre class="prettyprint">
spring:
  application:
    name: customer-service

server:
  port: 8080</pre></div><br> 

<div id="code">
    <pre class="prettyprint">
spackage com.example.demo;

public class Customer {

	private String id;
	private String name;
    
	// removed getters, setters for brevity
}</pre></div><br> 
  
    
<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerRestController {

    private static final Logger LOG = LoggerFactory.getLogger(CustomerRestController.class);

    private List&lt;Customer> customers = new ArrayList&lt;>();

    public CustomerRestController() {
        customers.add(new Customer("superman", "Clark Kent"));
        customers.add(new Customer("batman", "Ben Affleck"));
        customers.add(new Customer("thor", "Chris Hemsworth"));
    }

    @RequestMapping(value = "/v1/customers/{id}")
    public Customer getCustomer(@PathVariable String id) {
        LOG.info("returning toy");
        return customers.stream().filter(customer -> 
            customer.getId().equalsIgnoreCase(id)).findFirst().get();
    }

}</pre></div><br>

<div id="code">
    <pre class="prettyprint">
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(CustomerServiceApplication.class, args);
    }
}</pre></div><br>
    
    

    </div><br>
    
 
    <h4>Step 4) Testing Spring cloud gateway</h4>
    <div id="solution">
        Launch <code>CustomerServiceApplication</code> & <code>GatewayApplication</code>, in browser navigate to <a href="http://localhost:9999/customers/batman" target="_blank">http://localhost:9999/customers/batman</a>.<br>
        Note that above request goes to <code>GatewayApplication</code> which routes the request to <b><i>http://localhost:8080/v1/customers/batman</b></i>
    </div>
    
    <p>You will see below page displayed in the broswer.</p>
    
        <div>
            <p><img src="../images/microservices/springcloudgateway2.jpg" alt="Spring Cloud Gateway tutorial" style="width:400px;height:125px;"></p>
        </div>
        
        <br><br><br><br><br><br><br>
        
       
        
    References : <br><br>
    <a href="https://cloud.spring.io/spring-cloud-gateway/reference/html/" target="_blank">Spring Cloud Gateway</a>    <br><br>
        
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
    
    </div> <!-- content div -->
        
         <div id="content">
            <?php include '../blogs/entry.php';?>
        </div>
        
         <?php include("share.htm"); ?>
    </body>

    <?php 
        include("footer.htm");
    ?>
    </html>