<?php include "../header.htm" ;?>

<head>
    <title>Tech Blogss</title>
	<meta name="description" content="JDBC posts" />
    <link rel="canonical" href="https://www.techblogss.com/jdbc/jdbc">
    <!-- added for google search -->
    <script async src="https://cse.google.com/cse.js?cx=7d9bc37a65153d27d"></script>
</head>

<body>
    <?php include("../navigation.htm");?>
    
    <div id="posts">
        
        <div id="postLeft">
            <div id="postHeader"><h3><a href="../react/react-hello-world-visual-studio-code" target="_blank">React Hello world Visual Studio Code</a></h3></div>
            <div id="postText"><p>In this tutorial we will describe how to create a React Hello world ...</p></div>
            <div id="postFooter"><p>Uses React 18.2.0</p></div>
        </div>
        
        <div id="postRight">
            <div id="postHeader"><h3><a href="../react/react-pass-props-to-functional-component" target="_blank">Pass props to functional component</a></h3></div>
            <div id="postText"><p>In this example we will show how to pass props to a functional component...</p></div>
            <div id="postFooter"><p>Uses React 18.2.0</p></div>
        </div>
        
        - Hide and show in React JS functional component
        
        
        <?php include("../sidebar/ad.htm"); ?>
        
    </div>
	
	
    <?php include("../sidebar/sidebarHomePage.htm"); ?>
	
</body>

<?php include("footer.htm");?>

</html>
