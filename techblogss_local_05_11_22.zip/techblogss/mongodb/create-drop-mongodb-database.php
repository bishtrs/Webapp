<?php 
    include("header.htm");
?>

<head>
    <title>How to create & drop MongoDB Database</title>
	<meta name="description" content="Create & Drop MongoDB Database" />
	<link rel="canonical" href="https://www.techblogss.com/mongodb/create-drop-mongodb-database" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>How to create & drop MongoDB Database</h1>
	</div>
    
	<div id="solution">
        <h2>Create MongoDB Database</h2>
		
        <p>
            Launch MongoDB shell. On startup, the shell connects to the test database on a MongoDB server and assigns this database connection
            to the global variable <b><i>db</b></i>. This variable is the primary access point to your MongoDB server through the shell.
            To see the database db is currently assigned to, type in <b><i>db</b></i> and hit Enter:
        </p>
<pre class="prettyprint">>db
test
</pre>

        <p>
            To create a students database, type use students. Now if you look at the <b><i>db</b></i> variable, you can see that it refers to the students database.
        </p>
<pre class="prettyprint">>use students
switched to db students
</pre>
        <p>
            To check your databases list, use the command <b><i>show dbs</b></i>. Observe that it will not display students database as it is empty. 
            Now insert some document in students database using db.students.insert({"rollno":"1"}) & run <b><i>show dbs</b></i> command to see studendts database.
        </p>
<pre class="prettyprint">>show dbs
local  0.078GB
myDb   0.078GB
> db.students.insert({"rollno":"1"})
WriteResult({ "nInserted" : 1 })
> show dbs
local     0.078GB
myDb      0.078GB
students  0.078GB
</pre>
        
        <br>
        <h2>Drop MongoDB Database</h2>
		
        <p>
            You can drop a MongoDB database using <b><i>db.dropDatabase()</b></i> command. If you want to drop students database, first run use students
            command and then run <b><i>db.dropDatabase()</b></i> command. run <b><i>show dbs</b></i> command to verify if the database is dropped.
        </p>
<pre class="prettyprint">> show dbs
local     0.078GB
myDb      0.078GB
students  0.078GB
> db.dropDatabase()
{ "dropped" : "students", "ok" : 1 }
> show dbs
local  0.078GB
myDb   0.078GB
>
</pre>

    </div>
    
    <!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
 
References : <br><br>
<a href="https://www.mongodb.com/download-center/community/">https://www.mongodb.com/download-center/community/</a>	<br><br>
 
	</div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>
</html>