<?php include("../header.htm");?>

<head>
    <title>Prototype Design Pattern Java</title>
	<meta name="description" content="This example shows how to implement Prototype Design Pattern in Java" />
	<link rel="canonical" href="https://www.techblogss.com/designpatterns/prototype-design-pattern" />
</head>

<body>
	<?php 
		include("navigation.htm");
	?>
   	
	<div id="content">
    <div id="blog">
	<div id="problem">
		<h1>Prototype Design Pattern in Java</h1>
	</div><br>
    
	<div id="solution">
        <h2>Below example shows how to implement Prototype Design Pattern in Java</h2>
        <p>
        <b><i>Prototype Design Pattern</b></i> is a creational design pattern and should be used when creating an nstance of a class is either
        expensive or complex. <b><i>Prototype Design Pattern</b></i> is used when the type of objects to be created is determined by an 
        instance of a prototye, which is cloned to produce new objects.
        </p>
	</div>
    
    <p>We wil first create an abstract parent <b><i>Fruit</b></i> class & then create 3 sub classes Apple, Mango, & Banana.</p>    
    <h3>UML class diagram for Prototype Design Pattern</h3>
    <div>
            <p><img src="../images/dp/prototype.jpg" alt="Prototype Design Pattern" title="Prototype Design Pattern" 
            style="width:700px;height:300px;"></p>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br>    
	<div id="code">
    <pre class="prettyprint">
public abstract class Fruit implements Cloneable {
	
    private String name; 
        
    public Fruit(String name) {
        this.name = name;
    }
        
    public Fruit clone() throws CloneNotSupportedException {
        return (Fruit) super.clone();
    }
        
    public String getName() {
        return this.name;
    }

}</pre>
	</div>
    <br>
  
	
	<div id="code">
		<pre class="prettyprint">
public class Apple extends Fruit {
	
    public Apple(String name) {
        super(name);
    }
	
    @Override
    public Fruit clone() throws CloneNotSupportedException {
        return (Fruit) super.clone();
    }

}	</pre>
	</div>

    	<div id="code">
		<pre class="prettyprint">
public class Mango extends Fruit {
	
    public Mango(String name) {
        super(name);
    }
	
    @Override
    public Fruit clone() throws CloneNotSupportedException {
        return (Fruit) super.clone();
    }

}	</pre>
	</div>
    
	<div id="code">
		<pre class="prettyprint">
public class Banana extends Fruit {
	
    public Banana(String name) {
        super(name);
    }
	
    @Override
    public Fruit clone() throws CloneNotSupportedException {
        return (Fruit) super.clone();
    }

}	</pre>
	</div>  
 <br>
    <p>Now we create a FruitFactory class for creating <b><i>Fruit</b></i> type classes.</p>    
	<div id="code">
		<pre class="prettyprint">
import java.util.HashMap;
import java.util.Map;

public class FruitFactory {

    private static final Map&lt;String, Fruit> prototypes = new HashMap<>();

    static {
        prototypes.put("apple", new Apple("Apple"));
        prototypes.put("mango", new Mango("Mango"));
        prototypes.put("banana", new Mango("Banana"));
    }

    public static Fruit getPrototype(String type) {
        try {
            return prototypes.get(type).clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        return null;
    }

}	</pre>
	</div>      


	<div id="code">
		<pre class="prettyprint">
// Creates prototypes of the Fruit classes
public class FruitPrototypeTest {
    
    public static void main(String[] args) {
        Fruit mangoPrototype  = FruitFactory.getPrototype("mango");
        System.out.println(mangoPrototype);
        System.out.println(mangoPrototype.getName());
        
        mangoPrototype  = FruitFactory.getPrototype("mango");
        System.out.println(mangoPrototype);
        System.out.println(mangoPrototype.getName());

        Fruit applePrototype  = FruitFactory.getPrototype("apple");
        System.out.println(applePrototype);
        System.out.println(applePrototype.getName());
        
        applePrototype  = FruitFactory.getPrototype("apple");
        System.out.println(applePrototype);
        System.out.println(applePrototype.getName());
        
        Fruit bananaPrototype  = FruitFactory.getPrototype("banana");
        System.out.println(bananaPrototype);
        System.out.println(bananaPrototype.getName());
    }

}	</pre>
	</div>    

<div id="solution">
	<h4>Console Output : </h4>
	</div>
	
	<div id="code">
		<pre class="prettyprint">
dp.creational.Mango@1db9742
Mango
dp.creational.Mango@106d69c
Mango
dp.creational.Apple@52e922
Apple
dp.creational.Apple@25154f
Apple
dp.creational.Mango@10dea4e
Banana	</pre>
	</div>	
    <br>    
<!-- ADU1 -->
    <?php include("../sidebar/ad.htm"); ?>
    <br>
 
    </div> <!-- blog div-->
    
    <?php include("../sidebar/sidebar.htm"); ?>
	
    </div> <!-- content div -->
    
    <div id="content">
        <?php include '../blogs/entry.php';?>
    </div>
	
    <?php include("share.htm"); ?>
</body>

<?php 
    include("footer.htm");
?>
</html>